"""Async HTTP transport for the Databricks AI Search SDK.

Mirrors :class:`databricks.ai_search.utils.RequestUtils` over
``httpx.AsyncClient``. Status codes map to the same exception hierarchy as the
sync path so callers can use a single ``except`` block regardless of which
client they use.
"""

import asyncio
import datetime
import random
from email.utils import parsedate_to_datetime
from typing import Dict, Optional

import httpx

from databricks.ai_search.exceptions import AISearchException
from databricks.ai_search.utils import _format_error_message, exception_for_status
from databricks.ai_search.version import VERSION


_RETRYABLE_STATUS_CODES = {429, 503, 504}
# Match the sync path's urllib3.Retry network-error coverage: TimeoutException
# spans the connect/read/write/pool timeouts, NetworkError spans connect/read/
# write/close failures, and RemoteProtocolError catches mid-stream resets.
_RETRYABLE_EXCEPTIONS = (
    httpx.TimeoutException,
    httpx.NetworkError,
    httpx.RemoteProtocolError,
)


# Per-event-loop client cache so one httpx.AsyncClient (and its connection
# pool) is reused across requests on the same loop. Sync mirrors this with
# the functools.cache-decorated _cached_get_request_session in utils.py.
_clients: Dict[int, httpx.AsyncClient] = {}


def _parse_retry_after(value):
    """Parse a Retry-After header value as either seconds or an HTTP-date.

    Returns the delay in seconds, or None if the header cannot be parsed.
    """
    if value is None:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        pass
    try:
        retry_date = parsedate_to_datetime(value)
    except (TypeError, ValueError):
        return None
    if retry_date is None:
        return None
    now = datetime.datetime.now(datetime.timezone.utc)
    if retry_date.tzinfo is None:
        retry_date = retry_date.replace(tzinfo=datetime.timezone.utc)
    delta = (retry_date - now).total_seconds()
    return max(delta, 0.0)


async def _get_client_for_loop():
    """Return a cached ``httpx.AsyncClient`` bound to the running loop.

    ``httpx.AsyncClient`` holds connection pools that are tied to the event
    loop that created them; sharing across loops produces obscure errors.
    Keying the cache by ``id(loop)`` keeps construction lazy and per-loop.
    The body has no ``await`` between the cache check and insert, so within
    a single loop the check-and-set is atomic.
    """
    loop = asyncio.get_running_loop()
    key = id(loop)
    client = _clients.get(key)
    if client is None or client.is_closed:
        client = httpx.AsyncClient(timeout=None)
        _clients[key] = client
    return client


async def aclose_all_clients():
    """Close every cached ``httpx.AsyncClient``. Intended for tests and orderly shutdown.

    Do not call while requests are in flight — this closes the underlying
    connection pools, which will cause any awaiting coroutines to raise
    ``httpx.ClientError``.
    """
    clients = list(_clients.values())
    _clients.clear()
    for client in clients:
        try:
            await client.aclose()
        except (httpx.HTTPError, OSError):
            pass


class AsyncRequestUtils:
    """Async equivalent of :class:`RequestUtils`.

    Issues a single HTTP request with retry/backoff and translates non-2xx
    responses into the SDK's typed exceptions. ``httpx`` has no built-in
    retry support, so the loop is implemented here.
    """

    @staticmethod
    async def issue_request(
        url: str,
        method: str,
        token: Optional[str] = None,
        params: Optional[dict] = None,
        json: Optional[dict] = None,
        auth: Optional[tuple] = None,
        data: Optional[dict] = None,
        headers: Optional[dict] = None,
        total_retries: int = 3,
        backoff_factor: float = 1.0,
        backoff_jitter: float = 0.2,
        client: Optional[httpx.AsyncClient] = None,
    ):
        """Issue an async HTTP request and return its JSON body.

        Retries up to ``total_retries`` times on transient failures (HTTP
        429/503/504 plus httpx ``TimeoutException`` / ``NetworkError`` /
        ``RemoteProtocolError``). Honors ``Retry-After`` when present;
        otherwise sleeps for
        ``backoff_factor * (2 ** (attempt - 1)) * (1 + backoff_jitter * random())``
        seconds between attempts. Non-retryable 4xx responses raise immediately.
        """
        headers = dict(headers) if headers else {}
        if token:
            headers["Authorization"] = f"Bearer {token}"
        headers["X-Databricks-Python-SDK-Version"] = VERSION

        owns_client = client is None
        if owns_client:
            client = await _get_client_for_loop()

        last_exc: Optional[BaseException] = None
        response: Optional[httpx.Response] = None
        for attempt in range(total_retries + 1):
            try:
                response = await client.request(
                    method=method,
                    url=url,
                    params=params,
                    json=json,
                    data=data,
                    headers=headers,
                    auth=auth,
                )
                if response.status_code in _RETRYABLE_STATUS_CODES and attempt < total_retries:
                    delay = _parse_retry_after(response.headers.get("Retry-After"))
                    if delay is None:
                        delay = backoff_factor * (2**attempt) * (1 + backoff_jitter * random.random())
                    await asyncio.sleep(delay)
                    continue
                break
            except _RETRYABLE_EXCEPTIONS as exc:
                last_exc = exc
                if attempt >= total_retries:
                    raise
                delay = backoff_factor * (2**attempt) * (1 + backoff_jitter * random.random())
                await asyncio.sleep(delay)

        if response is None:
            raise AISearchException(
                f"Request to {url} failed: {last_exc!r}",
                status_code=None,
                response_content=None,
            )

        if response.is_success:
            return response.json()

        status_code = response.status_code
        error_message = f"HTTP {status_code}"
        error_code = None
        details = None
        try:
            error_data = response.json()
            if isinstance(error_data, dict):
                error_message = _format_error_message(error_data)
                error_code = error_data.get("error_code")
                details = error_data.get("details")
        except ValueError:
            # json.JSONDecodeError is a ValueError subclass; we catch the parent
            # because the `json` parameter on this method shadows the stdlib name
            # inside this scope.
            error_message = response.text or f"HTTP {status_code} error"

        raise exception_for_status(status_code)(
            error_message,
            status_code=status_code,
            response_content=response.content,
            error_code=error_code,
            details=details,
        )
