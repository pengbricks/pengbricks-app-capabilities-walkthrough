class AISearchException(Exception):
    """
    Base exception for all AI Search SDK errors.

    Attributes:
        status_code: HTTP status code if applicable
        response_content: Raw response content from the API
        error_code: Databricks error_code from the response body, if any
        details: Structured error details from the response body, if any
    """

    def __init__(self, message, status_code=None, response_content=None, error_code=None, details=None):
        super().__init__(message)
        self.status_code = status_code
        self.response_content = response_content
        self.error_code = error_code
        self.details = details


class InvalidInputException(AISearchException):
    pass


class NotFound(AISearchException):
    pass


# Alias for compatibility with databricks SDK naming convention
ResourceDoesNotExist = NotFound


class BadRequest(AISearchException):
    pass


class PermissionDenied(AISearchException):
    pass


class ResourceConflict(AISearchException):
    pass


class TooManyRequests(AISearchException):
    pass


# Backward-compat alias for the AI Search rebrand. The canonical class is
# AISearchException; VectorSearchException is the same class accessible under
# the legacy name.
VectorSearchException = AISearchException
