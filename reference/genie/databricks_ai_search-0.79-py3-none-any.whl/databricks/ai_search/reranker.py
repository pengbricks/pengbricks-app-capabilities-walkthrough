import re
from abc import ABC
from typing import Optional


def _default_finetuned_endpoint_name(index_name: str, table_id: str) -> str:
    """Default Model Serving endpoint name for a finetuned reranker.

    Formula (58 chars, 5 under Model Serving's 63-char cap):
        ``{cat6}_{schema6}_{index16}_{tableid8}_finetuned_reranker``

    where:
        - ``cat6``     : first 6 chars of UC catalog (sanitized + lowercased)
        - ``schema6``  : first 6 chars of UC schema (sanitized + lowercased)
        - ``index16``  : first 16 chars of the index name (sanitized + lowercased)
        - ``tableid8`` : first 8 hex chars of the UC index table UUID
                         (the ``id`` field on ``index.describe()``)

    The UC table UUID disambiguates distinct indexes that happen to share a
    leaf name in different catalogs/schemas, so derived endpoints never collide.
    Callers using ``ExperimentalDatabricksFinetunedReranker`` without an
    explicit ``endpoint_name`` get this value derived for them by
    ``AISearchIndex._build_query_payload`` via the index's cached
    ``_get_index_id`` lookup.
    """
    parts = index_name.split(".")
    if len(parts) < 3:
        raise ValueError(f"index_name must be fully qualified (catalog.schema.index): '{index_name}'")
    catalog, schema = parts[0], parts[1]
    index_short = ".".join(parts[2:])

    def _sanitize(segment: str) -> str:
        return re.sub(r"[^a-zA-Z0-9_-]", "_", segment).lower()

    cat6 = _sanitize(catalog)[:6]
    schema6 = _sanitize(schema)[:6]
    index16 = _sanitize(index_short)[:16]
    tableid8 = table_id.replace("-", "").lower()[:8]
    return f"{cat6}_{schema6}_{index16}_{tableid8}_finetuned_reranker"


class Reranker(ABC):
    """Abstract base class for all rerankers."""


class DatabricksReranker(Reranker):
    def __init__(self, columns_to_rerank: list[str]):
        """
        Initialize a DatabricksReranker config object.

        Args:
            columns_to_rerank: A list of column names to use for reranking the results.
        """
        self.columns_to_rerank = columns_to_rerank


class ExperimentalDatabricksFinetunedReranker(Reranker):
    """EXPERIMENTAL. Not covered by SDK compatibility guarantees.

    Rerank query results using a finetuned reranker model hosted on a Model
    Serving endpoint in the caller's workspace (typically created by the
    reranker finetuning job).
    """

    def __init__(
        self,
        columns_to_rerank: list[str],
        endpoint_name: Optional[str] = None,
    ):
        """Initialize an ExperimentalDatabricksFinetunedReranker.

        Args:
            columns_to_rerank: List of column names to concatenate and send to
                the reranker model for each document.
            endpoint_name: Name of the Model Serving endpoint hosting the
                finetuned reranker. If None, the index resolves it at query
                time via :func:`_default_finetuned_endpoint_name` using the
                index's UC table UUID (see that function for the exact
                formula). This requires one extra ``describe()`` round-trip
                the first time the index handles a finetuned-reranker query;
                the UUID is cached on the index for subsequent queries.
        """
        self.columns_to_rerank = columns_to_rerank
        self.endpoint_name = endpoint_name
