import json
import re
import requests
import os
import threading
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry
from functools import lru_cache
from databricks.ai_search.version import VERSION
from databricks.ai_search.exceptions import (
    BadRequest,
    NotFound,
    PermissionDenied,
    ResourceConflict,
    TooManyRequests,
    AISearchException,
)
from enum import Enum
from requests.packages import urllib3
from packaging import version
from typing import Optional


_CAMEL_TO_SNAKE_RE = re.compile(r"(?<!^)(?=[A-Z])")
_LITESWAP_TRAFFIC_ID_HEADER = "x-databricks-traffic-id"


def _liteswap_headers(liteswap_traffic_id):
    if not liteswap_traffic_id:
        return None
    return {_LITESWAP_TRAFFIC_ID_HEADER: liteswap_traffic_id}


def _camel_to_snake(name):
    """Convert a single camelCase string to snake_case. No-op on snake_case input."""
    return _CAMEL_TO_SNAKE_RE.sub("_", name).lower()


def normalize_response_keys_to_snake_case(value):
    """
    Recursively convert camelCase dict keys to snake_case.

    The proto3 JSON canonical mapping spec emits camelCase by default, which is what
    `vector-store` (Rust, via `protoc-gen-prost-serde`) returns on direct-DP requests.
    Responses routed through `brickindex-scheduler` (Scala, via `scalapb-json4s`) come
    back in snake_case because that library defaults the other way. This helper
    normalizes either shape to snake_case so downstream code can use a single key form.

    Already-snake_case keys are passed through unchanged. Lists and scalars are walked
    recursively. None is preserved.

    Do not apply to responses containing user-keyed maps (e.g. custom_tags): every
    key at every depth is rewritten, so user-controlled keys would be mangled.
    """
    if isinstance(value, dict):
        return {
            _camel_to_snake(k) if isinstance(k, str) else k: normalize_response_keys_to_snake_case(v)
            for k, v in value.items()
        }
    if isinstance(value, list):
        return [normalize_response_keys_to_snake_case(item) for item in value]
    return value


def _format_error_message(error_data):
    """Build an error string from a Databricks REST error body.

    Surfaces error_code and details alongside the message field, so callers see
    the full error instead of just the (often generic) message. The raw body
    still lives on the exception's response_content.
    """
    parts = []
    error_code = error_data.get("error_code")
    if error_code:
        parts.append(f"[{error_code}]")
    message = error_data.get("message") or error_data.get("error")
    if message:
        parts.append(message)
    details = error_data.get("details")
    if details:
        parts.append(f"details={json.dumps(details, default=str)}")
    # Nothing recognized: surface the whole body rather than an empty string.
    return " ".join(parts) if parts else str(error_data)


_STATUS_TO_EXCEPTION = {
    400: BadRequest,
    403: PermissionDenied,
    404: NotFound,
    409: ResourceConflict,
    429: TooManyRequests,
}


def exception_for_status(status_code):
    """Map an HTTP status to its SDK exception class (AISearchException for 5xx/other)."""
    return _STATUS_TO_EXCEPTION.get(status_code, AISearchException)


class OAuthTokenUtils:
    @staticmethod
    def get_azure_oauth_token(
        workspace_url,
        azure_tenant_id,
        azure_login_id,
        service_principal_client_id,
        service_principal_client_secret,
        authorization_details=None,
    ):
        assert azure_login_id and azure_tenant_id, "Both azure_login_id and azure_tenant_id must be specified"

        # Currently AI Search is only available in AZURE_PUBLIC, hence the url is hardcoded to
        # the active_directory_endpoint in AZURE_PUBLIC, see
        # See https://github.com/databricks/databricks-sdk-py/blob/main/databricks/sdk/environments.py
        # for the list of Azure login ids and active directory endpoint in Azure environments
        active_directory_endpoint = "https://login.microsoftonline.com/"
        aad_url = f"{active_directory_endpoint}/{azure_tenant_id}/oauth2/token"
        aad_response = RequestUtils.issue_request(
            url=aad_url,
            method="POST",
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            data={
                "grant_type": "client_credentials",
                "resource": azure_login_id,
                "client_id": service_principal_client_id,
                "client_secret": service_principal_client_secret,
            },
        )
        aad_token = aad_response["access_token"]
        authorization_details = authorization_details or []
        if not authorization_details:
            return aad_response

        # If authorization_details is specified, we need to exchange the AAD token for an OAuth token.
        # Request scope=all-apis on the exchange so the minted Databricks token carries an OAuth
        # scope. Without it, an Entra SP's exchanged token has an empty scope claim and is rejected
        # by scope-enforcing ingresses (e.g. Model Serving returns 403 OIDCTokenAuthenticatorInvalidScope
        # on query-text embedding). This mirrors the Databricks-SP path in get_oauth_token (ES-1967899).
        return RequestUtils.issue_request(
            url=workspace_url + "/oidc/v1/token",
            headers={
                "Content-Type": "application/x-www-form-urlencoded",
                "Accept": "*/*",
            },
            method="POST",
            data={
                "grant_type": "urn:ietf:params:oauth:grant-type:jwt-bearer",
                "assertion": aad_token,
                "scope": "all-apis",
                "authorization_details": authorization_details,
            },
        )

    @staticmethod
    def get_oauth_token(
        workspace_url,
        service_principal_client_id,
        service_principal_client_secret,
        authorization_details=None,
    ):
        authorization_details = authorization_details or []
        url = workspace_url + "/oidc/v1/token"
        headers = {"Content-Type": "application/x-www-form-urlencoded"}
        data = {
            "grant_type": "client_credentials",
            "scope": "all-apis",
            "authorization_details": authorization_details,
        }
        response = RequestUtils.issue_request(
            url=url,
            auth=(service_principal_client_id, service_principal_client_secret),
            headers=headers,
            method="POST",
            data=data,
        )
        return response


# maxsize is generous because the cache key now includes thread identity (see below): the
# working set scales with the number of concurrently-live threads, not a small constant. A
# large ThreadPoolExecutor would thrash a size-64 cache. Eviction only drops a connection
# pool (never affects correctness), but keeping live threads' sessions resident preserves
# HTTP keep-alive for realistic thread counts.
@lru_cache(maxsize=1024)
def _cached_get_request_session(
    total_retries,
    backoff_factor,
    backoff_jitter,
    # `process_id` and `thread_id` isolate the Session per (process, thread):
    # - process: a Session shared across processes breaks after fork (https://stackoverflow.com/q/3724900).
    # - thread: `requests.Session` is not thread-safe. Two threads sharing one Session can, under
    #   load and urllib3-level retries, have a response delivered to the wrong thread — returning a
    #   full but incorrect result set with no error (ES-2041784). Two concurrently-live threads always
    #   have distinct idents, so they never share a Session; idents reused after a thread exits are
    #   safe because the prior thread's Session has no remaining concurrent user.
    process_id,
    thread_id,
):
    session = requests.Session()

    # Check if urllib3 version supports backoff_jitter parameter
    urllib3_version = version.parse(urllib3.__version__)
    supports_backoff_jitter = urllib3_version >= version.parse("2.0.0")
    # Note: The Retry class automatically respects Retry-After headers in 429 and 503 responses.
    # If Retry-After is present, it takes precedence over the backoff_factor calculation.
    if supports_backoff_jitter:
        retry_strategy = Retry(
            total=total_retries,  # Total number of retries
            backoff_factor=backoff_factor,  # A backoff factor to apply between attempts
            backoff_jitter=backoff_jitter,
            status_forcelist=[429, 503, 504],  # HTTP status codes to retry on
        )
    else:
        retry_strategy = Retry(
            total=total_retries,  # Total number of retries
            backoff_factor=backoff_factor,  # A backoff factor to apply between attempts
            status_forcelist=[429, 503, 504],  # HTTP status codes to retry on
        )

    adapter = HTTPAdapter(max_retries=retry_strategy, pool_connections=50, pool_maxsize=50)
    session.mount("https://", adapter)
    session.mount("http://", adapter)
    return session


class RequestUtils:
    session = _cached_get_request_session(
        total_retries=3, backoff_factor=1, backoff_jitter=0.2, process_id=os.getpid(), thread_id=threading.get_ident()
    )

    @staticmethod
    def issue_request(
        url: str,
        method: str,
        token: Optional[str] = None,
        params: Optional[dict] = None,
        json: Optional[dict] = None,
        verify: bool = True,
        auth: Optional[tuple] = None,
        data: Optional[dict] = None,
        headers: Optional[dict] = None,
        total_retries: int = 3,
        backoff_factor: float = 1.0,
        backoff_jitter: float = 0.2,
    ):
        headers = headers or dict()
        if token:
            headers["Authorization"] = f"Bearer {token}"
        headers["X-Databricks-Python-SDK-Version"] = VERSION

        # Use custom session with the provided retry parameters. The session is isolated per
        # (process, thread) so concurrent callers never share a non-thread-safe requests.Session.
        session = _cached_get_request_session(
            total_retries=total_retries,
            backoff_factor=backoff_factor,
            backoff_jitter=backoff_jitter,
            process_id=os.getpid(),
            thread_id=threading.get_ident(),
        )

        response = session.request(
            url=url,
            headers=headers,
            method=method,
            params=params,
            json=json,
            verify=verify,
            auth=auth,
            data=data,
        )

        if not response.ok:
            status_code = response.status_code
            error_message = f"HTTP {status_code}"
            error_code = None
            details = None
            try:
                error_data = response.json()
                if isinstance(error_data, dict):
                    error_message = _format_error_message(error_data)
                    error_code = error_data.get("error_code")
                    details = error_data.get("details")
            except Exception:
                error_message = response.text or f"HTTP {status_code} error"
            raise exception_for_status(status_code)(
                error_message,
                status_code=status_code,
                response_content=response.content,
                error_code=error_code,
                details=details,
            )

        return response.json()


class UrlUtils:
    @staticmethod
    def add_https_if_missing(url):
        if not url.startswith("http://") and not url.startswith("https://"):
            url = "https://" + url
        return url


class CredentialStrategy(Enum):
    MODEL_SERVING_USER_CREDENTIALS = 1


def _get_invokers_token_fallback():
    main_thread = threading.main_thread()
    thread_data = main_thread.__dict__
    invokers_token = None
    if "invokers_token" in thread_data:
        invokers_token = thread_data["invokers_token"]
    return invokers_token


def _get_invokers_token_from_mlflowserving():
    try:
        from mlflowserving.scoring_server.agent_utils import fetch_obo_token

        return fetch_obo_token()
    except ImportError:
        return _get_invokers_token_fallback()


def get_model_serving_invoker_credentials():
    host = None
    invokers_token = None

    if is_in_model_serving_environment():
        host = os.environ.get("DATABRICKS_MODEL_SERVING_HOST_URL") or os.environ.get("DB_MODEL_SERVING_HOST_URL")

        invokers_token = _get_invokers_token_from_mlflowserving()

        if invokers_token is None:
            raise RuntimeError("Unable to read Invokers Token in Databricks Model Serving")

    return host, invokers_token


def is_in_model_serving_environment():
    """
    Check whether this is the model serving environment
    Additionally check if the oauth token file path exists
    """
    is_in_model_serving_env = (
        os.environ.get("IS_IN_DB_MODEL_SERVING_ENV") or os.environ.get("IS_IN_DATABRICKS_MODEL_SERVING_ENV") or "false"
    )
    return is_in_model_serving_env == "true"


def authentication_warning(notebook_token=None, personal_access_token=None, disable_notice=False):
    if not disable_notice:
        if notebook_token:
            print(
                """[NOTICE] Using a notebook authentication token. Recommended for development only. For improved performance, please use Service Principal based authentication. To disable this message, pass disable_notice=True."""
            )
        elif personal_access_token:
            print(
                """[NOTICE] Using a Personal Authentication Token (PAT). Recommended for development only. For improved performance, please use Service Principal based authentication. To disable this message, pass disable_notice=True."""
            )
