import json
import time
import datetime
import math
import threading
import deprecation
from typing import Optional, List, Dict, Any, Union
from databricks.ai_search.utils import OAuthTokenUtils
from databricks.ai_search.utils import RequestUtils
from databricks.ai_search.utils import UrlUtils
from databricks.ai_search.utils import CredentialStrategy
from databricks.ai_search.utils import normalize_response_keys_to_snake_case
from databricks.ai_search.reranker import (
    ExperimentalDatabricksFinetunedReranker,
    Reranker,
    _default_finetuned_endpoint_name,
)
from mlflow.utils import databricks_utils
from databricks.ai_search.utils import (
    authentication_warning,
    get_model_serving_invoker_credentials,
    _liteswap_headers,
)


class AISearchIndex:
    """
    AISearchIndex is a helper class that represents a AI Search Index.

    Those who wish to use this class should not instantiate it directly, but rather use the AISearchClient class.

    Thread safety: the data-plane query methods (e.g. ``similarity_search``) are safe to call
    concurrently from multiple threads, both on a single shared index object and on separate
    objects in the same process. The underlying HTTP session is isolated per thread and OAuth
    token refresh is serialized, so concurrent calls do not share connection state or race on
    token minting.
    """

    def __init__(
        self,
        workspace_url: str,
        index_url: str,
        name: str,
        endpoint_name: str,
        mlserving_endpoint_name: Optional[str] = None,
        personal_access_token: Optional[str] = None,
        service_principal_client_id: Optional[str] = None,
        service_principal_client_secret: Optional[str] = None,
        azure_tenant_id: Optional[str] = None,
        azure_login_id: Optional[str] = None,
        # whether or not credentials were explicitly passed in by user in client or inferred by client
        # via mlflow utilities. If passed in by user, continue to use user credentials. If not, can
        # attempt automatic auth refresh for model serving.
        use_user_passed_credentials: bool = False,
        credential_strategy: Optional[CredentialStrategy] = None,
        get_reranker_url_callable: Optional[callable] = None,
        mlserving_endpoint_name_for_query: Optional[str] = None,
        total_retries: int = 3,
        backoff_factor: float = 1,
        backoff_jitter: float = 0.2,
        _liteswap_traffic_id: Optional[str] = None,
    ):
        """
        Initialize a AISearchIndex instance.

        :param str workspace_url: The URL of the Databricks workspace.
        :param str index_url: The direct URL to the vector search index endpoint.
        :param str name: The name of the vector search index.
        :param str endpoint_name: The name of the vector search endpoint.
        :param str mlserving_endpoint_name: The name of the model serving endpoint used for embedding generation during ingestion.
        :param str personal_access_token: Personal access token for authentication.
        :param str service_principal_client_id: Service principal client ID for authentication.
        :param str service_principal_client_secret: Service principal client secret for authentication.
        :param str azure_tenant_id: Azure tenant ID for Azure-based authentication.
        :param str azure_login_id: Azure login ID (Databricks Azure Application ID) for authentication.
        :param bool use_user_passed_credentials: Whether credentials were explicitly provided by the user (True) or inferred automatically (False).
        :param CredentialStrategy credential_strategy: The credential strategy to use for authentication.
        :param callable get_reranker_url_callable: A callable function to retrieve the reranker-compatible index URL when needed.
        :param str mlserving_endpoint_name_for_query: The name of the model serving endpoint to use for queries (if different from ingestion endpoint).
        :param int total_retries: Total number of retries for requests. Defaults to 3.
        :param float backoff_factor: Backoff factor for retry delays. Defaults to 1.
        :param float backoff_jitter: Random jitter proportion (0-1) to add to backoff delays. Defaults to 0.2.
        """
        self.workspace_url = workspace_url
        self.name = name
        self.endpoint_name = endpoint_name
        self.personal_access_token = personal_access_token
        self.service_principal_client_id = service_principal_client_id
        self.service_principal_client_secret = service_principal_client_secret
        self.index_url = _get_index_url(
            index_url,
            self.workspace_url,
            self.name,
            self.personal_access_token,
            self.service_principal_client_id,
            self.service_principal_client_secret,
        )
        self._index_url_ensure_reranker_compatible = None
        self._get_reranker_url_callable = get_reranker_url_callable
        self.azure_tenant_id = azure_tenant_id
        self.azure_login_id = azure_login_id
        self._liteswap_traffic_id = _liteswap_traffic_id
        self._control_plane_oauth_token = None
        self._control_plane_oauth_token_expiry_ts = None
        self._read_oauth_token = None
        self._read_oauth_token_expiry_ts = None
        self._write_oauth_token = None
        self._write_oauth_token_expiry_ts = None
        # Serializes the check-and-refresh of the cached OAuth tokens above so a single index
        # object shared across threads mints a token once instead of racing (ES-2041784). Must be
        # initialized before the _get_mlserving_endpoint_id calls below, which read a token.
        self._token_refresh_lock = threading.Lock()
        self._use_user_passed_credentials = use_user_passed_credentials
        # Initialize `mlserving_endpoint_id` as `_get_token_for_request` (a dependency of `_get_mlserving_endpoint_id`)
        # may check the nullability of `mlserving_endpoint_id`
        self.mlserving_endpoint_id = self._get_mlserving_endpoint_id(mlserving_endpoint_name)
        self.mlserving_endpoint_id_for_query = self._get_mlserving_endpoint_id(mlserving_endpoint_name_for_query)
        self.credential_strategy = credential_strategy
        self._warned_on_deprecated_columns_to_rerank = False
        self.total_retries = total_retries
        self.backoff_factor = backoff_factor
        self.backoff_jitter = backoff_jitter
        # Cached on first call to _get_index_id() so finetuned-reranker payloads
        # don't pay a per-query describe() round-trip. The UUID is immutable for
        # the life of the index, so caching for the life of this client is safe.
        self._cached_index_id: Optional[str] = None

    def _get_mlserving_endpoint_id(self, mlserving_endpoint_name):
        if mlserving_endpoint_name is None:
            return None
        resp = RequestUtils.issue_request(
            url=f"{self.workspace_url}/api/2.0/serving-endpoints/{mlserving_endpoint_name}",
            method="GET",
            token=self._get_token_for_request(control_plane=True),
        )
        if resp.get("route_optimized", False):
            return resp["id"]
        else:
            return None

    def _get_token_for_request(self, write=False, control_plane=False, index_url=None):
        try:
            # automatically refresh auth if not passed in by user and in model serving environment
            if not self._use_user_passed_credentials and databricks_utils.is_in_databricks_model_serving_environment():
                if self.credential_strategy == CredentialStrategy.MODEL_SERVING_USER_CREDENTIALS:
                    _, token = get_model_serving_invoker_credentials()
                    return token
                else:
                    return databricks_utils.get_databricks_host_creds().token
        except Exception:
            # Faile to read credentials from model serving environment failed and we will default
            # to cached vector search token
            pass

        if self.personal_access_token:  # PAT flow
            return self.personal_access_token
        # Detect control-plane requests via URL matching, but only when the
        # caller has not already forced control_plane=True (e.g. reranker path).
        if not control_plane:
            if (index_url is None and self.workspace_url in self.index_url) or (
                index_url is not None and self.workspace_url in index_url
            ):
                control_plane = True
        # Serialize the check-and-refresh of the cached SP-OAuth tokens. Under the lock the first
        # thread to observe an expired/missing token mints it; threads that were waiting re-observe
        # the now-fresh cached value via the checks below and return without minting again. Reads and
        # writes of the shared token fields all happen here, so the check and the store never tear.
        with self._token_refresh_lock:
            if (
                control_plane
                and self._control_plane_oauth_token
                and self._control_plane_oauth_token_expiry_ts
                and self._control_plane_oauth_token_expiry_ts - 100 > time.time()
            ):
                return self._control_plane_oauth_token
            if (
                write
                and not control_plane
                and self._write_oauth_token
                and self._write_oauth_token_expiry_ts
                and self._write_oauth_token_expiry_ts - 100 > time.time()
            ):
                return self._write_oauth_token
            if (
                not write
                and not control_plane
                and self._read_oauth_token
                and self._read_oauth_token_expiry_ts
                and self._read_oauth_token_expiry_ts - 100 > time.time()
            ):
                return self._read_oauth_token
            if self.service_principal_client_id and self.service_principal_client_secret:
                if control_plane:
                    authorization_details = []
                else:
                    details = [
                        {
                            "type": "unity_catalog_permission",
                            "securable_type": "table",
                            "securable_object_name": self.name,
                            "operation": ("WriteVectorIndex" if write else "ReadVectorIndex"),
                        }
                    ]
                    endpoint_ids = [self.mlserving_endpoint_id]
                    # Queries may embed with the query model; keep the ingestion entry for servers that don't.
                    if not write and self.mlserving_endpoint_id_for_query != self.mlserving_endpoint_id:
                        endpoint_ids.append(self.mlserving_endpoint_id_for_query)
                    for endpoint_id in endpoint_ids:
                        if endpoint_id:
                            details.append(
                                {
                                    "type": "workspace_permission",
                                    "object_type": "serving-endpoints",
                                    "object_path": "/serving-endpoints/" + endpoint_id,
                                    "actions": ["query_inference_endpoint"],
                                }
                            )
                    authorization_details = json.dumps(details)
                oauth_token_data = (
                    OAuthTokenUtils.get_oauth_token(
                        workspace_url=self.workspace_url,
                        service_principal_client_id=self.service_principal_client_id,
                        service_principal_client_secret=self.service_principal_client_secret,
                        authorization_details=authorization_details,
                    )
                    if not self.azure_tenant_id
                    else OAuthTokenUtils.get_azure_oauth_token(
                        workspace_url=self.workspace_url,
                        service_principal_client_id=self.service_principal_client_id,
                        service_principal_client_secret=self.service_principal_client_secret,
                        authorization_details=authorization_details,
                        azure_tenant_id=self.azure_tenant_id,
                        azure_login_id=self.azure_login_id,
                    )
                )
                if control_plane:
                    self._control_plane_oauth_token = oauth_token_data["access_token"]
                    self._control_plane_oauth_token_expiry_ts = time.time() + float(oauth_token_data["expires_in"])
                    return self._control_plane_oauth_token
                if write:
                    self._write_oauth_token = oauth_token_data["access_token"]
                    self._write_oauth_token_expiry_ts = time.time() + float(oauth_token_data["expires_in"])
                    return self._write_oauth_token
                self._read_oauth_token = oauth_token_data["access_token"]
                self._read_oauth_token_expiry_ts = time.time() + float(oauth_token_data["expires_in"])
                return self._read_oauth_token
        raise Exception("You must specify service principal or PAT token")

    def _request_headers(self):
        return _liteswap_headers(self._liteswap_traffic_id)

    def _issue_request(self, **kwargs):
        headers = self._request_headers()
        if headers:
            kwargs["headers"] = headers
        return RequestUtils.issue_request(**kwargs)

    def _build_query_payload(
        self,
        columns,
        query_text=None,
        query_vector=None,
        filters=None,
        num_results=5,
        debug_level=0,
        score_threshold=None,
        query_type=None,
        columns_to_rerank=None,
        disable_notice=False,
        reranker=None,
        query_columns=None,
        sort_columns=None,
        facets=None,
        _query_experiment_config=None,
        _query_source=None,
    ):
        """Validate args and assemble the similarity_search request body.

        Pure (no I/O) so both sync and async paths can call it directly.
        Returns ``(json_data, resolved_columns_to_rerank)`` — the second is
        the value to feed into :py:meth:`_resolve_query_url`.
        """
        authentication_warning(
            not self._use_user_passed_credentials,
            self.personal_access_token,
            disable_notice,
        )
        if columns_to_rerank and reranker is not None:
            raise ValueError("The arguments `columns_to_rerank` and `reranker` cannot both be provided.")
        if columns_to_rerank:
            if not self._warned_on_deprecated_columns_to_rerank:
                print(
                    "[NOTICE] The argument `columns_to_rerank` is deprecated. Use the `reranker` argument instead: `from databricks.ai_search.reranker import DatabricksReranker; index.similarity_search(..., reranker=DatabricksReranker(columns_to_rerank=[...]))`."
                )
            self._warned_on_deprecated_columns_to_rerank = True
        reranker_block = None
        if reranker is not None:
            if isinstance(reranker, ExperimentalDatabricksFinetunedReranker):
                endpoint = reranker.endpoint_name or _default_finetuned_endpoint_name(self.name, self._get_index_id())
                reranker_block = {
                    "model": endpoint,
                    "model_type": "MODEL_TYPE_FINETUNED",
                    "parameters": {"columns_to_rerank": reranker.columns_to_rerank},
                }
            else:
                # DatabricksReranker.
                reranker_block = {
                    "model": "databricks_reranker",
                    "model_type": "MODEL_TYPE_BASE",
                    "parameters": {"columns_to_rerank": reranker.columns_to_rerank},
                }
        elif columns_to_rerank:
            # Deprecated columns_to_rerank kwarg: emit the same wire shape as
            # DatabricksReranker so the backend always reads from `reranker`.
            reranker_block = {
                "model": "databricks_reranker",
                "model_type": "MODEL_TYPE_BASE",
                "parameters": {"columns_to_rerank": columns_to_rerank},
            }

        if isinstance(filters, str):
            filter_string = filters
            filters_json = None
        else:
            filter_string = None
            filters_json = json.dumps(filters) if filters else None
        json_data = {
            "num_results": num_results,
            "columns": columns,
            "filters_json": filters_json,
            "filter_string": filter_string,
            "debug_level": debug_level,
        }
        if query_text:
            json_data["query_text"] = query_text
        if query_vector:
            json_data["query_vector"] = query_vector
        if score_threshold:
            json_data["score_threshold"] = score_threshold
        if query_type:
            json_data["query_type"] = query_type
        if query_columns:
            json_data["query_columns"] = query_columns
        if sort_columns:
            json_data["sort_columns"] = sort_columns
        if facets:
            json_data["facets"] = facets
        if reranker_block is not None:
            json_data["reranker"] = reranker_block
        if _query_experiment_config:
            json_data["query_experiment_config"] = _query_experiment_config
        if _query_source:
            json_data["query_source"] = _query_source
        is_reranker = reranker_block is not None
        return json_data, is_reranker

    def _resolve_query_url(self, is_reranker):
        """Return the URL to send the query to, fetching reranker URL if needed.

        Performs I/O via ``_get_reranker_url_callable`` on first reranker use,
        which is why the async path wraps this in :func:`asyncio.to_thread`.
        Result is memoized in ``_index_url_ensure_reranker_compatible``.
        """
        if not is_reranker:
            return self.index_url
        if self._index_url_ensure_reranker_compatible is None:
            if self._get_reranker_url_callable:
                index_url_raw = self._get_reranker_url_callable()
                self._index_url_ensure_reranker_compatible = _get_index_url(
                    index_url_raw,
                    self.workspace_url,
                    self.name,
                    self.personal_access_token,
                    self.service_principal_client_id,
                    self.service_principal_client_secret,
                )
            else:
                self._index_url_ensure_reranker_compatible = self.index_url
        return self._index_url_ensure_reranker_compatible

    def _build_scan_payload(self, num_results, last_primary_key):
        json_data = {
            "num_results": num_results,
            "endpoint_name": self.endpoint_name,
        }
        if last_primary_key:
            json_data["last_primary_key"] = last_primary_key
        return json_data

    def _build_next_page_payload(self, page_token):
        return {
            "page_token": page_token,
            "endpoint_name": self.endpoint_name,
        }

    def _build_upsert_payload(self, inputs):
        assert isinstance(inputs, list), "inputs must be of type: List of dictionaries"
        assert all(isinstance(i, dict) for i in inputs), "inputs must be of type: List of dicts"
        return {"inputs_json": json.dumps(inputs)}

    def _build_delete_payload(self, primary_keys):
        assert isinstance(primary_keys, list), "inputs must be of type: List"
        return {"primary_keys": primary_keys}

    def upsert(self, inputs):
        """
        Upsert data into the index.

        :param inputs: List of dictionaries to upsert into the index.
        """
        return self._issue_request(
            url=f"{self.index_url}/upsert-data",
            token=self._get_token_for_request(write=True),
            method="POST",
            json=self._build_upsert_payload(inputs),
        )

    def delete(self, primary_keys):
        """
        Delete data from the index.

        :param primary_keys: List of primary keys to delete from the index.
        """
        return self._issue_request(
            url=f"{self.index_url}/delete-data",
            token=self._get_token_for_request(write=True),
            method="DELETE",
            json=self._build_delete_payload(primary_keys),
        )

    def describe(self):
        """
        Describe the index. This returns metadata about the index.
        """
        return self._issue_request(
            url=f"{self.workspace_url}/api/2.0/vector-search/indexes/{self.name}",
            token=self._get_token_for_request(control_plane=True),
            method="GET",
        )

    def _get_index_id(self) -> str:
        """Return the UC table UUID for this index, fetching once and caching.

        Used to derive the default finetuned reranker endpoint name when callers
        pass ``ExperimentalDatabricksFinetunedReranker(endpoint_name=None)``.
        The first call issues a control-plane ``describe()`` to read the ``id``
        field; subsequent calls return the cached value with no network round-
        trip.

        Raises ``ValueError`` if ``describe()`` does not return an ``id`` field
        (e.g. partial response from an API error), since a missing UUID would
        otherwise propagate as a cryptic ``AttributeError`` from the downstream
        ``str.replace`` in ``_default_finetuned_endpoint_name``.
        """
        if self._cached_index_id is None:
            index_id = self.describe().get("id")
            if not index_id:
                raise ValueError(
                    f"describe() did not return an 'id' for index '{self.name}'; "
                    "cannot derive default finetuned reranker endpoint name"
                )
            self._cached_index_id = index_id
        return self._cached_index_id

    def sync(self):
        """
        Sync the index. This is used to sync the index with the source delta table.
        This only works with managed delta sync index with pipeline type="TRIGGERED".
        """
        return self._issue_request(
            url=f"{self.workspace_url}/api/2.0/vector-search/indexes/{self.name}/sync",
            token=self._get_token_for_request(control_plane=True),
            method="POST",
        )

    def similarity_search(
        self,
        columns: List[str],
        query_text: Optional[str] = None,
        query_vector: Optional[List[float]] = None,
        filters: Optional[Union[str, Dict[str, Any]]] = None,
        num_results: int = 5,
        debug_level: int = 0,
        score_threshold: Optional[float] = None,
        query_type: Optional[str] = None,
        columns_to_rerank: Optional[List[str]] = None,
        disable_notice: bool = False,
        reranker: Optional[Reranker] = None,
        total_retries: int = 3,
        backoff_factor: float = 1,
        backoff_jitter: float = 0.2,
        *,
        query_columns: Optional[List[str]] = None,
        sort_columns: Optional[List[str]] = None,
        facets: Optional[List[str]] = None,
        _query_experiment_config: Optional[Dict[str, Any]] = None,
        _query_source: Optional[str] = None,
    ):
        """similarity_search(columns: List[str], query_text: Optional[str] = None, query_vector: Optional[List[float]] = None, filters: Optional[Union[str, Dict[str, Any]]] = None, num_results: int = 5, debug_level: int = 0, score_threshold: Optional[float] = None, query_type: Optional[str] = None, columns_to_rerank: Optional[List[str]] = None, disable_notice: bool = False, reranker: Optional[Reranker] = None, total_retries: int = 3, backoff_factor: float = 1, backoff_jitter: float = 0.2, query_columns: Optional[List[str]] = None, sort_columns: Optional[List[str]] = None, facets: Optional[List[str]] = None)

        Perform a similarity search on the index. This returns the top K results that are most similar to the query.

        :param columns: List of column names to return in the results.
        :param query_text: Query text to search for.
        :param query_vector: Query vector to search for.
        :param filters: Filters to apply to the query.
        :param num_results: Number of results to return.
        :param debug_level: Debug level to use for the query.
        :param score_threshold: Score threshold to use for the query. If reranker is used, the score threshold is applied before reranking.
        :param query_type: Query type of this query. Choices are "ANN", "HYBRID", and "FULL_TEXT".
        :param query_columns: Text columns to search for query_text. When empty, all text columns are searched.
        :param sort_columns: Sort results by column values instead of the default relevance ordering. Each clause has the form "<column> ASC" or "<column> DESC", for example ["rating DESC", "price ASC"].
        :param facets: Facets to compute over the matched results. Each entry is one of: "<column>" (top 10 distinct values by count), "<column> TOP <n>" (top n distinct values, n > 0), or "<column> BUCKETS [[from,to],...]" (inclusive numeric ranges). TOP and BUCKETS are case-insensitive; a column may appear at most once.
        :param columns_to_rerank: (Deprecated) List of column names to use for reranking the results.
            Use the ``reranker`` parameter instead.
        :param disable_notice: Whether to disable the notice message.
        :param reranker: Optional reranker to apply on the top results. Pass an instance of
            :class:`databricks.ai_search.reranker.DatabricksReranker` with
            ``columns_to_rerank=[...]``. The reranker reorders the initial results using
            the specified text columns.
        :type reranker: Optional[:class:`databricks.ai_search.reranker.Reranker`]
        :param total_retries: Total number of retries for the request. Set to 0 to disable retries.
        :param backoff_factor: Backoff factor to apply between retry attempts. The delay between retries
            is calculated as {backoff_factor} * (2 ** (retry_count - 1)) seconds. For example, with
            backoff_factor=1, delays are 0.5s, 1s, 2s, 4s, etc.
        :param backoff_jitter: Random jitter to add to backoff delays to avoid thundering herd problem.
            Value between 0 and 1 representing the proportion of jitter to apply.

        This method is thread-safe: it may be called concurrently from multiple threads (for example
        a ``pandas_udf`` fanning out queries with a ``ThreadPoolExecutor``), whether the threads share
        one index object or use separate ones in the same process.

        Example:
            Use the Databricks reranker to improve the ordering of hybrid search results:

            .. code-block:: python

                from databricks.ai_search.reranker import DatabricksReranker

                results = index.similarity_search(
                    query_text=\"How to create a AI Search index\",
                    columns=[\"id\", \"text\", \"parent_doc_summary\", \"date\"],
                    # The final number of results to return. The reranker will automatically overfetch 50 documents and rerank them.
                    num_results=10,
                    query_type=\"hybrid\",
                    # Needed for debug info to get any warnings and time to rerank the results.
                    debug_level=1,
                    # The text reranked will be concatenated and if it is longer than 2000 characters, it will be truncated.
                    # Include shorter, important columns first.
                    reranker=DatabricksReranker(columns_to_rerank=[\"parent_doc_summary\", \"text\", \"other_column\"]),
                )
                # Check if reranking was successful and how much additional time it took to rerank the results.
                if "warnings" in results['debug_info']:
                    print(results['debug_info']['warnings'])
                else:
                    print(f"Reranking was successful and took {results['debug_info']['reranker_time']}ms")
        """
        json_data, is_reranker = self._build_query_payload(
            columns=columns,
            query_text=query_text,
            query_vector=query_vector,
            filters=filters,
            num_results=num_results,
            debug_level=debug_level,
            score_threshold=score_threshold,
            query_type=query_type,
            columns_to_rerank=columns_to_rerank,
            disable_notice=disable_notice,
            reranker=reranker,
            query_columns=query_columns,
            sort_columns=sort_columns,
            facets=facets,
            _query_experiment_config=_query_experiment_config,
            _query_source=_query_source,
        )
        query_url = self._resolve_query_url(is_reranker)

        response = self._issue_request(
            url=f"{query_url}/query",
            token=self._get_token_for_request(
                index_url=query_url,
                control_plane=is_reranker,
            ),
            method="GET",
            json=json_data,
            total_retries=total_retries,
            backoff_factor=backoff_factor,
            backoff_jitter=backoff_jitter,
        )
        # Direct-DP responses (Rust vector-store) are camelCase per proto3 JSON spec;
        # CP-routed responses (Scala) are snake_case. Normalize so the loop below works
        # against either backend.
        response = normalize_response_keys_to_snake_case(response)

        out_put = response
        while response.get("next_page_token"):
            response = self.__get_next_page(query_url, response["next_page_token"], control_plane=is_reranker)
            out_put["result"]["row_count"] += response["result"]["row_count"]
            out_put["result"]["data_array"] += response["result"]["data_array"]

        out_put.pop("next_page_token", None)
        return out_put

    def wait_until_ready(
        self,
        verbose=False,
        timeout=datetime.timedelta(hours=24),
        wait_for_updates=False,
    ):
        """
        Wait for the index to be online.

        :param bool verbose: Whether to print status messages.
        :param datetime.timedelta timeout: The time allowed until we timeout with an Exception.
        :param bool wait_for_updates: If true, the index will also wait for any updates to be completed.
        """

        def get_index_state():
            return self.describe()["status"]["detailed_state"]

        def is_index_state_ready(index_state):
            if "ONLINE" not in index_state:
                return False
            if not wait_for_updates:
                # It is enough to wait for any online state.
                return True
            # Now check if current online state is an update state.
            return index_state in [
                "ONLINE",
                "ONLINE_NO_PENDING_UPDATE",
                "ONLINE_DIRECT_ACCESS",
            ]

        start_time = datetime.datetime.now()
        sleep_time_seconds = 30
        # Online states all contain `ONLINE`.
        # Provisioning states all contain `PROVISIONING`
        # Offline states all contain `OFFLINE`.
        index_state = get_index_state()
        while not is_index_state_ready(index_state) and datetime.datetime.now() - start_time < timeout:
            if "OFFLINE" in index_state:
                raise Exception(f"Index {self.name} is offline")
            if verbose:
                running_time = int(math.floor((datetime.datetime.now() - start_time).total_seconds()))
                print(f"Index {self.name} is in state {index_state}. Time: {running_time}s.")
            time.sleep(sleep_time_seconds)
            index_state = get_index_state()
        if verbose:
            print(f"Index {self.name} is in state {index_state}.")
        if not is_index_state_ready(index_state):
            raise Exception(f"Index {self.name} did not become online within timeout of {timeout.total_seconds()}s.")

    def scan(self, num_results=10, last_primary_key=None):
        """
        Given all the data in the index sorted by primary key, this returns the next
        `num_results` data after the primary key specified by `last_primary_key`.
        If last_primary_key is None , it returns the first `num_results`.

        Please note if there's ongoing updates to the index, the scan results may not be consistent.

        :param num_results: Number of results to return.
        :param last_primary_key: last primary key from previous pagination, it will be used as the exclusive starting primary key.
        """
        response = self._issue_request(
            url=self.index_url + "/scan",
            token=self._get_token_for_request(),
            method="GET",
            json=self._build_scan_payload(num_results, last_primary_key),
        )
        return normalize_response_keys_to_snake_case(response)

    @deprecation.deprecated(
        deprecated_in="0.36",
        removed_in="0.37",
        current_version="0.36",
        details="Use the scan function instead",
    )
    def scan_index(self, num_results=10, last_primary_key=None):
        return self.scan(num_results, last_primary_key)

    def __get_next_page(self, index_url, page_token, control_plane=False):
        """
        Get the next page of results from a page token.
        """
        response = self._issue_request(
            url=index_url + "/query-next-page",
            token=self._get_token_for_request(control_plane=control_plane),
            method="GET",
            json=self._build_next_page_payload(page_token),
        )
        return normalize_response_keys_to_snake_case(response)


def _get_index_url(
    index_url,
    workspace_url,
    index_name,
    personal_access_token,
    service_principal_client_id,
    service_principal_client_secret,
):
    cp_url = workspace_url + f"/api/2.0/vector-search/indexes/{index_name}"
    if personal_access_token and not (service_principal_client_id and service_principal_client_secret):
        return cp_url
    elif index_url:
        return UrlUtils.add_https_if_missing(index_url)
    else:
        # Fallback to CP
        return cp_url


# Backward-compat alias for the AI Search rebrand. The canonical class is
# AISearchIndex; VectorSearchIndex is the same class accessible under the
# legacy name.
VectorSearchIndex = AISearchIndex
