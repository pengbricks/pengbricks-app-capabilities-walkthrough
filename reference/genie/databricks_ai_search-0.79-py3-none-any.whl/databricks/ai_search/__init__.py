from databricks.ai_search.version import VERSION as __version__

__all__ = ["__version__"]
