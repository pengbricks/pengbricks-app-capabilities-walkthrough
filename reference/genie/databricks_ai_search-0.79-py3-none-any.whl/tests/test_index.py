"""Tests for databricks.ai_search.index.AISearchIndex."""

import json
import threading
import time
from unittest.mock import patch

import pytest

from databricks.ai_search.index import _get_index_url
from databricks.ai_search.index import AISearchIndex
from databricks.ai_search.reranker import DatabricksReranker


class TestUpsert:
    @patch("databricks.ai_search.index.RequestUtils.issue_request")
    def test_upsert_posts_inputs_json(self, mock_req, ai_search_index_factory):
        idx = ai_search_index_factory()
        mock_req.return_value = {"ok": True}
        idx.upsert([{"id": 1, "text": "a"}])
        call = mock_req.call_args.kwargs
        assert call["method"] == "POST"
        assert call["url"].endswith("/upsert-data")
        body = call["json"]
        # _build_upsert_payload JSON-encodes inputs into inputs_json.
        assert json.loads(body["inputs_json"]) == [{"id": 1, "text": "a"}]

    def test_upsert_requires_list(self, ai_search_index_factory):
        idx = ai_search_index_factory()
        with pytest.raises(AssertionError):
            idx.upsert({"id": 1})

    def test_upsert_requires_list_of_dicts(self, ai_search_index_factory):
        idx = ai_search_index_factory()
        with pytest.raises(AssertionError):
            idx.upsert([1, 2, 3])


class TestDelete:
    @patch("databricks.ai_search.index.RequestUtils.issue_request")
    def test_delete_uses_delete_method_and_sends_primary_keys(self, mock_req, ai_search_index_factory):
        idx = ai_search_index_factory()
        mock_req.return_value = {"ok": True}
        idx.delete(["a", "b", "c"])
        call = mock_req.call_args.kwargs
        assert call["method"] == "DELETE"
        assert call["url"].endswith("/delete-data")
        assert call["json"] == {"primary_keys": ["a", "b", "c"]}

    def test_delete_requires_list(self, ai_search_index_factory):
        idx = ai_search_index_factory()
        with pytest.raises(AssertionError):
            idx.delete("not-a-list")


class TestDescribe:
    @patch("databricks.ai_search.index.RequestUtils.issue_request")
    def test_describe_hits_control_plane_url(self, mock_req, ai_search_index_factory, workspace_url):
        idx = ai_search_index_factory()
        mock_req.return_value = {"name": "cat.sch.idx"}
        idx.describe()
        call = mock_req.call_args.kwargs
        assert call["method"] == "GET"
        assert call["url"] == (f"{workspace_url}/api/2.0/vector-search/indexes/cat.sch.idx")


class TestSync:
    @patch("databricks.ai_search.index.RequestUtils.issue_request")
    def test_sync_posts_to_sync_url(self, mock_req, ai_search_index_factory, workspace_url):
        idx = ai_search_index_factory()
        mock_req.return_value = {"ok": True}
        idx.sync()
        call = mock_req.call_args.kwargs
        assert call["method"] == "POST"
        assert call["url"] == (f"{workspace_url}/api/2.0/vector-search/indexes/cat.sch.idx/sync")


class TestScan:
    @patch("databricks.ai_search.index.RequestUtils.issue_request")
    def test_scan_builds_payload(self, mock_req, ai_search_index_factory):
        idx = ai_search_index_factory()
        mock_req.return_value = {"results": []}
        idx.scan(num_results=20, last_primary_key="pk-7")
        call = mock_req.call_args.kwargs
        assert call["method"] == "GET"
        assert call["url"].endswith("/scan")
        body = call["json"]
        assert body["num_results"] == 20
        assert body["last_primary_key"] == "pk-7"
        assert body["endpoint_name"] == "test-endpoint"

    @patch("databricks.ai_search.index.RequestUtils.issue_request")
    def test_scan_without_last_primary_key_omits_field(self, mock_req, ai_search_index_factory):
        idx = ai_search_index_factory()
        mock_req.return_value = {"results": []}
        idx.scan(num_results=10)
        body = mock_req.call_args.kwargs["json"]
        assert "last_primary_key" not in body


class TestScanIndexDeprecation:
    def test_scan_index_attribute_exists(self, ai_search_index_factory):
        # `deprecation` is mocked at import time so the decorator wraps the
        # method in a MagicMock — calling it doesn't reach the real `scan`.
        # We can still assert the attribute is present, which is what the
        # deprecation path is supposed to leave behind for back-compat.
        idx = ai_search_index_factory()
        assert hasattr(idx, "scan_index")
        assert callable(idx.scan_index)


class TestSimilaritySearch:
    @patch("databricks.ai_search.index.RequestUtils.issue_request")
    def test_internal_liteswap_traffic_id_is_sent_on_query_pages(self, mock_req, workspace_url):
        idx = AISearchIndex(
            workspace_url=workspace_url,
            index_url="https://dp/idx",
            name="cat.sch.idx",
            endpoint_name="test-endpoint",
            personal_access_token="test-pat-token",
            _liteswap_traffic_id="testenv://liteswap/my-unit",
        )
        mock_req.side_effect = [
            {
                "result": {"row_count": 1, "data_array": [[1]]},
                "next_page_token": "tok-1",
            },
            {
                "result": {"row_count": 1, "data_array": [[2]]},
                "next_page_token": None,
            },
        ]

        idx.similarity_search(columns=["id"], query_text="x", disable_notice=True)

        assert mock_req.call_count == 2
        for call in mock_req.call_args_list:
            assert call.kwargs["headers"] == {"x-databricks-traffic-id": "testenv://liteswap/my-unit"}

    @patch("databricks.ai_search.index.RequestUtils.issue_request")
    def test_query_text_path(self, mock_req, ai_search_index_factory):
        idx = ai_search_index_factory()
        mock_req.return_value = {"result": {"row_count": 0, "data_array": []}}
        idx.similarity_search(columns=["id"], query_text="hello", disable_notice=True)
        body = mock_req.call_args.kwargs["json"]
        assert body["query_text"] == "hello"
        assert "query_vector" not in body

    @patch("databricks.ai_search.index.RequestUtils.issue_request")
    def test_query_vector_path(self, mock_req, ai_search_index_factory):
        idx = ai_search_index_factory()
        mock_req.return_value = {"result": {"row_count": 0, "data_array": []}}
        idx.similarity_search(columns=["id"], query_vector=[0.1, 0.2], disable_notice=True)
        body = mock_req.call_args.kwargs["json"]
        assert body["query_vector"] == [0.1, 0.2]
        assert "query_text" not in body

    @patch("databricks.ai_search.index.RequestUtils.issue_request")
    def test_internal_query_source_is_omitted_by_default_and_sent_when_set(self, mock_req, ai_search_index_factory):
        idx = ai_search_index_factory()
        mock_req.return_value = {"result": {"row_count": 0, "data_array": []}}

        idx.similarity_search(columns=["id"], query_text="customer", disable_notice=True)
        assert "query_source" not in mock_req.call_args.kwargs["json"]

        idx.similarity_search(
            columns=["id"],
            query_text="generated",
            disable_notice=True,
            _query_source="SEARCH_QUALITY_EVAL",
        )
        assert mock_req.call_args.kwargs["json"]["query_source"] == "SEARCH_QUALITY_EVAL"

    @patch("databricks.ai_search.index.RequestUtils.issue_request")
    def test_filters_as_string_uses_filter_string(self, mock_req, ai_search_index_factory):
        idx = ai_search_index_factory()
        mock_req.return_value = {"result": {"row_count": 0, "data_array": []}}
        idx.similarity_search(columns=["id"], query_text="x", filters="a > 5", disable_notice=True)
        body = mock_req.call_args.kwargs["json"]
        assert body["filter_string"] == "a > 5"
        assert body["filters_json"] is None

    @patch("databricks.ai_search.index.RequestUtils.issue_request")
    def test_filters_as_dict_serialized_to_json(self, mock_req, ai_search_index_factory):
        idx = ai_search_index_factory()
        mock_req.return_value = {"result": {"row_count": 0, "data_array": []}}
        idx.similarity_search(
            columns=["id"],
            query_text="x",
            filters={"a": "b"},
            disable_notice=True,
        )
        body = mock_req.call_args.kwargs["json"]
        assert json.loads(body["filters_json"]) == {"a": "b"}
        assert body["filter_string"] is None

    @patch("databricks.ai_search.index.RequestUtils.issue_request")
    def test_score_threshold_and_query_type_only_when_truthy(self, mock_req, ai_search_index_factory):
        idx = ai_search_index_factory()
        mock_req.return_value = {"result": {"row_count": 0, "data_array": []}}
        idx.similarity_search(columns=["id"], query_text="x", disable_notice=True)
        body = mock_req.call_args.kwargs["json"]
        assert "score_threshold" not in body
        assert "query_type" not in body

        idx.similarity_search(
            columns=["id"],
            query_text="x",
            score_threshold=0.5,
            query_type="HYBRID",
            disable_notice=True,
        )
        body = mock_req.call_args.kwargs["json"]
        assert body["score_threshold"] == 0.5
        assert body["query_type"] == "HYBRID"

    @patch("databricks.ai_search.index.RequestUtils.issue_request")
    def test_advanced_fts_fields_only_when_provided(self, mock_req, ai_search_index_factory):
        idx = ai_search_index_factory()
        mock_req.return_value = {"result": {"row_count": 0, "data_array": []}}
        idx.similarity_search(columns=["id"], query_text="x", disable_notice=True)
        body = mock_req.call_args.kwargs["json"]
        assert "query_columns" not in body
        assert "sort_columns" not in body
        assert "facets" not in body

        idx.similarity_search(
            columns=["id"],
            query_text="x",
            query_columns=["title", "body"],
            sort_columns=["rating DESC"],
            facets=["brand", "category TOP 5"],
            disable_notice=True,
        )
        body = mock_req.call_args.kwargs["json"]
        assert body["query_columns"] == ["title", "body"]
        assert body["sort_columns"] == ["rating DESC"]
        assert body["facets"] == ["brand", "category TOP 5"]

    @patch("databricks.ai_search.index.RequestUtils.issue_request")
    def test_columns_to_rerank_legacy_path_sets_reranker_block(self, mock_req, ai_search_index_factory, capsys):
        idx = ai_search_index_factory()
        mock_req.return_value = {"result": {"row_count": 0, "data_array": []}}
        idx.similarity_search(
            columns=["id"],
            query_text="x",
            columns_to_rerank=["text"],
            disable_notice=True,
        )
        body = mock_req.call_args.kwargs["json"]
        assert body["reranker"]["model"] == "databricks_reranker"
        assert body["reranker"]["model_type"] == "MODEL_TYPE_BASE"
        assert body["reranker"]["parameters"]["columns_to_rerank"] == ["text"]
        # First call prints the deprecation notice.
        out = capsys.readouterr().out
        assert "deprecated" in out.lower()

    @patch("databricks.ai_search.index.RequestUtils.issue_request")
    def test_columns_to_rerank_deprecation_notice_only_once(self, mock_req, ai_search_index_factory, capsys):
        idx = ai_search_index_factory()
        mock_req.return_value = {"result": {"row_count": 0, "data_array": []}}
        idx.similarity_search(
            columns=["id"],
            query_text="x",
            columns_to_rerank=["text"],
            disable_notice=True,
        )
        capsys.readouterr()  # drain first warning
        idx.similarity_search(
            columns=["id"],
            query_text="x",
            columns_to_rerank=["text"],
            disable_notice=True,
        )
        assert capsys.readouterr().out == ""

    @patch("databricks.ai_search.index.RequestUtils.issue_request")
    def test_reranker_arg_sets_reranker_block(self, mock_req, ai_search_index_factory, capsys):
        idx = ai_search_index_factory()
        mock_req.return_value = {"result": {"row_count": 0, "data_array": []}}
        idx.similarity_search(
            columns=["id"],
            query_text="x",
            reranker=DatabricksReranker(columns_to_rerank=["text"]),
            disable_notice=True,
        )
        body = mock_req.call_args.kwargs["json"]
        assert body["reranker"]["model"] == "databricks_reranker"
        assert body["reranker"]["parameters"]["columns_to_rerank"] == ["text"]
        # No deprecation notice for the new path.
        assert "deprecated" not in capsys.readouterr().out.lower()

    def test_both_columns_to_rerank_and_reranker_raises(self, ai_search_index_factory):
        idx = ai_search_index_factory()
        with pytest.raises(ValueError, match="cannot both be provided"):
            idx.similarity_search(
                columns=["id"],
                query_text="x",
                columns_to_rerank=["a"],
                reranker=DatabricksReranker(columns_to_rerank=["b"]),
                disable_notice=True,
            )

    @patch("databricks.ai_search.index.RequestUtils.issue_request")
    def test_pagination_accumulates_results(self, mock_req, ai_search_index_factory):
        idx = ai_search_index_factory()
        mock_req.side_effect = [
            {
                "result": {"row_count": 2, "data_array": [[1], [2]]},
                "next_page_token": "tok-1",
            },
            {
                "result": {"row_count": 1, "data_array": [[3]]},
                "next_page_token": None,
            },
        ]
        result = idx.similarity_search(columns=["id"], query_text="x", disable_notice=True)
        assert result["result"]["row_count"] == 3
        assert result["result"]["data_array"] == [[1], [2], [3]]
        assert "next_page_token" not in result


class TestWaitUntilReady:
    @patch("databricks.ai_search.index.time.sleep")
    @patch("databricks.ai_search.index.RequestUtils.issue_request")
    def test_polls_until_online(self, mock_req, _sleep, ai_search_index_factory):
        idx = ai_search_index_factory()
        mock_req.side_effect = [
            {"status": {"detailed_state": "PROVISIONING"}},
            {"status": {"detailed_state": "ONLINE_NO_PENDING_UPDATE"}},
        ]
        idx.wait_until_ready()
        assert mock_req.call_count == 2

    @patch("databricks.ai_search.index.time.sleep")
    @patch("databricks.ai_search.index.RequestUtils.issue_request")
    def test_raises_on_offline(self, mock_req, _sleep, ai_search_index_factory):
        idx = ai_search_index_factory()
        mock_req.return_value = {"status": {"detailed_state": "OFFLINE_FAILED"}}
        with pytest.raises(Exception, match="offline"):
            idx.wait_until_ready()


class TestGetIndexUrl:
    """Module-level `_get_index_url` URL routing."""

    def test_pat_only_returns_control_plane_url(self):
        url = _get_index_url(
            index_url="https://dp/idx",
            workspace_url="https://ws",
            index_name="cat.sch.idx",
            personal_access_token="pat",
            service_principal_client_id=None,
            service_principal_client_secret=None,
        )
        assert url == "https://ws/api/2.0/vector-search/indexes/cat.sch.idx"

    def test_sp_with_index_url_returns_index_url(self):
        url = _get_index_url(
            index_url="dp.example/idx",
            workspace_url="https://ws",
            index_name="cat.sch.idx",
            personal_access_token=None,
            service_principal_client_id="id",
            service_principal_client_secret="secret",
        )
        # add_https_if_missing was applied.
        assert url == "https://dp.example/idx"

    def test_missing_index_url_falls_back_to_control_plane(self):
        url = _get_index_url(
            index_url=None,
            workspace_url="https://ws",
            index_name="cat.sch.idx",
            personal_access_token=None,
            service_principal_client_id="id",
            service_principal_client_secret="secret",
        )
        assert url == "https://ws/api/2.0/vector-search/indexes/cat.sch.idx"


class TestTokenForRequest:
    """Cover the cache-hit branches of AISearchIndex._get_token_for_request."""

    def test_pat_branch_returns_pat(self, ai_search_index_factory):
        idx = ai_search_index_factory()
        idx.personal_access_token = "pat-value"
        assert idx._get_token_for_request() == "pat-value"

    def test_control_plane_cache_hit_returns_cached_token(self, ai_search_index_factory, workspace_url):
        idx = ai_search_index_factory()
        # Index URL contains workspace_url, so control_plane is auto-detected.
        idx.index_url = f"{workspace_url}/api/2.0/vector-search/indexes/cat.sch.idx"
        assert idx._get_token_for_request() == "cp-token"

    def test_write_cache_hit_returns_write_token(self, ai_search_index_factory):
        idx = ai_search_index_factory()
        idx.index_url = "https://dp/idx"  # not control plane
        assert idx._get_token_for_request(write=True) == "write-token"

    def test_read_cache_hit_returns_read_token(self, ai_search_index_factory):
        idx = ai_search_index_factory()
        idx.index_url = "https://dp/idx"  # not control plane
        assert idx._get_token_for_request() == "read-token"

    def test_explicit_control_plane_returns_cp_token(self, ai_search_index_factory):
        idx = ai_search_index_factory()
        idx.index_url = "https://dp/idx"  # not control plane in URL
        assert idx._get_token_for_request(control_plane=True) == "cp-token"

    def test_expired_token_triggers_refetch(self, ai_search_index_factory):
        idx = ai_search_index_factory()
        idx.index_url = "https://dp/idx"
        idx._read_oauth_token_expiry_ts = time.time() - 1  # expired
        with patch(
            "databricks.ai_search.utils.OAuthTokenUtils.get_oauth_token",
            return_value={"access_token": "fresh", "expires_in": 3600},
        ):
            assert idx._get_token_for_request() == "fresh"

    def test_raises_when_no_pat_and_no_service_principal(self, ai_search_index_factory):
        # Guards the fall-through raise, which sits outside the token-refresh lock: with no cached
        # token, no PAT, and no SP credentials, the method must still raise (not deadlock or return).
        idx = ai_search_index_factory()
        idx.index_url = "https://dp/idx"
        idx.personal_access_token = None
        idx.service_principal_client_id = None
        idx.service_principal_client_secret = None
        idx._read_oauth_token = None
        idx._read_oauth_token_expiry_ts = None
        with pytest.raises(Exception, match="must specify service principal or PAT"):
            idx._get_token_for_request()

    def test_concurrent_refresh_mints_token_once(self, ai_search_index_factory):
        # ES-2041784: one index object shared across threads must serialize token refresh so it
        # mints exactly once instead of racing the check-and-set. A Barrier makes all workers
        # arrive together, and a slow mint widens the race window the lock has to close.
        idx = ai_search_index_factory()
        idx.index_url = "https://dp/idx"  # data-plane read path
        idx._read_oauth_token = None  # force a refresh
        idx._read_oauth_token_expiry_ts = None

        num_threads = 8
        barrier = threading.Barrier(num_threads)
        call_count = 0
        count_lock = threading.Lock()

        def slow_mint(*args, **kwargs):
            nonlocal call_count
            with count_lock:
                call_count += 1
            time.sleep(0.05)  # hold the critical section so racing threads would overlap
            return {"access_token": "fresh", "expires_in": 3600}

        results = {}
        results_lock = threading.Lock()

        def worker():
            barrier.wait()
            token = idx._get_token_for_request()
            with results_lock:
                results[threading.get_ident()] = token

        with patch(
            "databricks.ai_search.utils.OAuthTokenUtils.get_oauth_token",
            side_effect=slow_mint,
        ):
            threads = [threading.Thread(target=worker) for _ in range(num_threads)]
            for t in threads:
                t.start()
            for t in threads:
                t.join()

        assert call_count == 1  # exactly one mint despite the concurrent stampede
        assert len(results) == num_threads
        assert set(results.values()) == {"fresh"}  # every thread observed the freshly-minted token


class TestTokenAuthorizationDetails:
    """authorization_details sent when minting a fresh SP-OAuth token."""

    @staticmethod
    def _mint(idx, write=False, control_plane=False):
        idx.index_url = "https://dp/idx"
        idx._read_oauth_token = idx._write_oauth_token = idx._control_plane_oauth_token = None
        with patch(
            "databricks.ai_search.utils.OAuthTokenUtils.get_oauth_token",
            return_value={"access_token": "fresh", "expires_in": 3600},
        ) as mint:
            idx._get_token_for_request(write=write, control_plane=control_plane)
        details = mint.call_args.kwargs["authorization_details"]
        return details if details == [] else json.loads(details)

    @staticmethod
    def _endpoint_paths(details):
        return [d["object_path"] for d in details if d["type"] == "workspace_permission"]

    def test_ingestion_only(self, ai_search_index_factory):
        idx = ai_search_index_factory()
        idx.mlserving_endpoint_id = "ing"
        details = self._mint(idx)
        assert details[0] == {
            "type": "unity_catalog_permission",
            "securable_type": "table",
            "securable_object_name": "cat.sch.idx",
            "operation": "ReadVectorIndex",
        }
        assert details[1] == {
            "type": "workspace_permission",
            "object_type": "serving-endpoints",
            "object_path": "/serving-endpoints/ing",
            "actions": ["query_inference_endpoint"],
        }
        assert len(details) == 2

    def test_no_endpoints(self, ai_search_index_factory):
        details = self._mint(ai_search_index_factory())
        assert [d["type"] for d in details] == ["unity_catalog_permission"]

    def test_read_with_distinct_query_endpoint_includes_both(self, ai_search_index_factory):
        idx = ai_search_index_factory()
        idx.mlserving_endpoint_id = "ing"
        idx.mlserving_endpoint_id_for_query = "qry"
        assert self._endpoint_paths(self._mint(idx)) == ["/serving-endpoints/ing", "/serving-endpoints/qry"]

    def test_read_with_same_query_endpoint_dedupes(self, ai_search_index_factory):
        idx = ai_search_index_factory()
        idx.mlserving_endpoint_id = idx.mlserving_endpoint_id_for_query = "ing"
        assert self._endpoint_paths(self._mint(idx)) == ["/serving-endpoints/ing"]

    def test_read_with_only_query_endpoint(self, ai_search_index_factory):
        idx = ai_search_index_factory()
        idx.mlserving_endpoint_id_for_query = "qry"
        assert self._endpoint_paths(self._mint(idx)) == ["/serving-endpoints/qry"]

    def test_write_ignores_query_endpoint(self, ai_search_index_factory):
        idx = ai_search_index_factory()
        idx.mlserving_endpoint_id = "ing"
        idx.mlserving_endpoint_id_for_query = "qry"
        details = self._mint(idx, write=True)
        assert details[0]["operation"] == "WriteVectorIndex"
        assert self._endpoint_paths(details) == ["/serving-endpoints/ing"]

    def test_control_plane_is_empty(self, ai_search_index_factory):
        idx = ai_search_index_factory()
        idx.mlserving_endpoint_id = "ing"
        idx.mlserving_endpoint_id_for_query = "qry"
        assert self._mint(idx, control_plane=True) == []
