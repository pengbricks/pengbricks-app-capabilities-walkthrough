# ruff: noqa: E402  -- sys.modules stubs must precede SDK imports
import sys
from unittest.mock import MagicMock

import pytest

# Mock external deps before importing the SDK (mirrors test_reranker_auth.py).
sys.modules.setdefault("deprecation", MagicMock())
sys.modules.setdefault("databricks.sdk", MagicMock())
sys.modules.setdefault("databricks.sdk.credentials_provider", MagicMock())
_dbu = MagicMock()
_dbu.is_in_databricks_model_serving_environment.return_value = False
_mlu = MagicMock()
_mlu.databricks_utils = _dbu
sys.modules.setdefault("mlflow", MagicMock())
sys.modules.setdefault("mlflow.utils", _mlu)
sys.modules.setdefault("mlflow.utils.databricks_utils", _dbu)

from databricks.ai_search.index import AISearchIndex
from databricks.ai_search.reranker import (
    DatabricksReranker,
    ExperimentalDatabricksFinetunedReranker,
)
from databricks.ai_search.reranker import _default_finetuned_endpoint_name


# UUID used by the formula-based tests. tableid8 = "12c56854"
_TEST_TABLE_ID = "12c56854-7850-4ca5-a921-9e938b8d353e"


def test_default_endpoint_name_formula():
    assert (
        _default_finetuned_endpoint_name("main.erikml.my_index", _TEST_TABLE_ID)
        == "main_erikml_my_index_12c56854_finetuned_reranker"
    )


def test_default_endpoint_name_truncates_to_caps():
    assert (
        _default_finetuned_endpoint_name(
            "vector_search_workloads.datasets.hima_autoeval_live_demo_index",
            _TEST_TABLE_ID,
        )
        == "vector_datase_hima_autoeval_li_12c56854_finetuned_reranker"
    )


def test_default_endpoint_name_preserves_dashes_in_index_name():
    # Dashes are valid in Model Serving endpoint names ([a-zA-Z0-9_-]), so
    # the sanitizer leaves them in place. "shopping-queries-us" stays as-is
    # (19 chars), then truncated to first 16 = "shopping-queries".
    assert (
        _default_finetuned_endpoint_name("main.erikml.shopping-queries-us", _TEST_TABLE_ID)
        == "main_erikml_shopping-queries_12c56854_finetuned_reranker"
    )


def test_default_endpoint_name_replaces_other_special_chars_with_underscore():
    # A char outside [a-zA-Z0-9_-] (here `@`) gets sanitized to `_`.
    assert (
        _default_finetuned_endpoint_name("main.erikml.foo@bar", _TEST_TABLE_ID)
        == "main_erikml_foo_bar_12c56854_finetuned_reranker"
    )


def test_default_endpoint_name_distinguishes_collisions():
    a = _default_finetuned_endpoint_name("c.s.foo", "11111111-aaaa-bbbb-cccc-dddddddddddd")
    b = _default_finetuned_endpoint_name("c.s.foo", "99999999-aaaa-bbbb-cccc-dddddddddddd")
    assert a != b


def test_default_endpoint_name_requires_fully_qualified_name():
    with pytest.raises(ValueError, match="fully qualified"):
        _default_finetuned_endpoint_name("my_index", _TEST_TABLE_ID)


def _make_index_for_test():
    """Create an AISearchIndex instance bypassing __init__ for isolated testing.

    Mirrors the bypass-init pattern in test_reranker_auth.py. Sets `name` to
    "main.erikml.my_index" so _default_finetuned_endpoint_name yields
    "main_erikml_my_index_12c56854_finetuned_reranker" when paired with the
    canonical test table_id ``12c56854-7850-4ca5-a921-9e938b8d353e``.
    """
    idx = AISearchIndex.__new__(AISearchIndex)
    idx.workspace_url = "https://my-workspace.cloud.databricks.com"
    idx.index_url = "https://my-workspace.cloud.databricks.com" "/api/2.0/vector-search/indexes/main.erikml.my_index"
    idx.name = "main.erikml.my_index"
    idx.endpoint_name = "test-endpoint"
    idx.personal_access_token = "pat-token"
    idx.service_principal_client_id = None
    idx.service_principal_client_secret = None
    idx.azure_tenant_id = None
    idx.azure_login_id = None
    idx._liteswap_traffic_id = None
    idx._use_user_passed_credentials = True
    idx.mlserving_endpoint_id = None
    idx.mlserving_endpoint_id_for_query = None
    idx.credential_strategy = None
    idx._warned_on_deprecated_columns_to_rerank = True
    idx._index_url_ensure_reranker_compatible = None
    idx._get_reranker_url_callable = lambda: idx.index_url
    # Pre-seed the index-id cache so _build_query_payload doesn't issue a real
    # describe() during _default_finetuned_endpoint_name fallback.
    idx._cached_index_id = _TEST_TABLE_ID
    return idx


def test_finetuned_reranker_builds_expected_top_level_reranker_block():
    idx = _make_index_for_test()
    json_data, _resolved_cols = idx._build_query_payload(
        columns=["id", "text"],
        query_text="hello",
        query_vector=None,
        filters=None,
        num_results=10,
        score_threshold=None,
        query_type=None,
        columns_to_rerank=None,
        reranker=ExperimentalDatabricksFinetunedReranker(columns_to_rerank=["text"]),
    )
    assert json_data["reranker"] == {
        "model": "main_erikml_my_index_12c56854_finetuned_reranker",
        "model_type": "MODEL_TYPE_FINETUNED",
        "parameters": {"columns_to_rerank": ["text"]},
    }
    # The DatabricksReranker top-level columns_to_rerank key must NOT also be set.
    assert "columns_to_rerank" not in json_data


def test_finetuned_reranker_uses_explicit_endpoint_name():
    idx = _make_index_for_test()
    json_data, _ = idx._build_query_payload(
        columns=["id", "text"],
        query_text="hello",
        query_vector=None,
        filters=None,
        num_results=10,
        score_threshold=None,
        query_type=None,
        columns_to_rerank=None,
        reranker=ExperimentalDatabricksFinetunedReranker(
            columns_to_rerank=["text"],
            endpoint_name="custom_endpoint",
        ),
    )
    assert json_data["reranker"]["model"] == "custom_endpoint"


def test_finetuned_reranker_rejects_combination_with_columns_to_rerank_kwarg():
    idx = _make_index_for_test()
    with pytest.raises(ValueError):
        idx._build_query_payload(
            columns=["id", "text"],
            query_text="hello",
            query_vector=None,
            filters=None,
            num_results=10,
            score_threshold=None,
            query_type=None,
            columns_to_rerank=["text"],
            reranker=ExperimentalDatabricksFinetunedReranker(columns_to_rerank=["text"]),
        )


def test_databricks_reranker_emits_base_reranker_block():
    idx = _make_index_for_test()
    json_data, _ = idx._build_query_payload(
        columns=["id", "text"],
        query_text="hello",
        query_vector=None,
        filters=None,
        num_results=10,
        score_threshold=None,
        query_type=None,
        columns_to_rerank=None,
        reranker=DatabricksReranker(columns_to_rerank=["text"]),
    )
    assert json_data["reranker"] == {
        "model": "databricks_reranker",
        "model_type": "MODEL_TYPE_BASE",
        "parameters": {"columns_to_rerank": ["text"]},
    }
    # The top-level columns_to_rerank key must NOT be set; the columns are
    # carried inside the reranker block.
    assert "columns_to_rerank" not in json_data


def test_deprecated_columns_to_rerank_kwarg_emits_base_reranker_block():
    idx = _make_index_for_test()
    json_data, _ = idx._build_query_payload(
        columns=["id", "text"],
        query_text="hello",
        query_vector=None,
        filters=None,
        num_results=10,
        score_threshold=None,
        query_type=None,
        columns_to_rerank=["text"],
        reranker=None,
        disable_notice=True,
    )
    assert json_data["reranker"] == {
        "model": "databricks_reranker",
        "model_type": "MODEL_TYPE_BASE",
        "parameters": {"columns_to_rerank": ["text"]},
    }
    assert "columns_to_rerank" not in json_data
