"""Tests for databricks.ai_search.utils."""

import sys
import threading
from unittest.mock import MagicMock, patch

import pytest

from databricks.ai_search.exceptions import (
    BadRequest,
    NotFound,
    PermissionDenied,
    ResourceConflict,
    TooManyRequests,
    AISearchException,
)
from databricks.ai_search.utils import (
    CredentialStrategy,
    OAuthTokenUtils,
    RequestUtils,
    UrlUtils,
    _cached_get_request_session,
    _get_invokers_token_fallback,
    _get_invokers_token_from_mlflowserving,
    authentication_warning,
    get_model_serving_invoker_credentials,
    is_in_model_serving_environment,
)


class TestUrlUtils:
    def test_adds_https_when_missing(self):
        assert UrlUtils.add_https_if_missing("foo.example.com") == "https://foo.example.com"

    def test_leaves_https_unchanged(self):
        assert UrlUtils.add_https_if_missing("https://foo.com") == "https://foo.com"

    def test_leaves_http_unchanged(self):
        assert UrlUtils.add_https_if_missing("http://foo.com") == "http://foo.com"


class TestCredentialStrategyEnum:
    def test_model_serving_user_credentials_exists(self):
        assert CredentialStrategy.MODEL_SERVING_USER_CREDENTIALS.value == 1

    def test_enum_membership(self):
        assert CredentialStrategy.MODEL_SERVING_USER_CREDENTIALS in CredentialStrategy


class TestOAuthTokenUtilsAzure:
    def test_requires_login_and_tenant_id(self):
        with pytest.raises(AssertionError):
            OAuthTokenUtils.get_azure_oauth_token(
                workspace_url="https://ws",
                azure_tenant_id=None,
                azure_login_id="login",
                service_principal_client_id="id",
                service_principal_client_secret="secret",
            )
        with pytest.raises(AssertionError):
            OAuthTokenUtils.get_azure_oauth_token(
                workspace_url="https://ws",
                azure_tenant_id="tenant",
                azure_login_id=None,
                service_principal_client_id="id",
                service_principal_client_secret="secret",
            )

    @patch("databricks.ai_search.utils.RequestUtils.issue_request")
    def test_returns_aad_response_when_no_authorization_details(self, mock_req):
        mock_req.return_value = {"access_token": "aad-token", "expires_in": 3600}
        result = OAuthTokenUtils.get_azure_oauth_token(
            workspace_url="https://ws",
            azure_tenant_id="tenant",
            azure_login_id="login",
            service_principal_client_id="id",
            service_principal_client_secret="secret",
        )
        assert result == {"access_token": "aad-token", "expires_in": 3600}
        # The AAD endpoint is hit; only one request when no authorization_details.
        mock_req.assert_called_once()
        url = mock_req.call_args.kwargs["url"]
        assert "login.microsoftonline.com" in url
        assert "tenant/oauth2/token" in url

    @patch("databricks.ai_search.utils.RequestUtils.issue_request")
    def test_exchanges_at_workspace_when_authorization_details_provided(self, mock_req):
        mock_req.side_effect = [
            {"access_token": "aad-token", "expires_in": 3600},
            {"access_token": "exchanged-token", "expires_in": 3600},
        ]
        result = OAuthTokenUtils.get_azure_oauth_token(
            workspace_url="https://ws",
            azure_tenant_id="tenant",
            azure_login_id="login",
            service_principal_client_id="id",
            service_principal_client_secret="secret",
            authorization_details=[{"type": "x"}],
        )
        assert result == {"access_token": "exchanged-token", "expires_in": 3600}
        assert mock_req.call_count == 2
        exchange_call = mock_req.call_args_list[1]
        assert exchange_call.kwargs["url"] == "https://ws/oidc/v1/token"
        assert exchange_call.kwargs["data"]["assertion"] == "aad-token"
        # ES-1967899: the exchange must request scope=all-apis so the minted token carries an
        # OAuth scope; otherwise Model Serving rejects the embedding call with InvalidScope.
        assert exchange_call.kwargs["data"]["scope"] == "all-apis"


class TestOAuthTokenUtilsOAuth:
    @patch("databricks.ai_search.utils.RequestUtils.issue_request")
    def test_posts_to_oidc_token_with_client_credentials_grant(self, mock_req):
        mock_req.return_value = {"access_token": "tok", "expires_in": 3600}
        result = OAuthTokenUtils.get_oauth_token(
            workspace_url="https://ws",
            service_principal_client_id="id",
            service_principal_client_secret="secret",
        )
        assert result["access_token"] == "tok"
        mock_req.assert_called_once()
        call = mock_req.call_args.kwargs
        assert call["url"] == "https://ws/oidc/v1/token"
        assert call["method"] == "POST"
        assert call["data"]["grant_type"] == "client_credentials"
        assert call["data"]["scope"] == "all-apis"
        assert call["auth"] == ("id", "secret")


class TestRequestUtilsErrorMapping:
    """Cover the response.ok==False status_code → exception mapping table."""

    def _patched_session(self, response):
        # Patch the session.request used inside RequestUtils.
        return patch.object(RequestUtils, "session", MagicMock(request=MagicMock(return_value=response)))

    @pytest.mark.parametrize(
        "status_code,exc_type",
        [
            (400, BadRequest),
            (403, PermissionDenied),
            (404, NotFound),
            (409, ResourceConflict),
            (429, TooManyRequests),
            (500, AISearchException),
            (503, AISearchException),
        ],
    )
    @patch("databricks.ai_search.utils._cached_get_request_session")
    def test_status_code_maps_to_expected_exception(self, mock_session_factory, status_code, exc_type):
        response = MagicMock()
        response.ok = False
        response.status_code = status_code
        response.json.return_value = {"message": f"err-{status_code}"}
        response.content = b"raw"
        mock_session_factory.return_value.request.return_value = response

        with pytest.raises(exc_type) as exc_info:
            RequestUtils.issue_request(url="https://x", method="GET")
        assert exc_info.value.status_code == status_code
        assert exc_info.value.response_content == b"raw"

    @patch("databricks.ai_search.utils._cached_get_request_session")
    def test_json_body_with_message_key_used_in_error_message(self, mock_session_factory):
        response = MagicMock()
        response.ok = False
        response.status_code = 400
        response.json.return_value = {"message": "specific message"}
        response.content = b""
        mock_session_factory.return_value.request.return_value = response

        with pytest.raises(BadRequest) as exc:
            RequestUtils.issue_request(url="https://x", method="GET")
        assert "specific message" in str(exc.value)

    @patch("databricks.ai_search.utils._cached_get_request_session")
    def test_json_body_with_error_key_used_in_error_message(self, mock_session_factory):
        response = MagicMock()
        response.ok = False
        response.status_code = 400
        response.json.return_value = {"error": "specific error"}
        response.content = b""
        mock_session_factory.return_value.request.return_value = response

        with pytest.raises(BadRequest) as exc:
            RequestUtils.issue_request(url="https://x", method="GET")
        assert "specific error" in str(exc.value)

    @patch("databricks.ai_search.utils._cached_get_request_session")
    def test_error_code_and_details_surfaced_in_message(self, mock_session_factory):
        # Message alone is often generic; error_code and details are the real
        # signal and must not be hidden (only accessible via response_content).
        response = MagicMock()
        response.ok = False
        response.status_code = 400
        response.json.return_value = {
            "error_code": "INVALID_PARAMETER_VALUE",
            "message": "generic message",
            "details": [{"reason": "bad name"}],
        }
        response.content = b'{"error_code": "INVALID_PARAMETER_VALUE"}'
        mock_session_factory.return_value.request.return_value = response

        with pytest.raises(BadRequest) as exc:
            RequestUtils.issue_request(url="https://x", method="GET")
        text = str(exc.value)
        assert "INVALID_PARAMETER_VALUE" in text
        assert "generic message" in text
        assert "bad name" in text
        # Structured attributes let callers read the fields without parsing the message.
        assert exc.value.error_code == "INVALID_PARAMETER_VALUE"
        assert exc.value.details == [{"reason": "bad name"}]

    @patch("databricks.ai_search.utils._cached_get_request_session")
    def test_error_code_surfaced_when_message_absent(self, mock_session_factory):
        # A message-less body must still surface error_code and details.
        response = MagicMock()
        response.ok = False
        response.status_code = 400
        response.json.return_value = {
            "error_code": "INVALID_PARAMETER_VALUE",
            "details": [{"reason": "bad name"}],
        }
        response.content = b"{}"
        mock_session_factory.return_value.request.return_value = response

        with pytest.raises(BadRequest) as exc:
            RequestUtils.issue_request(url="https://x", method="GET")
        text = str(exc.value)
        assert "INVALID_PARAMETER_VALUE" in text
        assert "bad name" in text

    @patch("databricks.ai_search.utils._cached_get_request_session")
    def test_non_json_body_falls_back_to_text(self, mock_session_factory):
        response = MagicMock()
        response.ok = False
        response.status_code = 500
        response.json.side_effect = ValueError("not json")
        response.text = "plain text error"
        response.content = b"plain text error"
        mock_session_factory.return_value.request.return_value = response

        with pytest.raises(AISearchException) as exc:
            RequestUtils.issue_request(url="https://x", method="GET")
        assert "plain text error" in str(exc.value)

    @patch("databricks.ai_search.utils._cached_get_request_session")
    def test_authorization_header_added_when_token_provided(self, mock_session_factory):
        response = MagicMock()
        response.ok = True
        response.json.return_value = {"ok": True}
        mock_session = mock_session_factory.return_value
        mock_session.request.return_value = response

        RequestUtils.issue_request(url="https://x", method="GET", token="my-token")
        headers = mock_session.request.call_args.kwargs["headers"]
        assert headers["Authorization"] == "Bearer my-token"

    @patch("databricks.ai_search.utils._cached_get_request_session")
    def test_sdk_version_header_always_added(self, mock_session_factory):
        response = MagicMock()
        response.ok = True
        response.json.return_value = {}
        mock_session = mock_session_factory.return_value
        mock_session.request.return_value = response

        RequestUtils.issue_request(url="https://x", method="GET")
        headers = mock_session.request.call_args.kwargs["headers"]
        assert "X-Databricks-Python-SDK-Version" in headers


class TestRequestSessionCaching:
    def test_same_args_returns_same_session(self):
        s1 = _cached_get_request_session(3, 1.0, 0.2, process_id=12345, thread_id=999)
        s2 = _cached_get_request_session(3, 1.0, 0.2, process_id=12345, thread_id=999)
        assert s1 is s2

    def test_different_args_yields_different_session(self):
        s1 = _cached_get_request_session(3, 1.0, 0.2, process_id=12346, thread_id=999)
        s2 = _cached_get_request_session(5, 1.0, 0.2, process_id=12346, thread_id=999)
        assert s1 is not s2

    def test_different_thread_id_yields_different_session(self):
        # Thread identity is part of the cache key so concurrent threads never share a Session.
        s1 = _cached_get_request_session(3, 1.0, 0.2, process_id=12346, thread_id=111)
        s2 = _cached_get_request_session(3, 1.0, 0.2, process_id=12346, thread_id=222)
        assert s1 is not s2

    def test_retry_strategy_includes_429_503_504(self):
        s = _cached_get_request_session(3, 1.0, 0.2, process_id=12347, thread_id=999)
        adapter = s.adapters["https://"]
        forcelist = adapter.max_retries.status_forcelist
        assert 429 in forcelist
        assert 503 in forcelist
        assert 504 in forcelist

    def test_concurrent_live_threads_get_distinct_sessions(self):
        # The core ES-2041784 invariant: threads that are provably alive at the same time must
        # each get their own Session (requests.Session is not thread-safe). A Barrier holds every
        # worker inside the factory call simultaneously, so their thread idents cannot be reused.
        num_threads = 8
        barrier = threading.Barrier(num_threads)
        sessions = {}
        lock = threading.Lock()

        def worker():
            barrier.wait()
            session = _cached_get_request_session(3, 1.0, 0.2, process_id=54321, thread_id=threading.get_ident())
            with lock:
                sessions[threading.get_ident()] = session

        threads = [threading.Thread(target=worker) for _ in range(num_threads)]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        assert len(sessions) == num_threads
        # All distinct: no two live threads shared a Session object.
        assert len({id(s) for s in sessions.values()}) == num_threads

    def test_same_thread_reuses_session(self):
        # Within one thread the Session is reused so HTTP keep-alive/pooling still works.
        tid = threading.get_ident()
        s1 = _cached_get_request_session(3, 1.0, 0.2, process_id=54322, thread_id=tid)
        s2 = _cached_get_request_session(3, 1.0, 0.2, process_id=54322, thread_id=tid)
        assert s1 is s2


class TestIsInModelServingEnvironment:
    def test_returns_false_when_env_unset(self, monkeypatch):
        monkeypatch.delenv("IS_IN_DB_MODEL_SERVING_ENV", raising=False)
        monkeypatch.delenv("IS_IN_DATABRICKS_MODEL_SERVING_ENV", raising=False)
        assert is_in_model_serving_environment() is False

    def test_returns_true_when_legacy_env_set(self, monkeypatch):
        monkeypatch.setenv("IS_IN_DB_MODEL_SERVING_ENV", "true")
        monkeypatch.delenv("IS_IN_DATABRICKS_MODEL_SERVING_ENV", raising=False)
        assert is_in_model_serving_environment() is True

    def test_returns_true_when_canonical_env_set(self, monkeypatch):
        monkeypatch.delenv("IS_IN_DB_MODEL_SERVING_ENV", raising=False)
        monkeypatch.setenv("IS_IN_DATABRICKS_MODEL_SERVING_ENV", "true")
        assert is_in_model_serving_environment() is True

    def test_returns_false_when_env_set_to_other_value(self, monkeypatch):
        monkeypatch.setenv("IS_IN_DB_MODEL_SERVING_ENV", "yes")
        assert is_in_model_serving_environment() is False


class TestGetModelServingInvokerCredentials:
    def test_returns_none_tuple_when_not_in_env(self, monkeypatch):
        monkeypatch.delenv("IS_IN_DB_MODEL_SERVING_ENV", raising=False)
        monkeypatch.delenv("IS_IN_DATABRICKS_MODEL_SERVING_ENV", raising=False)
        host, token = get_model_serving_invoker_credentials()
        assert host is None
        assert token is None

    def test_returns_host_and_token_when_in_env(self, monkeypatch):
        monkeypatch.setenv("IS_IN_DB_MODEL_SERVING_ENV", "true")
        monkeypatch.setenv("DATABRICKS_MODEL_SERVING_HOST_URL", "https://serving-host")
        threading.main_thread().__dict__["invokers_token"] = "invoker-tok"
        try:
            with patch.dict(sys.modules, {"mlflowserving.scoring_server.agent_utils": None}):
                # ImportError path falls back to thread dict.
                host, token = get_model_serving_invoker_credentials()
            assert host == "https://serving-host"
            assert token == "invoker-tok"
        finally:
            threading.main_thread().__dict__.pop("invokers_token", None)

    def test_raises_when_in_env_with_no_token(self, monkeypatch):
        monkeypatch.setenv("IS_IN_DB_MODEL_SERVING_ENV", "true")
        threading.main_thread().__dict__.pop("invokers_token", None)
        with patch.dict(sys.modules, {"mlflowserving.scoring_server.agent_utils": None}):
            with pytest.raises(RuntimeError, match="Unable to read Invokers Token"):
                get_model_serving_invoker_credentials()


class TestInvokersTokenFallback:
    def test_reads_from_main_thread_dict(self):
        threading.main_thread().__dict__["invokers_token"] = "thread-tok"
        try:
            assert _get_invokers_token_fallback() == "thread-tok"
        finally:
            threading.main_thread().__dict__.pop("invokers_token", None)

    def test_returns_none_when_not_set(self):
        threading.main_thread().__dict__.pop("invokers_token", None)
        assert _get_invokers_token_fallback() is None


class TestInvokersTokenFromMlflowserving:
    def test_uses_fetch_obo_token_when_importable(self):
        fake_module = MagicMock()
        fake_module.fetch_obo_token.return_value = "obo-token"
        with patch.dict(sys.modules, {"mlflowserving.scoring_server.agent_utils": fake_module}):
            assert _get_invokers_token_from_mlflowserving() == "obo-token"

    def test_falls_back_on_importerror(self):
        threading.main_thread().__dict__["invokers_token"] = "fallback"
        try:
            with patch.dict(sys.modules, {"mlflowserving.scoring_server.agent_utils": None}):
                assert _get_invokers_token_from_mlflowserving() == "fallback"
        finally:
            threading.main_thread().__dict__.pop("invokers_token", None)


class TestAuthenticationWarning:
    def test_notebook_token_prints_notice(self, capsys):
        authentication_warning(notebook_token=True, personal_access_token=None, disable_notice=False)
        out = capsys.readouterr().out
        assert "notebook" in out.lower()

    def test_pat_prints_notice(self, capsys):
        authentication_warning(notebook_token=False, personal_access_token="dapi...", disable_notice=False)
        out = capsys.readouterr().out
        assert "Personal Authentication Token" in out

    def test_disable_notice_silences_output(self, capsys):
        authentication_warning(notebook_token=True, personal_access_token="dapi", disable_notice=True)
        assert capsys.readouterr().out == ""

    def test_nothing_to_warn_about_is_silent(self, capsys):
        authentication_warning(notebook_token=False, personal_access_token=None, disable_notice=False)
        assert capsys.readouterr().out == ""
