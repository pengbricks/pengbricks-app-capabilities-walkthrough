# ruff: noqa: E402  -- sys.modules stubs must precede SDK imports
import sys
import unittest
from unittest.mock import MagicMock, patch

# Mock modules unavailable in the test environment before importing the SDK.
sys.modules.setdefault("deprecation", MagicMock())
sys.modules.setdefault("databricks.sdk", MagicMock())
sys.modules.setdefault("databricks.sdk.credentials_provider", MagicMock())
_mock_databricks_utils = MagicMock()
_mock_databricks_utils.is_in_databricks_model_serving_environment.return_value = False
_mock_mlflow_utils = MagicMock()
_mock_mlflow_utils.databricks_utils = _mock_databricks_utils
sys.modules.setdefault("mlflow", MagicMock())
sys.modules.setdefault("mlflow.utils", _mock_mlflow_utils)
sys.modules.setdefault("mlflow.utils.databricks_utils", _mock_databricks_utils)

from databricks.ai_search.utils import (
    _camel_to_snake,
    normalize_response_keys_to_snake_case,
)
from databricks.ai_search.index import AISearchIndex


class TestCamelToSnake(unittest.TestCase):
    def test_already_snake_case_unchanged(self):
        self.assertEqual(_camel_to_snake("next_page_token"), "next_page_token")
        self.assertEqual(_camel_to_snake("row_count"), "row_count")
        self.assertEqual(_camel_to_snake("id"), "id")

    def test_camel_case_converted(self):
        self.assertEqual(_camel_to_snake("nextPageToken"), "next_page_token")
        self.assertEqual(_camel_to_snake("rowCount"), "row_count")
        self.assertEqual(_camel_to_snake("dataArray"), "data_array")

    def test_pascal_case_converted(self):
        # PascalCase first letter is preserved-by-position; lowercased downstream.
        self.assertEqual(_camel_to_snake("NextPageToken"), "next_page_token")


class TestNormalizeResponseKeys(unittest.TestCase):
    def test_camelcase_dict_converted(self):
        camel = {
            "nextPageToken": "abc",
            "result": {"rowCount": 3, "dataArray": [[1], [2], [3]]},
        }
        snake = {
            "next_page_token": "abc",
            "result": {"row_count": 3, "data_array": [[1], [2], [3]]},
        }
        self.assertEqual(normalize_response_keys_to_snake_case(camel), snake)

    def test_snake_case_dict_unchanged(self):
        snake = {
            "next_page_token": "abc",
            "result": {"row_count": 3, "data_array": [[1], [2], [3]]},
        }
        self.assertEqual(normalize_response_keys_to_snake_case(snake), snake)

    def test_nested_lists_walked(self):
        value = {"items": [{"itemId": 1}, {"itemId": 2}]}
        self.assertEqual(
            normalize_response_keys_to_snake_case(value),
            {"items": [{"item_id": 1}, {"item_id": 2}]},
        )

    def test_scalars_pass_through(self):
        self.assertEqual(normalize_response_keys_to_snake_case(None), None)
        self.assertEqual(normalize_response_keys_to_snake_case(42), 42)
        self.assertEqual(normalize_response_keys_to_snake_case("hello"), "hello")


class TestSimilaritySearchHandlesCamelCase(unittest.TestCase):
    def _create_index(self):
        return AISearchIndex(
            workspace_url="https://example.cloud.databricks.com",
            index_url="https://dp.example.com/api/2.0/vector-search-with-creds/0/endpoints/x/indexes/y",
            name="cat.sch.idx",
            endpoint_name="ep",
            personal_access_token=None,
            service_principal_client_id="sp-id",
            service_principal_client_secret="sp-secret",
            use_user_passed_credentials=False,
        )

    @patch("databricks.ai_search.index.AISearchIndex._get_token_for_request")
    @patch("databricks.ai_search.utils.RequestUtils.issue_request")
    def test_camelcase_response_no_pagination(self, mock_request, mock_token):
        mock_token.return_value = "token"
        mock_request.return_value = {
            "result": {"rowCount": 2, "dataArray": [["a"], ["b"]]},
            "manifest": {"columns": [{"name": "id"}]},
        }
        idx = self._create_index()
        out = idx.similarity_search(query_text="hi", columns=["id"], num_results=10)
        self.assertEqual(out["result"]["row_count"], 2)
        self.assertEqual(out["result"]["data_array"], [["a"], ["b"]])

    @patch("databricks.ai_search.index.AISearchIndex._get_token_for_request")
    @patch("databricks.ai_search.utils.RequestUtils.issue_request")
    def test_camelcase_response_with_pagination(self, mock_request, mock_token):
        mock_token.return_value = "token"
        mock_request.side_effect = [
            {
                "nextPageToken": "page2",
                "result": {"rowCount": 1, "dataArray": [["a"]]},
                "manifest": {"columns": [{"name": "id"}]},
            },
            {
                "nextPageToken": "",
                "result": {"rowCount": 1, "dataArray": [["b"]]},
            },
        ]
        idx = self._create_index()
        out = idx.similarity_search(query_text="hi", columns=["id"], num_results=10)
        self.assertEqual(out["result"]["row_count"], 2)
        self.assertEqual(out["result"]["data_array"], [["a"], ["b"]])
        self.assertNotIn("next_page_token", out)

    @patch("databricks.ai_search.index.AISearchIndex._get_token_for_request")
    @patch("databricks.ai_search.utils.RequestUtils.issue_request")
    def test_snakecase_response_still_works(self, mock_request, mock_token):
        mock_token.return_value = "token"
        mock_request.return_value = {
            "result": {"row_count": 1, "data_array": [["a"]]},
            "manifest": {"columns": [{"name": "id"}]},
        }
        idx = self._create_index()
        out = idx.similarity_search(query_text="hi", columns=["id"], num_results=10)
        self.assertEqual(out["result"]["row_count"], 1)
        self.assertEqual(out["result"]["data_array"], [["a"]])


if __name__ == "__main__":
    unittest.main()
