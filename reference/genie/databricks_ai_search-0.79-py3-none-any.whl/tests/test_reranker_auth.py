# ruff: noqa: E402  -- sys.modules stubs must precede SDK imports
import threading
import time
import unittest
from unittest.mock import MagicMock, patch

import sys

# Mock modules that are unavailable in the test environment before importing
sys.modules["deprecation"] = MagicMock()
sys.modules["databricks.sdk"] = MagicMock()
sys.modules["databricks.sdk.credentials_provider"] = MagicMock()

# The mlflow mock needs is_in_databricks_model_serving_environment to return False
# so _get_token_for_request skips the model-serving early-return and exercises the
# OAuth / PAT / URL-detection logic under test.
_mock_databricks_utils = MagicMock()
_mock_databricks_utils.is_in_databricks_model_serving_environment.return_value = False
_mock_mlflow_utils = MagicMock()
_mock_mlflow_utils.databricks_utils = _mock_databricks_utils
sys.modules["mlflow"] = MagicMock()
sys.modules["mlflow.utils"] = _mock_mlflow_utils
sys.modules["mlflow.utils.databricks_utils"] = _mock_databricks_utils

from databricks.ai_search.index import AISearchIndex


def _create_index(workspace_url, index_url):
    """Create a AISearchIndex instance bypassing __init__ for isolated testing."""
    idx = AISearchIndex.__new__(AISearchIndex)
    idx.workspace_url = workspace_url
    idx.index_url = index_url
    idx.name = "catalog.schema.test_index"
    idx.endpoint_name = "test-endpoint"
    idx.personal_access_token = None
    idx.service_principal_client_id = "sp-client-id"
    idx.service_principal_client_secret = "sp-client-secret"
    idx.azure_tenant_id = None
    idx.azure_login_id = None
    idx._liteswap_traffic_id = None
    idx._use_user_passed_credentials = False
    idx.mlserving_endpoint_id = None
    idx.mlserving_endpoint_id_for_query = None
    idx.credential_strategy = None
    # __init__ is bypassed via __new__, so recreate the lock _get_token_for_request acquires.
    idx._token_refresh_lock = threading.Lock()

    # Pre-set a control plane token with a long expiry so the cached path is taken
    idx._control_plane_oauth_token = "control-plane-token"
    idx._control_plane_oauth_token_expiry_ts = time.time() + 9999

    idx._read_oauth_token = "read-data-plane-token"
    idx._read_oauth_token_expiry_ts = time.time() + 9999

    idx._write_oauth_token = None
    idx._write_oauth_token_expiry_ts = None

    return idx


class TestRerankerAuth(unittest.TestCase):
    """Verify that reranker requests always use a control-plane token."""

    def test_reranker_uses_control_plane_token_for_self_managed_index(self):
        """When control_plane=True is passed explicitly and the URL is an external
        domain (not containing the workspace URL), the method must still return
        the control-plane token instead of falling through to data-plane auth.
        """
        workspace_url = "https://my-workspace.cloud.databricks.com"
        index_url = workspace_url + "/api/2.0/vector-search/indexes/catalog.schema.test_index"
        idx = _create_index(workspace_url, index_url)

        # Simulate a reranker URL on an external domain (self-managed index)
        external_reranker_url = "https://external-self-managed.example.com/serving/indexes/catalog.schema.test_index"

        token = idx._get_token_for_request(
            index_url=external_reranker_url,
            control_plane=True,
        )
        self.assertEqual(
            token,
            "control-plane-token",
            "Reranker request to an external URL with control_plane=True should use control-plane token",
        )

    def test_regular_query_uses_url_based_token_detection(self):
        """Without an explicit control_plane override, a query to the workspace
        URL should detect control_plane=True via URL matching (existing behavior).
        """
        workspace_url = "https://my-workspace.cloud.databricks.com"
        index_url = workspace_url + "/api/2.0/vector-search/indexes/catalog.schema.test_index"
        idx = _create_index(workspace_url, index_url)

        # Regular query: index_url contains workspace_url, so it should detect control plane
        token = idx._get_token_for_request(index_url=index_url)
        self.assertEqual(
            token,
            "control-plane-token",
            "Regular query to workspace URL should detect control plane via URL matching",
        )

    def test_regular_query_to_external_url_uses_data_plane_token(self):
        """A regular query (no reranker) to an external URL should NOT get a
        control-plane token -- it should fall through to the data-plane read path.
        """
        workspace_url = "https://my-workspace.cloud.databricks.com"
        index_url = "https://external-endpoint.example.com/serving/indexes/catalog.schema.test_index"
        idx = _create_index(workspace_url, index_url)

        token = idx._get_token_for_request(index_url=index_url)
        self.assertEqual(
            token,
            "read-data-plane-token",
            "Regular query to external URL without control_plane flag should use data-plane token",
        )

    def test_reranker_uses_control_plane_token_for_managed_index(self):
        """When the reranker URL IS within the workspace URL, control_plane=True
        should still work (already covered by URL detection, but the explicit
        flag must not break anything).
        """
        workspace_url = "https://my-workspace.cloud.databricks.com"
        managed_reranker_url = workspace_url + "/api/2.0/vector-search/indexes/catalog.schema.test_index"
        idx = _create_index(workspace_url, managed_reranker_url)

        token = idx._get_token_for_request(
            index_url=managed_reranker_url,
            control_plane=True,
        )
        self.assertEqual(
            token,
            "control-plane-token",
            "Reranker request to a managed (workspace) URL should use control-plane token",
        )

    @patch("databricks.ai_search.utils.RequestUtils.issue_request")
    def test_reranker_pagination_uses_control_plane_token_for_self_managed_index(self, mock_issue_request):
        """When a reranker query against a self-managed index returns paginated
        results, the pagination requests must also use the control-plane token.
        """
        workspace_url = "https://my-workspace.cloud.databricks.com"
        index_url = workspace_url + "/api/2.0/vector-search/indexes/catalog.schema.test_index"
        idx = _create_index(workspace_url, index_url)

        external_reranker_url = "https://external-self-managed.example.com" "/serving/indexes/catalog.schema.test_index"
        idx._index_url_ensure_reranker_compatible = external_reranker_url
        idx._get_reranker_url_callable = None
        idx._warned_on_deprecated_columns_to_rerank = True
        idx.total_retries = 3
        idx.backoff_factor = 1
        idx.backoff_jitter = 0.2

        # First call is the query; second is pagination; third returns no next page.
        mock_issue_request.side_effect = [
            {
                "result": {"row_count": 1, "data_array": [["row1"]]},
                "next_page_token": "page2",
            },
            {
                "result": {"row_count": 1, "data_array": [["row2"]]},
                "next_page_token": None,
            },
        ]

        idx.similarity_search(
            columns=["col1"],
            query_text="test query",
            columns_to_rerank=["col1"],
        )

        # The initial query (call 0) and the pagination call (call 1) must both
        # receive the control-plane token.
        for call_index, call_args in enumerate(mock_issue_request.call_args_list):
            token_used = call_args[1].get("token") or call_args[0][1]
            self.assertEqual(
                token_used,
                "control-plane-token",
                f"Request #{call_index} should use the control-plane token " f"but got '{token_used}'",
            )


if __name__ == "__main__":
    unittest.main()
