"""Tests for databricks.ai_search.exceptions."""

import pytest

from databricks.ai_search.exceptions import (
    BadRequest,
    InvalidInputException,
    NotFound,
    PermissionDenied,
    ResourceConflict,
    ResourceDoesNotExist,
    TooManyRequests,
    AISearchException,
)


class TestAISearchException:
    def test_message_only(self):
        exc = AISearchException("boom")
        assert str(exc) == "boom"
        assert exc.status_code is None
        assert exc.response_content is None
        assert exc.error_code is None
        assert exc.details is None

    def test_carries_status_code_and_response_content(self):
        exc = AISearchException("nope", status_code=500, response_content=b"raw body")
        assert exc.status_code == 500
        assert exc.response_content == b"raw body"

    def test_is_subclass_of_builtin_exception(self):
        assert issubclass(AISearchException, Exception)


class TestExceptionHierarchy:
    @pytest.mark.parametrize(
        "cls",
        [
            InvalidInputException,
            NotFound,
            BadRequest,
            PermissionDenied,
            ResourceConflict,
            TooManyRequests,
        ],
    )
    def test_subclass_of_base(self, cls):
        assert issubclass(cls, AISearchException)

    @pytest.mark.parametrize(
        "cls",
        [
            InvalidInputException,
            NotFound,
            BadRequest,
            PermissionDenied,
            ResourceConflict,
            TooManyRequests,
        ],
    )
    def test_subclass_carries_fields(self, cls):
        exc = cls("msg", status_code=418, response_content=b"x")
        assert exc.status_code == 418
        assert exc.response_content == b"x"
        assert str(exc) == "msg"

    def test_base_catches_subclasses(self):
        with pytest.raises(AISearchException):
            raise NotFound("x", status_code=404)
        with pytest.raises(AISearchException):
            raise TooManyRequests("x", status_code=429)


class TestResourceDoesNotExistAlias:
    def test_alias_is_notfound(self):
        # ResourceDoesNotExist is the databricks-sdk-compat alias for NotFound;
        # they are literally the same class object.
        assert ResourceDoesNotExist is NotFound

    def test_alias_instance_is_notfound(self):
        exc = ResourceDoesNotExist("x")
        assert isinstance(exc, NotFound)
        assert isinstance(exc, AISearchException)
