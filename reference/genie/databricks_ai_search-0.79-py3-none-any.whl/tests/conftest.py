"""Shared fixtures for ai_search SDK tests.

External-module stubs (mlflow, deprecation, databricks.sdk) live in the root
conftest.py and the Bazel test entrypoint; this file holds pytest fixtures used
across multiple test modules.
"""

import threading
import time
from unittest.mock import MagicMock, patch

import pytest


@pytest.fixture
def mock_issue_request():
    """Patch RequestUtils.issue_request and yield the mock."""
    with patch("databricks.ai_search.utils.RequestUtils.issue_request") as m:
        yield m


@pytest.fixture
def workspace_url():
    return "https://test-workspace.cloud.databricks.com"


@pytest.fixture
def aisc_with_pat(workspace_url):
    """An AISearchClient using PAT auth, with mlflow auto-detect bypassed."""
    from databricks.ai_search.client import AISearchClient

    return AISearchClient(
        workspace_url=workspace_url,
        personal_access_token="test-pat-token",
        disable_notice=True,
    )


@pytest.fixture
def aisc_with_sp(workspace_url):
    """An AISearchClient using service principal auth."""
    from databricks.ai_search.client import AISearchClient

    return AISearchClient(
        workspace_url=workspace_url,
        service_principal_client_id="sp-client-id",
        service_principal_client_secret="sp-client-secret",
        disable_notice=True,
    )


def _build_index(workspace_url, index_url=None):
    """Construct a AISearchIndex bypassing __init__.

    Sets credential attributes so _get_token_for_request returns the cached
    tokens this fixture pre-populates, rather than calling the OAuth flow.
    """
    from databricks.ai_search.index import AISearchIndex

    idx = AISearchIndex.__new__(AISearchIndex)
    idx.workspace_url = workspace_url
    idx.index_url = index_url or f"{workspace_url}/api/2.0/vector-search/indexes/cat.sch.idx"
    idx.name = "cat.sch.idx"
    idx.endpoint_name = "test-endpoint"
    idx.personal_access_token = None
    idx.service_principal_client_id = "sp-id"
    idx.service_principal_client_secret = "sp-secret"
    idx.azure_tenant_id = None
    idx.azure_login_id = None
    idx._liteswap_traffic_id = None
    idx._use_user_passed_credentials = False
    idx.mlserving_endpoint_id = None
    idx.mlserving_endpoint_id_for_query = None
    idx.credential_strategy = None
    # __init__ is bypassed via __new__, so recreate the lock _get_token_for_request acquires.
    idx._token_refresh_lock = threading.Lock()
    idx._control_plane_oauth_token = "cp-token"
    idx._control_plane_oauth_token_expiry_ts = time.time() + 9999
    idx._read_oauth_token = "read-token"
    idx._read_oauth_token_expiry_ts = time.time() + 9999
    idx._write_oauth_token = "write-token"
    idx._write_oauth_token_expiry_ts = time.time() + 9999
    idx._index_url_ensure_reranker_compatible = None
    idx._get_reranker_url_callable = None
    idx._warned_on_deprecated_columns_to_rerank = False
    idx.total_retries = 3
    idx.backoff_factor = 1
    idx.backoff_jitter = 0.2
    return idx


@pytest.fixture
def ai_search_index_factory(workspace_url):
    """Factory for AISearchIndex instances with pre-populated tokens."""
    return lambda url=None: _build_index(workspace_url, url)


@pytest.fixture
def mock_response_factory():
    """Build a fake requests.Response-shaped mock."""

    def _make(status_code=200, json_data=None, text="", content=b""):
        resp = MagicMock()
        resp.status_code = status_code
        resp.ok = 200 <= status_code < 300
        resp.text = text
        resp.content = content
        if json_data is not None:
            resp.json.return_value = json_data
        else:
            resp.json.side_effect = ValueError("no json")
        return resp

    return _make
