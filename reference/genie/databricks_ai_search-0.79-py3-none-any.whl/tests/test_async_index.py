# ruff: noqa: E402  -- sys.modules stubs must precede SDK imports
import asyncio
import sys
import threading
import time
import unittest
from unittest.mock import AsyncMock, MagicMock, patch

# Mock modules that are unavailable in the test environment before importing
sys.modules["deprecation"] = MagicMock()
sys.modules["databricks.sdk"] = MagicMock()
sys.modules["databricks.sdk.credentials_provider"] = MagicMock()

_mock_databricks_utils = MagicMock()
_mock_databricks_utils.is_in_databricks_model_serving_environment.return_value = False
_mock_mlflow_utils = MagicMock()
_mock_mlflow_utils.databricks_utils = _mock_databricks_utils
sys.modules["mlflow"] = MagicMock()
sys.modules["mlflow.utils"] = _mock_mlflow_utils
sys.modules["mlflow.utils.databricks_utils"] = _mock_databricks_utils

from databricks.ai_search.async_index import AsyncAISearchIndex
from databricks.ai_search.client import AISearchClient
from databricks.ai_search.index import AISearchIndex


def _create_async_index(workspace_url, index_url):
    """Bypass __init__ (which does HTTP) and pre-populate state.

    Mirrors _create_index in tests/test_reranker_auth.py — both the
    AsyncAISearchIndex and its internal sync index need to be hand-built
    because the real constructor performs a blocking HTTP request.
    """
    idx = AsyncAISearchIndex.__new__(AsyncAISearchIndex)
    idx.workspace_url = workspace_url
    idx.index_url = index_url
    idx.name = "catalog.schema.test_index"
    idx.endpoint_name = "test-endpoint"
    idx.total_retries = 3
    idx.backoff_factor = 1
    idx.backoff_jitter = 0.2
    idx._closed = False
    idx._token_lock = asyncio.Lock()

    sync = AISearchIndex.__new__(AISearchIndex)
    sync.workspace_url = workspace_url
    sync.index_url = index_url
    sync.name = "catalog.schema.test_index"
    sync.endpoint_name = "test-endpoint"
    sync.personal_access_token = None
    sync.service_principal_client_id = "sp-client-id"
    sync.service_principal_client_secret = "sp-client-secret"
    sync.azure_tenant_id = None
    sync.azure_login_id = None
    sync._liteswap_traffic_id = None
    sync._use_user_passed_credentials = False
    sync.mlserving_endpoint_id = None
    sync.mlserving_endpoint_id_for_query = None
    sync.credential_strategy = None
    # __init__ is bypassed via __new__, so recreate the lock _get_token_for_request acquires.
    sync._token_refresh_lock = threading.Lock()
    sync._control_plane_oauth_token = "control-plane-token"
    sync._control_plane_oauth_token_expiry_ts = time.time() + 9999
    sync._read_oauth_token = "read-data-plane-token"
    sync._read_oauth_token_expiry_ts = time.time() + 9999
    sync._write_oauth_token = "write-data-plane-token"
    sync._write_oauth_token_expiry_ts = time.time() + 9999
    sync._index_url_ensure_reranker_compatible = None
    sync._get_reranker_url_callable = None
    sync._warned_on_deprecated_columns_to_rerank = False
    sync.total_retries = 3
    sync.backoff_factor = 1
    sync.backoff_jitter = 0.2

    idx._sync = sync
    return idx


class TestAsyncIndex(unittest.IsolatedAsyncioTestCase):
    """Verify each async data-plane wrapper produces the expected wire shape."""

    @patch(
        "databricks.ai_search.async_index.AsyncRequestUtils.issue_request",
        new_callable=AsyncMock,
    )
    async def test_internal_liteswap_traffic_id_is_sent_on_query_pages(self, mock_issue):
        idx = AsyncAISearchIndex(
            workspace_url="https://ws.databricks.com",
            index_url="https://external.example.com/serving/indexes/x",
            name="catalog.schema.test_index",
            endpoint_name="test-endpoint",
            personal_access_token="test-pat-token",
            _liteswap_traffic_id="testenv://liteswap/my-unit",
        )
        mock_issue.side_effect = [
            {
                "result": {"row_count": 1, "data_array": [["row1"]]},
                "next_page_token": "page2",
            },
            {
                "result": {"row_count": 1, "data_array": [["row2"]]},
                "next_page_token": None,
            },
        ]

        await idx.similarity_search(
            columns=["id"],
            query_text="hello",
            disable_notice=True,
        )

        self.assertEqual(mock_issue.call_count, 2)
        for call in mock_issue.call_args_list:
            self.assertEqual(
                call.kwargs["headers"],
                {"x-databricks-traffic-id": "testenv://liteswap/my-unit"},
            )

    @patch(
        "databricks.ai_search.async_index.AsyncRequestUtils.issue_request",
        new_callable=AsyncMock,
    )
    async def test_upsert_calls_issue_request_with_correct_url_and_body(self, mock_issue):
        # Data plane URL is on a different domain from the workspace, so the
        # sync token helper does not auto-promote this to a control-plane call.
        idx = _create_async_index(
            "https://ws.databricks.com",
            "https://external.example.com/serving/indexes/x",
        )
        mock_issue.return_value = {"status": "SUCCESS"}
        await idx.upsert([{"id": 1, "text": "hello"}])

        kwargs = mock_issue.call_args.kwargs
        self.assertEqual(kwargs["method"], "POST")
        self.assertTrue(kwargs["url"].endswith("/upsert-data"))
        self.assertIn("inputs_json", kwargs["json"])
        self.assertEqual(kwargs["token"], "write-data-plane-token")

    @patch(
        "databricks.ai_search.async_index.AsyncRequestUtils.issue_request",
        new_callable=AsyncMock,
    )
    async def test_delete_calls_issue_request_with_correct_url_and_body(self, mock_issue):
        idx = _create_async_index(
            "https://ws.databricks.com",
            "https://external.example.com/serving/indexes/x",
        )
        mock_issue.return_value = {"status": "SUCCESS"}
        await idx.delete(["pk1", "pk2"])

        kwargs = mock_issue.call_args.kwargs
        self.assertEqual(kwargs["method"], "DELETE")
        self.assertTrue(kwargs["url"].endswith("/delete-data"))
        self.assertEqual(kwargs["json"], {"primary_keys": ["pk1", "pk2"]})
        self.assertEqual(kwargs["token"], "write-data-plane-token")

    @patch(
        "databricks.ai_search.async_index.AsyncRequestUtils.issue_request",
        new_callable=AsyncMock,
    )
    async def test_describe_calls_issue_request_with_correct_url_and_token(self, mock_issue):
        idx = _create_async_index(
            "https://ws.databricks.com",
            "https://ws.databricks.com/serving/indexes/x",
        )
        mock_issue.return_value = {"name": "catalog.schema.test_index"}
        await idx.describe()

        kwargs = mock_issue.call_args.kwargs
        self.assertEqual(kwargs["method"], "GET")
        self.assertEqual(
            kwargs["url"],
            "https://ws.databricks.com/api/2.0/vector-search/indexes/catalog.schema.test_index",
        )
        self.assertEqual(kwargs["token"], "control-plane-token")

    @patch(
        "databricks.ai_search.async_index.AsyncRequestUtils.issue_request",
        new_callable=AsyncMock,
    )
    async def test_sync_calls_issue_request_with_correct_url_and_token(self, mock_issue):
        idx = _create_async_index(
            "https://ws.databricks.com",
            "https://ws.databricks.com/serving/indexes/x",
        )
        mock_issue.return_value = {"status": "SUCCESS"}
        await idx.sync()

        kwargs = mock_issue.call_args.kwargs
        self.assertEqual(kwargs["method"], "POST")
        self.assertTrue(kwargs["url"].endswith("/sync"))
        self.assertEqual(kwargs["token"], "control-plane-token")

    @patch(
        "databricks.ai_search.async_index.AsyncRequestUtils.issue_request",
        new_callable=AsyncMock,
    )
    async def test_scan_calls_issue_request_with_correct_payload(self, mock_issue):
        idx = _create_async_index(
            "https://ws.databricks.com",
            "https://external.example.com/serving/indexes/x",
        )
        mock_issue.return_value = {"data": []}
        await idx.scan(num_results=20)

        kwargs = mock_issue.call_args.kwargs
        self.assertEqual(kwargs["method"], "GET")
        self.assertTrue(kwargs["url"].endswith("/scan"))
        self.assertEqual(kwargs["json"]["num_results"], 20)
        self.assertEqual(kwargs["json"]["endpoint_name"], "test-endpoint")

    @patch(
        "databricks.ai_search.async_index.AsyncRequestUtils.issue_request",
        new_callable=AsyncMock,
    )
    async def test_similarity_search_with_query_text_basic(self, mock_issue):
        idx = _create_async_index(
            "https://ws.databricks.com",
            "https://external.example.com/serving/indexes/x",
        )
        mock_issue.return_value = {
            "result": {"row_count": 1, "data_array": [["row1"]]},
        }
        await idx.similarity_search(
            columns=["id", "text"],
            query_text="hello world",
            disable_notice=True,
        )

        kwargs = mock_issue.call_args.kwargs
        self.assertEqual(kwargs["method"], "GET")
        self.assertTrue(kwargs["url"].endswith("/query"))
        self.assertEqual(kwargs["json"]["query_text"], "hello world")
        self.assertEqual(kwargs["json"]["columns"], ["id", "text"])

    @patch(
        "databricks.ai_search.async_index.AsyncRequestUtils.issue_request",
        new_callable=AsyncMock,
    )
    async def test_similarity_search_with_query_vector_basic(self, mock_issue):
        idx = _create_async_index(
            "https://ws.databricks.com",
            "https://external.example.com/serving/indexes/x",
        )
        mock_issue.return_value = {
            "result": {"row_count": 1, "data_array": [["row1"]]},
        }
        await idx.similarity_search(
            columns=["id"],
            query_vector=[0.1, 0.2, 0.3],
            disable_notice=True,
        )

        kwargs = mock_issue.call_args.kwargs
        self.assertEqual(kwargs["json"]["query_vector"], [0.1, 0.2, 0.3])
        self.assertNotIn("query_text", kwargs["json"])

    @patch(
        "databricks.ai_search.async_index.AsyncRequestUtils.issue_request",
        new_callable=AsyncMock,
    )
    async def test_internal_query_source_is_sent_when_set(self, mock_issue):
        idx = _create_async_index(
            "https://ws.databricks.com",
            "https://external.example.com/serving/indexes/x",
        )
        mock_issue.return_value = {"result": {"row_count": 0, "data_array": []}}

        await idx.similarity_search(
            columns=["id"],
            query_text="generated",
            disable_notice=True,
            _query_source="LEARNED_FUSION",
        )

        self.assertEqual(mock_issue.call_args.kwargs["json"]["query_source"], "LEARNED_FUSION")

    @patch(
        "databricks.ai_search.async_index.AsyncRequestUtils.issue_request",
        new_callable=AsyncMock,
    )
    async def test_similarity_search_advanced_fts_fields(self, mock_issue):
        idx = _create_async_index(
            "https://ws.databricks.com",
            "https://external.example.com/serving/indexes/x",
        )
        mock_issue.return_value = {
            "result": {"row_count": 0, "data_array": []},
        }
        await idx.similarity_search(
            columns=["id"],
            query_text="x",
            query_columns=["title", "body"],
            sort_columns=["rating DESC"],
            facets=["brand", "category TOP 5"],
            disable_notice=True,
        )
        kwargs = mock_issue.call_args.kwargs
        self.assertEqual(kwargs["json"]["query_columns"], ["title", "body"])
        self.assertEqual(kwargs["json"]["sort_columns"], ["rating DESC"])
        self.assertEqual(kwargs["json"]["facets"], ["brand", "category TOP 5"])

    @patch(
        "databricks.ai_search.async_index.AsyncRequestUtils.issue_request",
        new_callable=AsyncMock,
    )
    async def test_similarity_search_paginates_across_pages(self, mock_issue):
        idx = _create_async_index(
            "https://ws.databricks.com",
            "https://external.example.com/serving/indexes/x",
        )
        mock_issue.side_effect = [
            {
                "result": {"row_count": 1, "data_array": [["row1"]]},
                "next_page_token": "page2",
            },
            {
                "result": {"row_count": 1, "data_array": [["row2"]]},
                "next_page_token": None,
            },
        ]
        result = await idx.similarity_search(
            columns=["id"],
            query_text="hello",
            disable_notice=True,
        )

        self.assertEqual(mock_issue.call_count, 2)
        self.assertEqual(result["result"]["row_count"], 2)
        self.assertEqual(result["result"]["data_array"], [["row1"], ["row2"]])
        self.assertNotIn("next_page_token", result)

    @patch(
        "databricks.ai_search.async_index.AsyncRequestUtils.issue_request",
        new_callable=AsyncMock,
    )
    async def test_similarity_search_with_reranker_uses_control_plane_token(self, mock_issue):
        workspace_url = "https://my-workspace.cloud.databricks.com"
        index_url = workspace_url + "/api/2.0/vector-search/indexes/catalog.schema.test_index"
        idx = _create_async_index(workspace_url, index_url)
        external_reranker_url = "https://external-self-managed.example.com" "/serving/indexes/catalog.schema.test_index"
        idx._sync._index_url_ensure_reranker_compatible = external_reranker_url

        mock_issue.side_effect = [
            {
                "result": {"row_count": 1, "data_array": [["row1"]]},
                "next_page_token": "page2",
            },
            {
                "result": {"row_count": 1, "data_array": [["row2"]]},
                "next_page_token": None,
            },
        ]

        await idx.similarity_search(
            columns=["col1"],
            query_text="test query",
            columns_to_rerank=["col1"],
            disable_notice=True,
        )

        for call_index, call in enumerate(mock_issue.call_args_list):
            self.assertEqual(
                call.kwargs["token"],
                "control-plane-token",
                f"Request #{call_index} should use control-plane token",
            )

    async def test_concurrent_upserts_all_succeed(self):
        """Concurrent upserts must all return successfully.

        The async path intentionally does not serialize OAuth refresh — sync
        does not either, and racing refreshes are benign because each writes
        a valid token (last write wins). See PR writeup for details.
        """
        idx = _create_async_index(
            "https://ws.databricks.com",
            "https://external.example.com/serving/indexes/x",
        )
        with patch(
            "databricks.ai_search.async_index.AsyncRequestUtils.issue_request",
            new_callable=AsyncMock,
        ) as mock_issue:
            mock_issue.return_value = {"status": "SUCCESS"}

            async def fire():
                return await idx.upsert([{"id": 1}])

            results = await asyncio.gather(*[fire() for _ in range(50)])

        self.assertEqual(len(results), 50)
        self.assertTrue(all(r == {"status": "SUCCESS"} for r in results))

    async def test_aclose_is_idempotent(self):
        idx = _create_async_index(
            "https://ws.databricks.com",
            "https://ws.databricks.com/serving/indexes/x",
        )
        await idx.aclose()
        await idx.aclose()  # second close must not raise

    async def test_async_with_marks_instance_closed(self):
        # `aclose()` only flips the `_closed` flag on the instance — the
        # per-loop httpx pool is shared module state and stays open.
        idx = _create_async_index(
            "https://ws.databricks.com",
            "https://ws.databricks.com/serving/indexes/x",
        )
        async with idx as entered:
            self.assertIs(entered, idx)
            self.assertFalse(idx._closed)
        self.assertTrue(idx._closed)


_FAKE_INDEX_RESP = {
    "status": {"index_url": "https://external.example.com/serving/indexes/cat.schema.my_idx"},
    "endpoint_name": "my-endpoint",
    "creator": "user@example.com",
}


class TestGetAsyncIndex(unittest.TestCase):
    """Verify AISearchClient.get_async_index constructs AsyncAISearchIndex correctly."""

    def _make_client(self):
        """Return a minimal AISearchClient that skips live HTTP.

        Service principal credentials so _get_index_url honors the
        data-plane URL from the index response (PAT-only auth would route
        through the control-plane URL).
        """
        return AISearchClient(
            workspace_url="https://ws.databricks.com",
            service_principal_client_id="sp-id",
            service_principal_client_secret="sp-secret",
            disable_notice=True,
        )

    @patch(
        "databricks.ai_search.client.OAuthTokenUtils.get_oauth_token",
        return_value={"access_token": "tok", "expires_in": 3600},
    )
    @patch("databricks.ai_search.client.RequestUtils.issue_request")
    def test_returns_async_index_with_correct_fields(self, mock_issue, _mock_oauth):
        mock_issue.return_value = _FAKE_INDEX_RESP

        client = self._make_client()
        idx = client.get_async_index(
            endpoint_name="my-endpoint",
            index_name="catalog.schema.my_idx",
        )

        self.assertIsInstance(idx, AsyncAISearchIndex)
        self.assertEqual(idx.name, "catalog.schema.my_idx")
        self.assertEqual(
            idx.index_url,
            "https://external.example.com/serving/indexes/cat.schema.my_idx",
        )
        # endpoint_name comes from the response, not the caller's kwarg
        self.assertEqual(idx.endpoint_name, "my-endpoint")

    @patch("databricks.ai_search.client.RequestUtils.issue_request")
    def test_raises_assertion_error_when_index_name_is_none(self, mock_issue):
        client = self._make_client()
        with self.assertRaises(AssertionError):
            client.get_async_index(endpoint_name="my-endpoint", index_name=None)

        # The guard fires before any HTTP call is made.
        mock_issue.assert_not_called()


if __name__ == "__main__":
    unittest.main()
