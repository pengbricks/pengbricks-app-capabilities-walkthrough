# ruff: noqa: E402  -- sys.modules stubs must precede SDK imports
import unittest
from unittest.mock import patch, MagicMock
import os
import json
import threading
from collections import namedtuple

# Mock the problematic modules before importing
import sys

sys.modules["databricks.sdk"] = MagicMock()
sys.modules["databricks.sdk.credentials_provider"] = MagicMock()
sys.modules["mlflow.utils.databricks_utils"] = MagicMock()

from databricks.ai_search.client import AISearchClient
from databricks.ai_search.utils import CredentialStrategy


class TestAISearchClient(unittest.TestCase):
    """Test cases for the AISearchClient authentication in model serving environments."""

    def setUp(self):
        """Set up test environment before each test method."""
        # Define constants
        self.api_token = os.environ.get("DATABRICKS_TEST_TOKEN", "test-token-default")
        self.invalid_api_token = "dapi12345"
        self.WORKSPACE_URL = "https://e2-dogfood.staging.cloud.databricks.com"
        # Use main_thread instead of current_thread to match utils.py changes
        self.THREAD_DATA = threading.main_thread().__dict__

        # Set up environment variables
        os.environ["IS_IN_DB_MODEL_SERVING_ENV"] = "true"
        os.environ["DATABRICKS_MODEL_SERVING_HOST_URL"] = self.WORKSPACE_URL
        os.environ["DB_MODEL_SERVING_HOST_URL"] = self.WORKSPACE_URL

        # Create credential files for testing
        oauth_data_good = {"OAUTH_TOKEN": [{"oauthTokenValue": self.api_token}]}
        oauth_data_bad = {"OAUTH_TOKEN": [{"oauthTokenValue": self.invalid_api_token}]}

        # Create credential files
        with open("./good-creds", "w") as json_file:
            json.dump(oauth_data_good, json_file, indent=4)
        with open("./bad-creds", "w") as json_file:
            json.dump(oauth_data_bad, json_file, indent=4)

        # Create namedtuple for host credentials
        self.FakeCredsTuple = namedtuple("FakeCreds", ["host", "token"])

    def tearDown(self):
        """Clean up after each test method."""
        # Remove credential files
        try:
            os.remove("./good-creds")
            os.remove("./bad-creds")
        except FileNotFoundError:
            pass

    def set_valid_token(self):
        self.THREAD_DATA["invokers_token"] = self.api_token
        # Mock the credential provider paths
        if "databricks.sdk.credentials_provider" in sys.modules:
            mock_provider = sys.modules["databricks.sdk.credentials_provider"]
            mock_provider.ModelServingAuthProvider = MagicMock()
            mock_provider.ModelServingAuthProvider._MODEL_DEPENDENCY_OAUTH_TOKEN_FILE_PATH = "./good-creds"

        if "mlflow.utils.databricks_utils" in sys.modules:
            mock_mlflow = sys.modules["mlflow.utils.databricks_utils"]
            mock_mlflow._MODEL_DEPENDENCY_OAUTH_TOKEN_FILE_PATH = "./good-creds"

    def set_invalid_token(self):
        """Set invalid token for testing."""
        self.THREAD_DATA["invokers_token"] = self.invalid_api_token
        # Mock the credential provider paths
        if "databricks.sdk.credentials_provider" in sys.modules:
            mock_provider = sys.modules["databricks.sdk.credentials_provider"]
            mock_provider.ModelServingAuthProvider = MagicMock()
            mock_provider.ModelServingAuthProvider._MODEL_DEPENDENCY_OAUTH_TOKEN_FILE_PATH = "./bad-creds"

        if "mlflow.utils.databricks_utils" in sys.modules:
            mock_mlflow = sys.modules["mlflow.utils.databricks_utils"]
            mock_mlflow._MODEL_DEPENDENCY_OAUTH_TOKEN_FILE_PATH = "./bad-creds"

        os.environ["DB_DEPENDENCY_OAUTH_CACHE_EXPIRY_TS"] = "0"

    def expect_invalid_client_call(self, client):
        """Assert that client call raises an exception."""
        with self.assertRaises(Exception):
            client.list_endpoints()

    @patch("os.path.isfile", return_value=True)
    def test_model_serving_user_credentials(self, mock_isfile):
        """Test MODEL_SERVING_USER_CREDENTIALS credential strategy."""
        # Mock the mlflowserving import to test fallback behavior
        with patch("databricks.ai_search.utils._get_invokers_token_from_mlflowserving") as mock_get_token:
            # Test with valid token using fallback path
            mock_get_token.return_value = self.api_token
            self.set_valid_token()

            # Mock the client's list_endpoints method to avoid actual API calls
            with patch.object(AISearchClient, "list_endpoints", return_value=["endpoint1", "endpoint2"]):
                vsc = AISearchClient(credential_strategy=CredentialStrategy.MODEL_SERVING_USER_CREDENTIALS)
                try:
                    endpoints = vsc.list_endpoints()
                    self.assertIsNotNone(endpoints)  # Verify we get a response
                except Exception as e:
                    self.fail(f"Valid token should not raise exception: {e}")

            # Test with invalid token
            mock_get_token.return_value = self.invalid_api_token
            self.set_invalid_token()

            with patch.object(AISearchClient, "list_endpoints", side_effect=Exception("Invalid token")):
                vsc = AISearchClient(credential_strategy=CredentialStrategy.MODEL_SERVING_USER_CREDENTIALS)
                self.expect_invalid_client_call(vsc)

            # Test with valid token again
            mock_get_token.return_value = self.api_token
            self.set_valid_token()

            with patch.object(AISearchClient, "list_endpoints", return_value=["endpoint1", "endpoint2"]):
                try:
                    endpoints = vsc.list_endpoints()
                    self.assertIsNotNone(endpoints)  # Verify we get a response
                except Exception as e:
                    self.fail(f"Valid token should not raise exception: {e}")

    @patch("os.path.isfile", return_value=True)
    def test_model_serving_user_credentials_with_mlflowserving_import(self, mock_isfile):
        """Test MODEL_SERVING_USER_CREDENTIALS with successful mlflowserving import."""
        # Mock the fetch_obo_token function to simulate successful import
        mock_fetch_obo_token = MagicMock()
        mock_fetch_obo_token.return_value = self.api_token

        with patch.dict(
            "sys.modules",
            {
                "mlflowserving": MagicMock(),
                "mlflowserving.scoring_server": MagicMock(),
                "mlflowserving.scoring_server.agent_utils": MagicMock(),
            },
        ):
            with patch("mlflowserving.scoring_server.agent_utils.fetch_obo_token", mock_fetch_obo_token):
                self.set_valid_token()

                with patch.object(AISearchClient, "list_endpoints", return_value=["endpoint1", "endpoint2"]):
                    vsc = AISearchClient(credential_strategy=CredentialStrategy.MODEL_SERVING_USER_CREDENTIALS)
                    try:
                        endpoints = vsc.list_endpoints()
                        self.assertIsNotNone(endpoints)  # Verify we get a response
                        mock_fetch_obo_token.assert_called()
                    except Exception as e:
                        self.fail(f"Valid token should not raise exception: {e}")

    @patch("os.path.isfile", return_value=True)
    def test_model_serving_user_credentials_fallback_to_thread_data(self, mock_isfile):
        """Test MODEL_SERVING_USER_CREDENTIALS fallback to thread data when mlflowserving import fails."""
        # Test the fallback path when mlflowserving import fails
        with patch("databricks.ai_search.utils._get_invokers_token_from_mlflowserving") as mock_get_token:
            # Simulate ImportError and fallback to thread data
            mock_get_token.side_effect = lambda: self.THREAD_DATA.get("invokers_token")

            self.set_valid_token()

            with patch.object(AISearchClient, "list_endpoints", return_value=["endpoint1", "endpoint2"]):
                vsc = AISearchClient(credential_strategy=CredentialStrategy.MODEL_SERVING_USER_CREDENTIALS)
                try:
                    endpoints = vsc.list_endpoints()
                    self.assertIsNotNone(endpoints)  # Verify we get a response
                except Exception as e:
                    self.fail(f"Valid token should not raise exception: {e}")

    @patch("os.path.isfile", return_value=True)
    def test_standard_creds(self, mock_isfile):
        """Test standard credentials with get_databricks_host_creds."""
        # Create fake credentials
        good_creds = self.FakeCredsTuple(self.WORKSPACE_URL, self.api_token)
        bad_creds = self.FakeCredsTuple(self.WORKSPACE_URL, self.invalid_api_token)

        # Test with good credentials
        with patch.object(
            sys.modules["mlflow.utils.databricks_utils"], "get_databricks_host_creds", return_value=good_creds
        ):
            self.set_valid_token()

            with patch.object(AISearchClient, "list_endpoints", return_value=["endpoint1", "endpoint2"]):
                vsc = AISearchClient()
                try:
                    vsc.list_endpoints()
                except Exception as e:
                    self.fail(f"Valid credentials should not raise exception: {e}")

        # Test with bad credentials
        with patch.object(
            sys.modules["mlflow.utils.databricks_utils"], "get_databricks_host_creds", return_value=bad_creds
        ):
            self.set_invalid_token()

            with patch.object(AISearchClient, "list_endpoints", side_effect=Exception("Invalid credentials")):
                vsc = AISearchClient()
                self.expect_invalid_client_call(vsc)

        # Test with good credentials again
        with patch.object(
            sys.modules["mlflow.utils.databricks_utils"], "get_databricks_host_creds", return_value=good_creds
        ):
            self.set_valid_token()

            with patch.object(AISearchClient, "list_endpoints", return_value=["endpoint1", "endpoint2"]):
                try:
                    endpoints = vsc.list_endpoints()
                    self.assertIsNotNone(endpoints)  # Verify we get a response
                except Exception as e:
                    self.fail(f"Valid credentials should not raise exception: {e}")

    def test_user_credentials(self):
        self.set_invalid_token()

        with patch.object(AISearchClient, "list_endpoints", return_value=["endpoint1", "endpoint2"]):
            vsc = AISearchClient(workspace_url=self.WORKSPACE_URL, personal_access_token=self.api_token)
            try:
                vsc.list_endpoints()
            except Exception as e:
                self.fail(f"Should load user credentials: {e}")

    def test_pat_credentials_skip_mlflow(self):
        """Regression test: Verify that explicit PAT credentials do not trigger MLflow calls.

        This test ensures that when users provide both workspace_url and personal_access_token,
        the client does not call mlflow.utils.databricks_utils.get_databricks_host_creds(),
        which would fail in environments without MLflow configuration.

        Bug reference: MLFLOW_INTEGRATION_ANALYSIS.md Section 5 - PAT Credential Bug
        """
        # Create a mock that will fail if called (to ensure MLflow is NOT called)
        mock_get_databricks_host_creds = MagicMock(
            side_effect=Exception("MLflow should not be called when PAT credentials are provided!")
        )

        with patch.object(
            sys.modules["mlflow.utils.databricks_utils"], "get_databricks_host_creds", mock_get_databricks_host_creds
        ):
            # Create client with explicit PAT credentials
            vsc = AISearchClient(workspace_url=self.WORKSPACE_URL, personal_access_token=self.api_token)

            # Verify client was created successfully without calling MLflow
            self.assertEqual(vsc.workspace_url, self.WORKSPACE_URL)
            self.assertEqual(vsc.personal_access_token, self.api_token)
            self.assertTrue(vsc._using_user_passed_credentials)

            # Verify MLflow was NOT called
            mock_get_databricks_host_creds.assert_not_called()

    def test_service_principal_credentials_skip_mlflow(self):
        """Verify that service principal credentials do not trigger MLflow calls.

        This test ensures that when users provide service principal credentials,
        the client does not call mlflow.utils.databricks_utils.get_databricks_host_creds().
        """
        # Create a mock that will fail if called (to ensure MLflow is NOT called)
        mock_get_databricks_host_creds = MagicMock(
            side_effect=Exception("MLflow should not be called when service principal credentials are provided!")
        )

        with patch.object(
            sys.modules["mlflow.utils.databricks_utils"], "get_databricks_host_creds", mock_get_databricks_host_creds
        ):
            # Create client with service principal credentials
            vsc = AISearchClient(
                workspace_url=self.WORKSPACE_URL,
                service_principal_client_id="test-sp-id",
                service_principal_client_secret="test-sp-secret",
            )

            # Verify client was created successfully without calling MLflow
            self.assertEqual(vsc.workspace_url, self.WORKSPACE_URL)
            self.assertEqual(vsc.service_principal_client_id, "test-sp-id")
            self.assertEqual(vsc.service_principal_client_secret, "test-sp-secret")
            self.assertTrue(vsc._using_user_passed_credentials)

            # Verify MLflow was NOT called
            mock_get_databricks_host_creds.assert_not_called()


if __name__ == "__main__":
    unittest.main()
