# ruff: noqa: E402  -- sys.modules stubs must precede SDK imports
"""Smoke tests for the databricks-ai-search package.

Verifies that the package is importable, exposes the correct version, and that
the backward-compat aliases (``VectorSearchClient`` / ``VectorSearchIndex`` /
``VectorSearchException``) point to the canonical AI* classes."""

import sys
import unittest
from unittest.mock import MagicMock


class TestAISearchPackage(unittest.TestCase):
    def test_package_is_importable(self):
        import databricks.ai_search  # noqa: F401

    def test_version(self):
        from databricks.ai_search import __version__

        self.assertEqual(__version__, "0.79")

    def _install_external_mocks(self):
        """Install mocks for external deps required to import the client/index
        modules. Returns a snapshot of sys.modules taken before installing the
        mocks; pass it to ``_restore_modules`` to roll back."""
        original = sys.modules.copy()
        mlflow_dbu = MagicMock()
        mlflow_dbu.is_in_databricks_model_serving_environment.return_value = False
        mlflow_utils = MagicMock()
        mlflow_utils.databricks_utils = mlflow_dbu
        sys.modules.setdefault("deprecation", MagicMock())
        sys.modules.setdefault("databricks.sdk", MagicMock())
        sys.modules.setdefault("databricks.sdk.credentials_provider", MagicMock())
        sys.modules.setdefault("mlflow", MagicMock())
        sys.modules.setdefault("mlflow.utils", mlflow_utils)
        sys.modules.setdefault("mlflow.utils.databricks_utils", mlflow_dbu)
        return original

    def _restore_modules(self, original):
        for name in list(sys.modules):
            if name not in original:
                del sys.modules[name]
            elif sys.modules[name] is not original[name]:
                sys.modules[name] = original[name]

    def test_vector_search_client_alias_points_to_ai_search_client(self):
        original = self._install_external_mocks()
        try:
            from databricks.ai_search.client import (
                AISearchClient,
                VectorSearchClient,
            )

            # Same object: type identity preserved, isinstance works either way.
            self.assertIs(VectorSearchClient, AISearchClient)
        finally:
            self._restore_modules(original)

    def test_vector_search_index_alias_points_to_ai_search_index(self):
        original = self._install_external_mocks()
        try:
            from databricks.ai_search.index import (
                AISearchIndex,
                VectorSearchIndex,
            )

            self.assertIs(VectorSearchIndex, AISearchIndex)
        finally:
            self._restore_modules(original)

    def test_vector_search_exception_alias_points_to_ai_search_exception(self):
        # exceptions.py has no heavy deps, so no mocks required.
        original = sys.modules.copy()
        try:
            from databricks.ai_search.exceptions import (
                AISearchException,
                VectorSearchException,
            )

            self.assertIs(VectorSearchException, AISearchException)
            # Subclasses still inherit from AISearchException.
            from databricks.ai_search.exceptions import NotFound

            self.assertTrue(issubclass(NotFound, AISearchException))
            self.assertTrue(issubclass(NotFound, VectorSearchException))
        finally:
            self._restore_modules(original)
