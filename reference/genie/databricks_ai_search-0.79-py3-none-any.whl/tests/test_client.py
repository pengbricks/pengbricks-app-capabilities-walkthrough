"""Tests for databricks.ai_search.client.AISearchClient."""

from unittest.mock import Mock, patch

import pytest

from databricks.ai_search.client import AISearchClient
from databricks.ai_search.exceptions import InvalidInputException, NotFound
from databricks.ai_search.index import AISearchIndex


class TestAISearchClientInit:
    def test_pat_credentials_stored(self):
        client = AISearchClient(
            workspace_url="https://ws",
            personal_access_token="dapi...",
            disable_notice=True,
        )
        assert client.workspace_url == "https://ws"
        assert client.personal_access_token == "dapi..."
        assert client._using_user_passed_credentials is True
        assert client._is_notebook_pat is False

    def test_service_principal_credentials_stored(self):
        client = AISearchClient(
            workspace_url="https://ws",
            service_principal_client_id="id",
            service_principal_client_secret="secret",
            disable_notice=True,
        )
        assert client.service_principal_client_id == "id"
        assert client.service_principal_client_secret == "secret"
        assert client._using_user_passed_credentials is True

    def test_azure_login_id_defaults_to_public(self):
        client = AISearchClient(
            workspace_url="https://ws",
            personal_access_token="x",
            disable_notice=True,
        )
        assert client.azure_login_id == "2ff814a6-3304-4ab8-85cb-cd0e6f879c1d"

    def test_pat_missing_workspace_url_raises_invalid_input(self):
        with pytest.raises(InvalidInputException, match="Workspace URL is required"):
            AISearchClient(personal_access_token="dapi", disable_notice=True)

    def test_no_credentials_raises_invalid_input(self):
        # With user-passed creds path off and a workspace_url provided, validate()
        # raises because neither PAT nor SP are set.
        client = AISearchClient.__new__(AISearchClient)
        client.workspace_url = "https://ws"
        client.personal_access_token = None
        client.service_principal_client_id = None
        client.service_principal_client_secret = None
        client._using_user_passed_credentials = False
        client._is_notebook_pat = False
        with pytest.raises(InvalidInputException, match="personal access token or service principal"):
            client.validate(disable_notice=True)


class TestGetTokenForRequest:
    def test_pat_returns_pat(self):
        client = AISearchClient(
            workspace_url="https://ws",
            personal_access_token="pat-value",
            disable_notice=True,
        )
        assert client._get_token_for_request() == "pat-value"

    @patch("databricks.ai_search.client.OAuthTokenUtils.get_oauth_token")
    def test_sp_fetches_and_caches_oauth_token(self, mock_oauth):
        mock_oauth.return_value = {"access_token": "oauth-tok", "expires_in": 3600}
        client = AISearchClient(
            workspace_url="https://ws",
            service_principal_client_id="id",
            service_principal_client_secret="secret",
            disable_notice=True,
        )
        token1 = client._get_token_for_request()
        token2 = client._get_token_for_request()
        assert token1 == "oauth-tok"
        assert token2 == "oauth-tok"
        # Only one network call thanks to in-memory cache.
        mock_oauth.assert_called_once()

    @patch("databricks.ai_search.client.OAuthTokenUtils.get_azure_oauth_token")
    def test_azure_sp_routes_through_azure_oauth(self, mock_azure):
        mock_azure.return_value = {"access_token": "azure-tok", "expires_in": 3600}
        client = AISearchClient(
            workspace_url="https://ws",
            service_principal_client_id="id",
            service_principal_client_secret="secret",
            azure_tenant_id="tenant",
            disable_notice=True,
        )
        assert client._get_token_for_request() == "azure-tok"
        mock_azure.assert_called_once()

    def test_no_credentials_raises(self):
        client = AISearchClient.__new__(AISearchClient)
        client.workspace_url = "https://ws"
        client.personal_access_token = None
        client.service_principal_client_id = None
        client.service_principal_client_secret = None
        client.azure_tenant_id = None
        client._using_user_passed_credentials = True
        client._control_plane_oauth_token = None
        client._control_plane_oauth_token_expiry_ts = None
        client.credential_strategy = None
        with pytest.raises(Exception, match="service principal or PAT"):
            client._get_token_for_request()


class TestEndpointCRUD:
    @patch("databricks.ai_search.client.RequestUtils.issue_request")
    def test_internal_liteswap_traffic_id_is_sent_as_header(self, mock_req, workspace_url):
        mock_req.return_value = {"endpoints": []}
        client = AISearchClient(
            workspace_url=workspace_url,
            personal_access_token="test-pat-token",
            disable_notice=True,
            _liteswap_traffic_id="testenv://liteswap/my-unit",
        )

        client.list_endpoints()

        assert mock_req.call_args.kwargs["headers"] == {"x-databricks-traffic-id": "testenv://liteswap/my-unit"}

    @patch("databricks.ai_search.client.RequestUtils.issue_request")
    def test_headers_are_omitted_without_internal_liteswap_traffic_id(self, mock_req, aisc_with_pat):
        mock_req.return_value = {"endpoints": []}
        aisc_with_pat.list_endpoints()

        assert "headers" not in mock_req.call_args.kwargs

    @patch("databricks.ai_search.client.RequestUtils.issue_request")
    def test_create_endpoint_posts_payload(self, mock_req, aisc_with_pat, workspace_url):
        mock_req.return_value = {"endpoint": {}}
        aisc_with_pat.create_endpoint("my-ep", endpoint_type="STANDARD")
        call = mock_req.call_args.kwargs
        assert call["method"] == "POST"
        assert call["url"] == f"{workspace_url}/api/2.0/vector-search/endpoints"
        assert call["json"] == {"name": "my-ep", "endpoint_type": "STANDARD"}

    def test_create_endpoint_rejects_both_policy_ids(self, aisc_with_pat):
        with pytest.raises(InvalidInputException):
            aisc_with_pat.create_endpoint("ep", budget_policy_id="b", usage_policy_id="u")

    def test_create_endpoint_rejects_non_int_target_qps(self, aisc_with_pat):
        with pytest.raises(InvalidInputException, match="must be an integer"):
            aisc_with_pat.create_endpoint("ep", target_qps="big")

    def test_create_endpoint_rejects_non_positive_target_qps(self, aisc_with_pat):
        with pytest.raises(InvalidInputException, match="positive integer"):
            aisc_with_pat.create_endpoint("ep", target_qps=0)

    @patch("databricks.ai_search.client.RequestUtils.issue_request")
    def test_create_endpoint_includes_target_qps_and_policy(self, mock_req, aisc_with_pat):
        mock_req.return_value = {}
        aisc_with_pat.create_endpoint("ep", target_qps=50, usage_policy_id="up")
        body = mock_req.call_args.kwargs["json"]
        assert body["target_qps"] == 50
        assert body["budget_policy_id"] == "up"

    @patch("databricks.ai_search.client.RequestUtils.issue_request")
    def test_get_endpoint_hits_endpoint_url(self, mock_req, aisc_with_pat, workspace_url):
        mock_req.return_value = {"endpoint": {"state": "ONLINE"}}
        result = aisc_with_pat.get_endpoint("my-ep")
        assert result == {"endpoint": {"state": "ONLINE"}}
        assert mock_req.call_args.kwargs["url"] == (f"{workspace_url}/api/2.0/vector-search/endpoints/my-ep")
        assert mock_req.call_args.kwargs["method"] == "GET"

    @patch("databricks.ai_search.client.RequestUtils.issue_request")
    def test_endpoint_exists_true_on_success(self, mock_req, aisc_with_pat):
        mock_req.return_value = {}
        assert aisc_with_pat.endpoint_exists("ep") is True

    @patch("databricks.ai_search.client.RequestUtils.issue_request")
    def test_endpoint_exists_false_on_not_found(self, mock_req, aisc_with_pat):
        mock_req.side_effect = NotFound("nope", status_code=404)
        assert aisc_with_pat.endpoint_exists("ep") is False

    @patch("databricks.ai_search.client.RequestUtils.issue_request")
    def test_list_endpoints_calls_endpoints_url(self, mock_req, aisc_with_pat, workspace_url):
        mock_req.return_value = {"endpoints": []}
        aisc_with_pat.list_endpoints()
        assert mock_req.call_args.kwargs["url"] == (f"{workspace_url}/api/2.0/vector-search/endpoints")

    @patch("databricks.ai_search.client.RequestUtils.issue_request")
    def test_list_endpoints_normalizes_camelcase_keys(self, mock_req, aisc_with_pat):
        # Direct-DP (Rust) returns camelCase; callers must get stable snake_case.
        mock_req.return_value = {"endpoints": [{"endpointStatus": {"readyState": "ONLINE"}}]}
        result = aisc_with_pat.list_endpoints()
        assert result == {"endpoints": [{"endpoint_status": {"ready_state": "ONLINE"}}]}

    @patch("databricks.ai_search.client.RequestUtils.issue_request")
    def test_list_endpoints_snake_case_passthrough(self, mock_req, aisc_with_pat):
        # CP (Scala) already returns snake_case; normalization must be a no-op.
        snake = {"endpoints": [{"endpoint_status": {"ready_state": "ONLINE"}}]}
        mock_req.return_value = snake
        assert aisc_with_pat.list_endpoints() == snake

    @patch("databricks.ai_search.client.RequestUtils.issue_request")
    def test_get_endpoint_normalizes_camelcase_keys(self, mock_req, aisc_with_pat):
        mock_req.return_value = {"endpointStatus": {"state": "ONLINE"}}
        assert aisc_with_pat.get_endpoint("ep") == {"endpoint_status": {"state": "ONLINE"}}

    @patch("databricks.ai_search.client.RequestUtils.issue_request")
    def test_delete_endpoint_issues_delete(self, mock_req, aisc_with_pat, workspace_url):
        mock_req.return_value = {}
        aisc_with_pat.delete_endpoint("my-ep")
        call = mock_req.call_args.kwargs
        assert call["method"] == "DELETE"
        assert call["url"] == f"{workspace_url}/api/2.0/vector-search/endpoints/my-ep"

    @patch("databricks.ai_search.client.RequestUtils.issue_request")
    def test_update_endpoint_target_qps_payload(self, mock_req, aisc_with_pat, workspace_url):
        mock_req.return_value = {}
        aisc_with_pat.update_endpoint("ep", target_qps=200)
        call = mock_req.call_args.kwargs
        assert call["method"] == "PATCH"
        assert call["url"] == f"{workspace_url}/api/2.0/vector-search/endpoints/ep"
        assert call["json"] == {"target_qps": 200}

    @patch("databricks.ai_search.client.RequestUtils.issue_request")
    def test_update_endpoint_accepts_minus_one_reset_literal(self, mock_req, aisc_with_pat):
        # The validator still accepts -1 (the internal reset sentinel) for
        # back-compat even though it's no longer advertised as a public API.
        mock_req.return_value = {}
        aisc_with_pat.update_endpoint("ep", target_qps=-1)
        assert mock_req.call_args.kwargs["json"] == {"target_qps": -1}

    def test_update_endpoint_rejects_empty_name(self, aisc_with_pat):
        with pytest.raises(InvalidInputException, match="Endpoint name"):
            aisc_with_pat.update_endpoint(name="")

    def test_update_endpoint_rejects_invalid_target_qps(self, aisc_with_pat):
        with pytest.raises(InvalidInputException, match="positive integer"):
            aisc_with_pat.update_endpoint("ep", target_qps=0)

    @patch("databricks.ai_search.client.RequestUtils.issue_request")
    def test_update_endpoint_budget_policy_uses_budget_field(self, mock_req, aisc_with_pat, workspace_url):
        mock_req.return_value = {}
        aisc_with_pat.update_endpoint_budget_policy("ep", usage_policy_id="up")
        call = mock_req.call_args.kwargs
        assert call["url"] == (f"{workspace_url}/api/2.0/vector-search/endpoints/ep/budget-policy")
        assert call["json"] == {"budget_policy_id": "up"}

    def test_update_endpoint_budget_policy_rejects_both(self, aisc_with_pat):
        with pytest.raises(InvalidInputException):
            aisc_with_pat.update_endpoint_budget_policy("ep", budget_policy_id="b", usage_policy_id="u")

    def test_update_endpoint_budget_policy_rejects_neither(self, aisc_with_pat):
        with pytest.raises(InvalidInputException):
            aisc_with_pat.update_endpoint_budget_policy("ep")


class TestWaitForEndpoint:
    @patch("databricks.ai_search.client.time.sleep")
    @patch("databricks.ai_search.client.RequestUtils.issue_request")
    def test_polls_until_online(self, mock_req, mock_sleep, aisc_with_pat):
        mock_req.side_effect = [
            {"endpoint_status": {"state": "PROVISIONING"}},
            {"endpoint_status": {"state": "ONLINE"}},
        ]
        aisc_with_pat.wait_for_endpoint("ep")
        assert mock_req.call_count == 2

    @patch("databricks.ai_search.client.time.sleep")
    @patch("databricks.ai_search.client.RequestUtils.issue_request")
    def test_raises_on_offline(self, mock_req, _sleep, aisc_with_pat):
        mock_req.return_value = {"endpoint_status": {"state": "OFFLINE"}}
        with pytest.raises(Exception, match="OFFLINE"):
            aisc_with_pat.wait_for_endpoint("ep")


class TestIndexCRUD:
    @patch("databricks.ai_search.client.RequestUtils.issue_request")
    def test_internal_liteswap_traffic_id_propagates_to_index(self, mock_req, workspace_url):
        mock_req.return_value = {
            "status": {"index_url": "https://dp/idx"},
            "endpoint_name": "ep",
        }
        client = AISearchClient(
            workspace_url=workspace_url,
            personal_access_token="test-pat-token",
            disable_notice=True,
            _liteswap_traffic_id="testenv://liteswap/my-unit",
        )

        idx = client.get_index(endpoint_name="ep", index_name="cat.sch.idx")

        assert idx._liteswap_traffic_id == "testenv://liteswap/my-unit"

    @patch("databricks.ai_search.client.RequestUtils.issue_request")
    def test_create_delta_sync_index_returns_index(self, mock_req, aisc_with_pat):
        mock_req.return_value = {
            "name": "cat.sch.idx",
            "status": {"index_url": "https://dp/index"},
        }
        idx = aisc_with_pat.create_delta_sync_index(
            endpoint_name="ep",
            index_name="cat.sch.idx",
            primary_key="id",
            source_table_name="cat.sch.source",
            pipeline_type="TRIGGERED",
            embedding_dimension=768,
            embedding_vector_column="emb",
        )
        assert isinstance(idx, AISearchIndex)
        body = mock_req.call_args.kwargs["json"]
        assert body["name"] == "cat.sch.idx"
        assert body["index_type"] == "DELTA_SYNC"
        assert body["delta_sync_index_spec"]["pipeline_type"] == "TRIGGERED"
        assert "payload_logging_enabled" not in body

    @pytest.mark.parametrize("payload_logging_enabled", [True, False])
    @patch("databricks.ai_search.client.RequestUtils.issue_request")
    def test_create_delta_sync_index_sets_payload_logging(self, mock_req, aisc_with_pat, payload_logging_enabled):
        mock_req.return_value = {
            "name": "cat.sch.idx",
            "status": {"index_url": "https://dp/index"},
        }
        aisc_with_pat.create_delta_sync_index(
            endpoint_name="ep",
            index_name="cat.sch.idx",
            primary_key="id",
            source_table_name="cat.sch.source",
            pipeline_type="TRIGGERED",
            embedding_dimension=768,
            embedding_vector_column="emb",
            payload_logging_enabled=payload_logging_enabled,
        )
        assert mock_req.call_args.kwargs["json"]["payload_logging_enabled"] is payload_logging_enabled

    def test_create_delta_sync_index_and_wait_preserves_legacy_override(self, workspace_url):
        index = Mock()

        class LegacySignatureClient(AISearchClient):
            def create_delta_sync_index(
                self,
                endpoint_name,
                index_name,
                primary_key,
                source_table_name,
                pipeline_type,
                embedding_dimension=None,
                embedding_vector_column=None,
                embedding_source_column=None,
                embedding_model_endpoint_name=None,
                sync_computed_embeddings=False,
                columns_to_sync=None,
                model_endpoint_name_for_query=None,
                budget_policy_id=None,
                usage_policy_id=None,
                index_subtype=None,
            ):
                return index

        client = LegacySignatureClient(
            workspace_url=workspace_url,
            personal_access_token="test-pat-token",
            disable_notice=True,
        )
        client.create_delta_sync_index_and_wait(
            endpoint_name="ep",
            index_name="cat.sch.idx",
            primary_key="id",
            source_table_name="cat.sch.source",
            pipeline_type="TRIGGERED",
        )

        index.wait_until_ready.assert_called_once()

    @pytest.mark.parametrize("payload_logging_enabled", [True, False])
    def test_create_delta_sync_index_and_wait_forwards_explicit_payload_logging(
        self, aisc_with_pat, payload_logging_enabled
    ):
        index = Mock()
        with patch.object(
            aisc_with_pat,
            "create_delta_sync_index",
            return_value=index,
        ) as create_index:
            aisc_with_pat.create_delta_sync_index_and_wait(
                endpoint_name="ep",
                index_name="cat.sch.idx",
                primary_key="id",
                source_table_name="cat.sch.source",
                pipeline_type="TRIGGERED",
                payload_logging_enabled=payload_logging_enabled,
            )

        assert create_index.call_args.kwargs == {
            "payload_logging_enabled": payload_logging_enabled,
        }
        index.wait_until_ready.assert_called_once()

    def test_create_delta_sync_index_requires_embedding_config(self, aisc_with_pat):
        with pytest.raises(InvalidInputException, match="embedding_source_column or embedding_vector_column"):
            aisc_with_pat.create_delta_sync_index(
                endpoint_name="ep",
                index_name="i",
                primary_key="id",
                source_table_name="src",
                pipeline_type="TRIGGERED",
            )

    def test_create_delta_sync_index_rejects_both_policy_ids(self, aisc_with_pat):
        with pytest.raises(InvalidInputException):
            aisc_with_pat.create_delta_sync_index(
                endpoint_name="ep",
                index_name="i",
                primary_key="id",
                source_table_name="src",
                pipeline_type="TRIGGERED",
                embedding_dimension=4,
                embedding_vector_column="v",
                budget_policy_id="b",
                usage_policy_id="u",
            )

    @patch("databricks.ai_search.client.RequestUtils.issue_request")
    def test_create_direct_access_index_returns_index(self, mock_req, aisc_with_pat):
        mock_req.return_value = {
            "name": "cat.sch.da",
            "status": {"index_url": "https://dp/da"},
        }
        idx = aisc_with_pat.create_direct_access_index(
            endpoint_name="ep",
            index_name="cat.sch.da",
            primary_key="id",
            embedding_dimension=8,
            embedding_vector_column="v",
            schema={"id": "integer", "v": "array<float>"},
            payload_logging_enabled=True,
        )
        assert isinstance(idx, AISearchIndex)
        body = mock_req.call_args.kwargs["json"]
        assert body["index_type"] == "DIRECT_ACCESS"
        spec = body["direct_access_index_spec"]
        assert spec["embedding_vector_columns"][0]["embedding_dimension"] == 8
        assert body["payload_logging_enabled"] is True

    def test_create_direct_access_index_requires_schema(self, aisc_with_pat):
        with pytest.raises(AssertionError):
            aisc_with_pat.create_direct_access_index(
                endpoint_name="ep",
                index_name="da",
                primary_key="id",
                embedding_dimension=4,
                embedding_vector_column="v",
                schema=None,
            )

    @patch("databricks.ai_search.client.RequestUtils.issue_request")
    def test_get_index_returns_index_instance(self, mock_req, aisc_with_pat):
        mock_req.return_value = {
            "status": {"index_url": "https://dp/idx"},
            "endpoint_name": "ep",
        }
        idx = aisc_with_pat.get_index(endpoint_name="ep", index_name="cat.sch.idx")
        assert isinstance(idx, AISearchIndex)
        assert idx.name == "cat.sch.idx"

    def test_get_index_requires_index_name(self, aisc_with_pat):
        with pytest.raises(AssertionError):
            aisc_with_pat.get_index(endpoint_name="ep", index_name=None)

    @patch("databricks.ai_search.client.RequestUtils.issue_request")
    def test_index_exists_false_on_not_found(self, mock_req, aisc_with_pat):
        mock_req.side_effect = NotFound("nope", status_code=404)
        assert aisc_with_pat.index_exists(index_name="cat.sch.idx") is False

    @patch("databricks.ai_search.client.RequestUtils.issue_request")
    def test_index_exists_true_on_success(self, mock_req, aisc_with_pat):
        mock_req.return_value = {"status": {"index_url": "https://x"}}
        assert aisc_with_pat.index_exists(index_name="cat.sch.idx") is True

    @patch("databricks.ai_search.client.RequestUtils.issue_request")
    def test_list_indexes_url(self, mock_req, aisc_with_pat, workspace_url):
        mock_req.return_value = {"indexes": []}
        aisc_with_pat.list_indexes("ep")
        assert mock_req.call_args.kwargs["url"] == (f"{workspace_url}/api/2.0/vector-search/endpoints/ep/indexes")

    @patch("databricks.ai_search.client.RequestUtils.issue_request")
    def test_list_indexes_normalizes_camelcase_keys(self, mock_req, aisc_with_pat):
        # Direct-DP (Rust) returns camelCase; callers must get stable snake_case.
        mock_req.return_value = {"vectorIndexes": [{"primaryKey": "id", "indexType": "DELTA_SYNC"}]}
        result = aisc_with_pat.list_indexes("ep")
        assert result == {"vector_indexes": [{"primary_key": "id", "index_type": "DELTA_SYNC"}]}

    @patch("databricks.ai_search.client.RequestUtils.issue_request")
    def test_delete_index_url_with_endpoint(self, mock_req, aisc_with_pat, workspace_url):
        mock_req.return_value = {}
        aisc_with_pat.delete_index(endpoint_name="ep", index_name="i")
        call = mock_req.call_args.kwargs
        assert call["method"] == "DELETE"
        assert call["url"] == (f"{workspace_url}/api/2.0/vector-search/endpoints/ep/indexes/i")

    @patch("databricks.ai_search.client.RequestUtils.issue_request")
    def test_delete_index_url_without_endpoint(self, mock_req, aisc_with_pat, workspace_url):
        mock_req.return_value = {}
        aisc_with_pat.delete_index(index_name="i")
        assert mock_req.call_args.kwargs["url"] == (f"{workspace_url}/api/2.0/vector-search/indexes/i")

    @patch("databricks.ai_search.client.RequestUtils.issue_request")
    def test_update_index_budget_policy_payload(self, mock_req, aisc_with_pat, workspace_url):
        mock_req.return_value = {}
        aisc_with_pat.update_index_budget_policy("i", usage_policy_id="up")
        call = mock_req.call_args.kwargs
        assert call["method"] == "PATCH"
        assert call["url"] == (f"{workspace_url}/api/2.0/vector-search/indexes/i/usage-policy")
        assert call["json"] == {"usage_policy_id": "up"}

    def test_update_index_budget_policy_rejects_both(self, aisc_with_pat):
        with pytest.raises(InvalidInputException):
            aisc_with_pat.update_index_budget_policy("i", budget_policy_id="b", usage_policy_id="u")

    @pytest.mark.parametrize("payload_logging_enabled", [True, False])
    @patch("databricks.ai_search.client.RequestUtils.issue_request")
    def test_update_index_payload_logging(self, mock_req, aisc_with_pat, workspace_url, payload_logging_enabled):
        mock_req.return_value = {}
        aisc_with_pat.update_index_payload_logging("cat.sch.idx", payload_logging_enabled)
        call = mock_req.call_args.kwargs
        assert call["method"] == "PATCH"
        assert call["url"] == f"{workspace_url}/api/2.0/vector-search/indexes/cat.sch.idx"
        assert call["json"] == {
            "name": "cat.sch.idx",
            "payload_logging_enabled": payload_logging_enabled,
        }
        assert call["params"] == {"update_mask": "payload_logging_enabled"}

    @pytest.mark.parametrize("payload_logging_enabled", [None, "true"])
    def test_payload_logging_rejects_non_boolean(self, aisc_with_pat, payload_logging_enabled):
        with pytest.raises(InvalidInputException, match="must be a boolean"):
            aisc_with_pat.update_index_payload_logging("i", payload_logging_enabled)


class TestPrivateHelpers:
    def test_get_index_url_with_endpoint(self, aisc_with_pat, workspace_url):
        assert aisc_with_pat._get_index_url("ep", "i") == (
            f"{workspace_url}/api/2.0/vector-search/endpoints/ep/indexes/i"
        )

    def test_get_index_url_without_endpoint(self, aisc_with_pat, workspace_url):
        assert aisc_with_pat._get_index_url(None, "i") == (f"{workspace_url}/api/2.0/vector-search/indexes/i")

    def test_mlserving_endpoint_name_from_resp(self, aisc_with_pat):
        resp = {"delta_sync_index_spec": {"embedding_source_columns": [{"embedding_model_endpoint_name": "my-ep"}]}}
        assert aisc_with_pat._get_mlserving_endpoint_name_from_resp(resp) == "my-ep"

    def test_mlserving_endpoint_name_for_query_from_resp(self, aisc_with_pat):
        resp = {"delta_sync_index_spec": {"embedding_source_columns": [{"model_endpoint_name_for_query": "query-ep"}]}}
        assert aisc_with_pat._get_mlserving_endpoint_name_for_query_from_resp(resp) == "query-ep"
