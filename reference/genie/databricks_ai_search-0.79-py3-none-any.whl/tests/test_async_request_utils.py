# ruff: noqa: E402  -- sys.modules stubs must precede SDK imports
import json
import sys
import unittest
from unittest.mock import AsyncMock, MagicMock, patch

# Mock modules that are unavailable in the test environment before importing
sys.modules["deprecation"] = MagicMock()
sys.modules["databricks.sdk"] = MagicMock()
sys.modules["databricks.sdk.credentials_provider"] = MagicMock()

_mock_databricks_utils = MagicMock()
_mock_databricks_utils.is_in_databricks_model_serving_environment.return_value = False
_mock_mlflow_utils = MagicMock()
_mock_mlflow_utils.databricks_utils = _mock_databricks_utils
sys.modules["mlflow"] = MagicMock()
sys.modules["mlflow.utils"] = _mock_mlflow_utils
sys.modules["mlflow.utils.databricks_utils"] = _mock_databricks_utils

import httpx

from databricks.ai_search import async_utils
from databricks.ai_search.async_utils import AsyncRequestUtils
from databricks.ai_search.exceptions import (
    BadRequest,
    NotFound,
    PermissionDenied,
    ResourceConflict,
    TooManyRequests,
    AISearchException,
)


def _mock_response(status_code, body=None, headers=None):
    """Build a minimal httpx.Response-shaped mock."""
    resp = MagicMock(spec=httpx.Response)
    resp.status_code = status_code
    resp.is_success = 200 <= status_code < 300
    resp.headers = headers or {}
    if body is None:
        body = {}
    resp.json.return_value = body
    resp.text = str(body)
    resp.content = str(body).encode()
    return resp


class TestAsyncRequestUtils(unittest.IsolatedAsyncioTestCase):
    """Cover the hand-rolled retry/exception logic in AsyncRequestUtils."""

    async def asyncSetUp(self):
        # Each test gets a fresh per-loop client cache so we can patch
        # AsyncClient.request without worrying about a stale cached instance.
        await async_utils.aclose_all_clients()

    @patch("httpx.AsyncClient.request", new_callable=AsyncMock)
    async def test_200_returns_parsed_json(self, mock_request):
        mock_request.return_value = _mock_response(200, {"ok": True})
        result = await AsyncRequestUtils.issue_request(url="https://example.com/x", method="GET", token="t")
        self.assertEqual(result, {"ok": True})
        self.assertEqual(mock_request.call_count, 1)

    @patch("httpx.AsyncClient.request", new_callable=AsyncMock)
    async def test_404_raises_NotFound(self, mock_request):
        mock_request.return_value = _mock_response(404, {"message": "no such index"})
        with self.assertRaises(NotFound) as ctx:
            await AsyncRequestUtils.issue_request(url="https://example.com/x", method="GET", token="t")
        self.assertEqual(ctx.exception.status_code, 404)

    @patch("httpx.AsyncClient.request", new_callable=AsyncMock)
    async def test_400_raises_BadRequest(self, mock_request):
        mock_request.return_value = _mock_response(400, {"message": "bad"})
        with self.assertRaises(BadRequest):
            await AsyncRequestUtils.issue_request(url="https://example.com/x", method="GET", token="t")

    @patch("httpx.AsyncClient.request", new_callable=AsyncMock)
    async def test_403_raises_PermissionDenied(self, mock_request):
        mock_request.return_value = _mock_response(403, {"message": "denied"})
        with self.assertRaises(PermissionDenied):
            await AsyncRequestUtils.issue_request(url="https://example.com/x", method="GET", token="t")

    @patch("httpx.AsyncClient.request", new_callable=AsyncMock)
    async def test_409_raises_ResourceConflict(self, mock_request):
        mock_request.return_value = _mock_response(409, {"message": "conflict"})
        with self.assertRaises(ResourceConflict):
            await AsyncRequestUtils.issue_request(url="https://example.com/x", method="GET", token="t")

    @patch("httpx.AsyncClient.request", new_callable=AsyncMock)
    async def test_500_raises_AISearchException(self, mock_request):
        mock_request.return_value = _mock_response(500, {"message": "boom"})
        with self.assertRaises(AISearchException):
            await AsyncRequestUtils.issue_request(
                url="https://example.com/x",
                method="GET",
                token="t",
                total_retries=0,
            )

    @patch("httpx.AsyncClient.request", new_callable=AsyncMock)
    async def test_error_code_and_details_surfaced_in_message(self, mock_request):
        # Async path must surface error_code/details too, not just message.
        mock_request.return_value = _mock_response(
            400,
            {
                "error_code": "INVALID_PARAMETER_VALUE",
                "message": "generic message",
                "details": [{"reason": "bad name"}],
            },
        )
        with self.assertRaises(BadRequest) as ctx:
            await AsyncRequestUtils.issue_request(url="https://example.com/x", method="GET", token="t")
        text = str(ctx.exception)
        self.assertIn("INVALID_PARAMETER_VALUE", text)
        self.assertIn("generic message", text)
        self.assertIn("bad name", text)
        # Structured attributes let callers read the fields without parsing the message.
        self.assertEqual(ctx.exception.error_code, "INVALID_PARAMETER_VALUE")
        self.assertEqual(ctx.exception.details, [{"reason": "bad name"}])

    @patch("asyncio.sleep", new_callable=AsyncMock)
    @patch("httpx.AsyncClient.request", new_callable=AsyncMock)
    async def test_retries_on_503_then_succeeds(self, mock_request, mock_sleep):
        mock_request.side_effect = [
            _mock_response(503),
            _mock_response(503),
            _mock_response(200, {"ok": True}),
        ]
        result = await AsyncRequestUtils.issue_request(url="https://example.com/x", method="GET", token="t")
        self.assertEqual(result, {"ok": True})
        self.assertEqual(mock_request.call_count, 3)

    @patch("asyncio.sleep", new_callable=AsyncMock)
    @patch("httpx.AsyncClient.request", new_callable=AsyncMock)
    async def test_retries_exhaust_on_429_raises_TooManyRequests(self, mock_request, mock_sleep):
        mock_request.side_effect = [_mock_response(429) for _ in range(4)]
        with self.assertRaises(TooManyRequests):
            await AsyncRequestUtils.issue_request(
                url="https://example.com/x",
                method="GET",
                token="t",
                total_retries=3,
            )
        self.assertEqual(mock_request.call_count, 4)

    @patch("httpx.AsyncClient.request", new_callable=AsyncMock)
    async def test_no_retry_on_400(self, mock_request):
        mock_request.return_value = _mock_response(400, {"message": "bad"})
        with self.assertRaises(BadRequest):
            await AsyncRequestUtils.issue_request(url="https://example.com/x", method="GET", token="t")
        # 400 is non-retryable, so exactly one call.
        self.assertEqual(mock_request.call_count, 1)

    @patch("asyncio.sleep", new_callable=AsyncMock)
    @patch("httpx.AsyncClient.request", new_callable=AsyncMock)
    async def test_retry_after_header_honored(self, mock_request, mock_sleep):
        # Integer value.
        mock_request.side_effect = [
            _mock_response(503, headers={"Retry-After": "2"}),
            _mock_response(200, {"ok": True}),
        ]
        result = await AsyncRequestUtils.issue_request(url="https://example.com/x", method="GET", token="t")
        self.assertEqual(result, {"ok": True})
        mock_sleep.assert_awaited_with(2.0)

    @patch("asyncio.sleep", new_callable=AsyncMock)
    @patch("httpx.AsyncClient.request", new_callable=AsyncMock)
    async def test_retry_after_decimal_honored(self, mock_request, mock_sleep):
        # Decimal value must not be truncated to an integer (e.g. "1.5" → 1.5,
        # not 1.0 as the old float(int(value)) path produced).
        mock_request.side_effect = [
            _mock_response(503, headers={"Retry-After": "1.5"}),
            _mock_response(200, {"ok": True}),
        ]
        result = await AsyncRequestUtils.issue_request(url="https://example.com/x", method="GET", token="t")
        self.assertEqual(result, {"ok": True})
        mock_sleep.assert_awaited_with(1.5)

    @patch("asyncio.sleep", new_callable=AsyncMock)
    @patch("httpx.AsyncClient.request", new_callable=AsyncMock)
    async def test_retries_on_write_timeout(self, mock_request, mock_sleep):
        # Ensures the full httpx.TimeoutException hierarchy is retried, not just
        # ConnectError / ReadTimeout.
        mock_request.side_effect = [
            httpx.WriteTimeout("write timed out"),
            _mock_response(200, {"ok": True}),
        ]
        result = await AsyncRequestUtils.issue_request(url="https://example.com/x", method="GET", token="t")
        self.assertEqual(result, {"ok": True})
        self.assertEqual(mock_request.call_count, 2)

    @patch("asyncio.sleep", new_callable=AsyncMock)
    @patch("httpx.AsyncClient.request", new_callable=AsyncMock)
    async def test_retries_on_remote_protocol_error(self, mock_request, mock_sleep):
        mock_request.side_effect = [
            httpx.RemoteProtocolError("server reset"),
            _mock_response(200, {"ok": True}),
        ]
        result = await AsyncRequestUtils.issue_request(url="https://example.com/x", method="GET", token="t")
        self.assertEqual(result, {"ok": True})
        self.assertEqual(mock_request.call_count, 2)

    @patch("httpx.AsyncClient.request", new_callable=AsyncMock)
    async def test_non_json_error_body_falls_back_to_text(self, mock_request):
        # Regression: the `json` parameter on issue_request shadows the stdlib
        # name inside this function, so `except json.JSONDecodeError:` would
        # raise AttributeError on the parameter (None / dict). The fix catches
        # ValueError (the parent class). httpx.Response.json() raises the real
        # json.JSONDecodeError on a non-JSON body, so use that exact type here
        # to prove the catch handles the subclass via inheritance.
        resp = MagicMock(spec=httpx.Response)
        resp.status_code = 502
        resp.is_success = False
        resp.headers = {}
        resp.json.side_effect = json.JSONDecodeError("Expecting value", "<html>...", 0)
        resp.text = "upstream returned an HTML 502 page"
        resp.content = resp.text.encode()
        mock_request.return_value = resp
        with self.assertRaises(AISearchException) as ctx:
            await AsyncRequestUtils.issue_request(
                url="https://example.com/x",
                method="GET",
                token="t",
                total_retries=0,
            )
        self.assertIn("upstream returned an HTML 502 page", str(ctx.exception))

    async def test_client_is_cached_across_calls(self):
        # Regression for the WeakValueDictionary-based cache that GC'd the
        # AsyncClient between requests, defeating connection pooling.
        c1 = await async_utils._get_client_for_loop()
        c2 = await async_utils._get_client_for_loop()
        self.assertIs(c1, c2)


if __name__ == "__main__":
    unittest.main()
