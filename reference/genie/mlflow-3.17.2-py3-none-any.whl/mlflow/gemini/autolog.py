import functools
import inspect
import logging
from typing import Any

import mlflow
import mlflow.gemini
from mlflow.entities import SpanType
from mlflow.entities.span import LiveSpan
from mlflow.gemini.chat import (
    convert_gemini_func_to_mlflow_chat_tool,
)
from mlflow.tracing.constant import SpanAttributeKey, TokenUsageKey
from mlflow.tracing.distributed import _get_tracing_headers_from_span
from mlflow.tracing.provider import detach_span_from_context, set_span_in_context
from mlflow.tracing.utils import (
    construct_full_inputs,
    set_span_chat_tools,
    set_span_model_attribute,
)
from mlflow.utils.autologging_utils.config import AutoLoggingConfig

_logger = logging.getLogger(__name__)


# The Google SDKs are imported lazily. Importing them at module load would fire the
# `mlflow.autolog()` post-import hook for `google.genai` while `mlflow.gemini` is still
# partially initialized, causing a circular import.
@functools.cache
def _get_generativeai():
    try:
        # This is for supporting the previous Google GenAI SDK
        # https://github.com/google-gemini/generative-ai-python
        from google import generativeai

        return generativeai
    except ImportError:
        return None


@functools.cache
def _get_genai():
    try:
        from google import genai

        return genai
    except ImportError:
        return None


def patched_class_call(original, self, *args, **kwargs):
    """
    This method is used for patching class methods of gemini SDKs.
    This patch creates a span and set input and output of the original method to the span.
    """
    with TracingSession(original, self, args, kwargs) as manager:
        if manager.span and _is_genai_model_or_chat(self) and _should_inject_headers(original):
            _inject_tracing_headers_genai(kwargs, manager.span)
        output = original(self, *args, **kwargs)
        manager.output = output
        return output


async def async_patched_class_call(original, self, *args, **kwargs):
    """
    This method is used for patching async class methods of gemini SDKs.
    This patch creates a span and set input and output of the original method to the span.
    """
    async with TracingSession(original, self, args, kwargs) as manager:
        if manager.span and _is_genai_model_or_chat(self) and _should_inject_headers(original):
            _inject_tracing_headers_genai(kwargs, manager.span)
        output = await original(self, *args, **kwargs)
        manager.output = output
        return output


class TracingSession:
    """Context manager for handling MLflow spans in both sync and async contexts."""

    def __init__(self, original, instance, args, kwargs):
        self.original = original
        self.instance = instance
        self.inputs = construct_full_inputs(original, instance, *args, **kwargs)

        # These attributes are set outside the constructor.
        self.span = None
        self.token = None
        self.output = None

    def __enter__(self):
        return self._enter_impl()

    def __exit__(self, exc_type, exc_val, exc_tb):
        self._exit_impl(exc_type, exc_val, exc_tb)

    async def __aenter__(self):
        return self._enter_impl()

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        self._exit_impl(exc_type, exc_val, exc_tb)

    def _enter_impl(self):
        config = AutoLoggingConfig.init(flavor_name=mlflow.gemini.FLAVOR_NAME)
        if not config.log_traces:
            return self

        self.span = mlflow.start_span_no_context(
            name=f"{self.instance.__class__.__name__}.{self.original.__name__}",
            span_type=_get_span_type(self.original.__name__),
            inputs=self.inputs,
            attributes={SpanAttributeKey.MESSAGE_FORMAT: "gemini"},
        )
        generativeai = _get_generativeai()
        if generativeai and isinstance(self.instance, generativeai.GenerativeModel):
            _log_generativeai_tool_definition(self.instance, self.span)

        if _is_genai_model_or_chat(self.instance):
            _log_genai_tool_definition(self.instance, self.inputs, self.span)

        # Attach the span to the current context. This is necessary because single Gemini
        # SDK call might create multiple child spans.
        self.token = set_span_in_context(self.span)
        return self

    def _exit_impl(self, exc_type, exc_val, exc_tb) -> None:
        if not self.span:
            return

        # Detach span from the context at first. This must not be interrupted by any exception,
        # otherwise the span context will leak and pollute other traces created next.
        detach_span_from_context(self.token)

        if exc_val:
            self.span.record_exception(exc_val)

        try:
            # Chat instances store model in _model attribute
            if model := (self.inputs.get("model") or getattr(self.instance, "_model", None)):
                self.span.set_attribute(SpanAttributeKey.MODEL, model)
                self.span.set_attribute(SpanAttributeKey.MODEL_PROVIDER, "gemini")
        except Exception as e:
            _logger.debug(f"Failed to extract model for span {self.span.name}: {e}", exc_info=True)

        try:
            if usage := _parse_usage(self.output):
                self.span.set_attribute(SpanAttributeKey.CHAT_USAGE, usage)
        except Exception as e:
            _logger.warning(
                f"Failed to extract token usage for span {self.span.name}: {e}", exc_info=True
            )

        # need to convert the response of generate_content for better visualization
        outputs = self.output.to_dict() if hasattr(self.output, "to_dict") else self.output
        self.span.end(outputs=outputs)


def _is_genai_model_or_chat(instance) -> bool:
    genai = _get_genai()
    return genai is not None and isinstance(
        instance,
        (
            genai.models.Models,
            genai.chats.Chat,
            genai.models.AsyncModels,
            genai.chats.AsyncChat,
        ),
    )


def patched_module_call(original, *args, **kwargs):
    """
    This method is used for patching standalone functions of the google.generativeai module.
    This patch creates a span and set input and output of the original function to the span.
    """
    config = AutoLoggingConfig.init(flavor_name=mlflow.gemini.FLAVOR_NAME)
    if not config.log_traces:
        return original(*args, **kwargs)

    with mlflow.start_span(
        name=f"{original.__name__}",
        span_type=_get_span_type(original.__name__),
    ) as span:
        inputs = _construct_full_inputs(original, *args, **kwargs)
        span.set_inputs(inputs)
        span.set_attribute(SpanAttributeKey.MESSAGE_FORMAT, "gemini")
        result = original(*args, **kwargs)
        set_span_model_attribute(span, inputs)
        try:
            if usage := _parse_usage(result):
                span.set_attribute(SpanAttributeKey.CHAT_USAGE, usage)
        except Exception as e:
            _logger.warning(
                f"Failed to extract token usage for span {span.name}: {e}", exc_info=True
            )
        # need to convert the response of generate_content for better visualization
        outputs = result.to_dict() if hasattr(result, "to_dict") else result
        span.set_outputs(outputs)

    return result


def _get_keys(dic, keys):
    for key in keys:
        if key in dic:
            return dic[key]

    return None


def _log_generativeai_tool_definition(model, span):
    """
    This method extract tool definition from generativeai tool type.
    """
    # when tools are not passed
    if not getattr(model, "_tools", None):
        return

    try:
        set_span_chat_tools(
            span,
            [
                convert_gemini_func_to_mlflow_chat_tool(func)
                for func in model._tools.to_proto()[0].function_declarations
            ],
        )
    except Exception as e:
        _logger.warning(f"Failed to set tool definitions for {span}. Error: {e}")


def _log_genai_tool_definition(model, inputs, span):
    """
    This method extract tool definition from genai tool type.
    """
    config = inputs.get("config")
    tools = getattr(config, "tools", None)
    if not tools:
        return
    # Here, we use an internal function of gemini library to convert callable to Tool schema to
    # avoid having the same logic on mlflow side and there is no public attribute for Tool schema.
    # https://github.com/googleapis/python-genai/blob/01b15e32d3823a58d25534bb6eea93f30bf82219/google/genai/_transformers.py#L662
    tools = _get_genai()._transformers.t_tools(model._api_client, tools)

    try:
        set_span_chat_tools(
            span,
            [
                convert_gemini_func_to_mlflow_chat_tool(function_declaration)
                for tool in tools
                for function_declaration in tool.function_declarations
            ],
        )
    except Exception as e:
        _logger.warning(f"Failed to set tool definitions for {span}. Error: {e}")


_HEADER_INJECTION_METHODS = {"_generate_content", "send_message", "count_tokens", "embed_content"}


def _should_inject_headers(original) -> bool:
    return getattr(original, "__name__", "") in _HEADER_INJECTION_METHODS


def _inject_tracing_headers_genai(kwargs: dict[str, Any], span: LiveSpan):
    genai = _get_genai()
    if genai is None:
        return
    try:
        tracing_headers = _get_tracing_headers_from_span(span)
        if not tracing_headers:
            return

        if "config" not in kwargs:
            return

        config = kwargs["config"]
        if config is None:
            kwargs["config"] = {"http_options": {"headers": tracing_headers}}
            return
        elif isinstance(config, dict):
            http_options = config.get("http_options") or {}
            if isinstance(http_options, dict):
                existing_headers = http_options.get("headers") or {}
                http_options["headers"] = tracing_headers | existing_headers
                config["http_options"] = http_options
            else:
                existing_headers = getattr(http_options, "headers", None) or {}
                http_options.headers = tracing_headers | existing_headers
        else:
            http_options = getattr(config, "http_options", None)
            if http_options is None:
                config.http_options = genai.types.HttpOptions(headers=tracing_headers)
            else:
                existing_headers = getattr(http_options, "headers", None) or {}
                http_options.headers = tracing_headers | existing_headers
    except Exception:
        _logger.debug("Failed to inject tracing headers for Gemini", exc_info=True)


def _get_span_type(task_name: str) -> str:
    span_type_mapping = {
        "generate_content": SpanType.LLM,
        "_generate_content": SpanType.LLM,
        "send_message": SpanType.CHAT_MODEL,
        "count_tokens": SpanType.LLM,
        "embed_content": SpanType.EMBEDDING,
    }
    return span_type_mapping.get(task_name, SpanType.UNKNOWN)


def _construct_full_inputs(func, *args, **kwargs):
    signature = inspect.signature(func)
    # this method does not create copy. So values should not be mutated directly
    arguments = signature.bind_partial(*args, **kwargs).arguments

    if "self" in arguments:
        arguments.pop("self")

    return arguments


def _parse_usage(output):
    usage = None
    if hasattr(output, "usage_metadata"):
        usage = output.usage_metadata
    elif isinstance(output, dict):
        usage = output.get("usage_metadata")
    else:
        return None

    usage_dict = {}
    if (prompt_tokens := usage.prompt_token_count) is not None:
        usage_dict[TokenUsageKey.INPUT_TOKENS] = prompt_tokens
    if (candidate_tokens := usage.candidates_token_count) is not None:
        usage_dict[TokenUsageKey.OUTPUT_TOKENS] = candidate_tokens
    if (total_tokens := usage.total_token_count) is not None:
        usage_dict[TokenUsageKey.TOTAL_TOKENS] = total_tokens
    if (cached_tokens := getattr(usage, "cached_content_token_count", None)) is not None:
        usage_dict[TokenUsageKey.CACHE_READ_INPUT_TOKENS] = cached_tokens

    return usage_dict or None
