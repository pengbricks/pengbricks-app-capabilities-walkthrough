import json
import os
import warnings
from typing import TYPE_CHECKING, Any, AsyncIterable
from urllib.parse import urlparse, urlunparse

from mlflow.environment_variables import MLFLOW_ENABLE_UC_FUNCTIONS
from mlflow.exceptions import MlflowException
from mlflow.gateway.config import EndpointConfig, OpenAIAPIType, OpenAIConfig
from mlflow.gateway.exceptions import AIGatewayException
from mlflow.gateway.providers.base import (
    BaseProvider,
    PassthroughAction,
    _client_provides_auth,
    _drop_client_auth_headers,
)
from mlflow.gateway.providers.openai_compatible import OpenAICompatibleAdapter
from mlflow.gateway.providers.utils import (
    proxy_root_url,
    send_proxy_request,
    send_request,
    send_stream_request,
)
from mlflow.gateway.schemas import chat, completions, embeddings
from mlflow.gateway.uc_function_utils import (
    _UC_FUNCTION,
    TokenUsageAccumulator,
    execute_function,
    get_func_schema,
    join_uc_functions,
    parse_uc_functions,
    prepend_uc_functions,
)
from mlflow.gateway.utils import parse_sse_lines, stream_sse_data
from mlflow.utils.uri import append_to_uri_path, append_to_uri_query_params

if TYPE_CHECKING:
    from databricks.sdk import FunctionInfo


# To mock the WorkspaceClient in tests
def _get_workspace_client():
    try:
        from databricks.sdk import WorkspaceClient

        return WorkspaceClient()
    except ImportError:
        raise AIGatewayException(
            message="Databricks SDK is required to use Unity Catalog integration",
            error_code=404,
        )


class OpenAIAdapter(OpenAICompatibleAdapter):
    """OpenAI-specific adapter that extends OpenAICompatibleAdapter.

    Overrides payload methods to handle Azure OpenAI, where the model name
    is part of the URL (deployment name) rather than the request body.
    Also includes legacy completions response transformation methods.
    """

    @classmethod
    def _add_model_to_payload_if_necessary(cls, payload, config):
        # NB: For Azure OpenAI, the deployment name (which is included in the URL) specifies
        # the model; it is not specified in the payload. For OpenAI outside of Azure, the
        # model is always specified in the payload
        if config.model.config.openai_api_type not in (OpenAIAPIType.AZURE, OpenAIAPIType.AZUREAD):
            return {"model": config.model.name, **payload}
        else:
            return payload

    @classmethod
    def chat_to_model(cls, payload, config):
        return cls._add_model_to_payload_if_necessary(payload, config)

    @classmethod
    def completion_to_model(cls, payload, config):
        return cls._add_model_to_payload_if_necessary(payload, config)

    @classmethod
    def completions_to_model(cls, payload, config):
        return cls._add_model_to_payload_if_necessary(payload, config)

    @classmethod
    def embeddings_to_model(cls, payload, config):
        return cls._add_model_to_payload_if_necessary(payload, config)

    @classmethod
    def model_to_completions(cls, resp, config):
        # Response example (https://platform.openai.com/docs/api-reference/completions/create)
        # ```
        # {
        #   "id": "cmpl-uqkvlQyYK7bGYrRHQ0eXlWi7",
        #   "object": "text_completion",
        #   "created": 1589478378,
        #   "model": "text-davinci-003",
        #   "choices": [
        #     {
        #       "text": "\n\nThis is indeed a test",
        #       "index": 0,
        #       "logprobs": null,
        #       "finish_reason": "length"
        #     }
        #   ],
        #   "usage": {
        #     "prompt_tokens": 5,
        #     "completion_tokens": 7,
        #     "total_tokens": 12
        #   }
        # }
        # ```
        return completions.ResponsePayload(
            id=resp["id"],
            object="text_completion",
            created=resp["created"],
            model=resp["model"],
            choices=[
                completions.Choice(
                    index=idx,
                    text=c.get("message", {}).get("content") or c.get("text") or "",
                    finish_reason=c["finish_reason"],
                )
                for idx, c in enumerate(resp["choices"])
            ],
            usage=completions.CompletionsUsage(
                prompt_tokens=resp["usage"]["prompt_tokens"],
                completion_tokens=resp["usage"]["completion_tokens"],
                total_tokens=resp["usage"]["total_tokens"],
            ),
        )

    @classmethod
    def model_to_completions_streaming(cls, resp, config):
        usage = None
        if usage_data := resp.get("usage"):
            usage = completions.CompletionsUsage(
                prompt_tokens=usage_data.get("prompt_tokens"),
                completion_tokens=usage_data.get("completion_tokens"),
                total_tokens=usage_data.get("total_tokens"),
            )

        return completions.StreamResponsePayload(
            id=resp["id"],
            object="text_completion_chunk",
            created=resp["created"],
            model=resp["model"],
            choices=[
                completions.StreamChoice(
                    index=c["index"],
                    finish_reason=c["finish_reason"],
                    text=c["delta"].get("content"),
                )
                for c in resp["choices"]
            ],
            usage=usage,
        )


class OpenAIProvider(BaseProvider):
    DISPLAY_NAME = "OpenAI"
    CONFIG_TYPE = OpenAIConfig

    PASSTHROUGH_PROVIDER_PATHS = {
        PassthroughAction.OPENAI_CHAT: "chat/completions",
        PassthroughAction.OPENAI_EMBEDDINGS: "embeddings",
        PassthroughAction.OPENAI_RESPONSES: "responses",
        PassthroughAction.OPENAI_RESPONSES_COMPACT: "responses/compact",
    }

    def __init__(self, config: EndpointConfig, enable_tracing: bool = False) -> None:
        super().__init__(config, enable_tracing=enable_tracing)
        if config.model.config is None or not isinstance(config.model.config, OpenAIConfig):
            # Should be unreachable
            raise MlflowException.invalid_parameter_value(
                "Invalid config type {config.model.config}"
            )
        self.openai_config: OpenAIConfig = config.model.config

    @property
    def base_url(self):
        api_type = self.openai_config.openai_api_type
        if api_type == OpenAIAPIType.OPENAI:
            base_url = self.openai_config.openai_api_base or "https://api.openai.com/v1"
            if (api_version := self.openai_config.openai_api_version) is not None:
                return append_to_uri_query_params(base_url, ("api-version", api_version))
            else:
                return base_url
        elif api_type in (OpenAIAPIType.AZURE, OpenAIAPIType.AZUREAD):
            openai_url = append_to_uri_path(
                self.openai_config.openai_api_base,
                "openai",
                "deployments",
                self.openai_config.openai_deployment_name,
            )
            return append_to_uri_query_params(
                openai_url,
                ("api-version", self.openai_config.openai_api_version),
            )
        else:
            raise MlflowException.invalid_parameter_value(
                f"Invalid OpenAI API type '{self.openai_config.openai_api_type}'"
            )

    @property
    def headers(self):
        api_type = self.openai_config.openai_api_type
        if api_type == OpenAIAPIType.OPENAI:
            headers = {
                "authorization": f"Bearer {self.openai_config.openai_api_key}",
            }
            if org := self.openai_config.openai_organization:
                headers["OpenAI-Organization"] = org
            return headers
        elif api_type == OpenAIAPIType.AZUREAD:
            return {
                "authorization": f"Bearer {self.openai_config.openai_api_key}",
            }
        elif api_type == OpenAIAPIType.AZURE:
            return {
                "api-key": self.openai_config.openai_api_key,
            }
        else:
            raise MlflowException.invalid_parameter_value(
                f"Invalid OpenAI API type '{self.openai_config.openai_api_type}'"
            )

    def _get_headers(
        self,
        payload: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, str]:
        """
        Generate headers for OpenAI API requests.

        Args:
            payload: Request payload (reserved for future conditional headers)
            headers: Optional headers from client request to propagate

        Returns:
            Merged headers with provider headers taking precedence
        """
        result_headers = self.headers.copy()

        if headers:
            client_headers = headers.copy()
            client_headers.pop("host", None)
            client_headers.pop("content-length", None)
            if _client_provides_auth(headers):
                # Preserve the client's own credentials for subscription-based tools
                # (e.g. Claude Code, Codex, Gemini CLI) instead of using the server key.
                result_headers.pop("authorization", None)
                result_headers.pop("api-key", None)
            else:
                # Never forward client auth headers to the upstream provider.
                client_headers = _drop_client_auth_headers(client_headers)
            result_headers = client_headers | result_headers

        return result_headers

    @property
    def adapter_class(self):
        return OpenAIAdapter

    def get_endpoint_url(self, route_type: str) -> str:
        if route_type == "llm/v1/chat":
            route_path = "chat/completions"
        elif route_type == "llm/v1/completions":
            route_path = "completions"
        elif route_type == "llm/v1/embeddings":
            route_path = "embeddings"
        else:
            raise ValueError(f"Invalid route type {route_type}")

        # Append the route path to the base URL. Note that we cannot simply append the route path
        # at the end of the base URL because it has query parameters for the Azure OpenAI case.
        parsed_base_url = urlparse(self.base_url)
        return urlunparse(parsed_base_url._replace(path=f"{parsed_base_url.path}/{route_path}"))

    async def _chat_stream(
        self, payload: chat.RequestPayload
    ) -> AsyncIterable[chat.StreamResponsePayload]:
        from fastapi.encoders import jsonable_encoder

        payload = jsonable_encoder(payload, exclude_none=True)
        self.check_for_model_field(payload)

        # Inject stream_options.include_usage=true to get usage in final chunk
        if payload.get("stream_options") is None:
            payload["stream_options"] = {"include_usage": True}
        elif "include_usage" not in payload["stream_options"]:
            payload["stream_options"]["include_usage"] = True

        stream = send_stream_request(
            headers=self.headers,
            base_url=self.base_url,
            path="chat/completions",
            payload=self.adapter_class.chat_to_model(payload, self.config),
        )

        async for resp in stream_sse_data(stream):
            yield OpenAIAdapter.model_to_chat_streaming(resp, self.config)

    async def _send_chat_request(self, payload: chat.RequestPayload) -> chat.ResponsePayload:
        from fastapi.encoders import jsonable_encoder

        payload = jsonable_encoder(payload, exclude_none=True)
        self.check_for_model_field(payload)

        return await send_request(
            headers=self.headers,
            base_url=self.base_url,
            path="chat/completions",
            payload=self.adapter_class.chat_to_model(payload, self.config),
        )

    async def _chat_uc_function(self, payload: chat.RequestPayload) -> chat.ResponsePayload:
        workspace_client = _get_workspace_client()
        warehouse_id = os.environ.get("DATABRICKS_WAREHOUSE_ID")
        if warehouse_id is None:
            raise AIGatewayException(
                status_code=400,
                detail="DATABRICKS_WAREHOUSE_ID environment variable is not set",
            )

        from fastapi.encoders import jsonable_encoder

        payload = jsonable_encoder(payload, exclude_none=True)
        self.check_for_model_field(payload)

        token_usage_accumulator = TokenUsageAccumulator()
        user_tool_messages = [m for m in payload["messages"] if m["role"] == "tool"]
        user_tool_calls = next(
            (m["tool_calls"] for m in payload["messages"] if "tool_calls" in m), None
        )
        if (
            user_tool_messages
            and user_tool_calls
            and (result := parse_uc_functions(payload["messages"][0]["content"]))
        ):
            uc_func_calls, uc_func_messages = result
            messages = [
                *[m for m in payload["messages"] if m["role"] == "tool" or "tool_calls" in m],
                # Join UC function calls and user tool calls
                {
                    "role": "assistant",
                    "content": None,
                    "tool_calls": uc_func_calls + user_tool_calls,
                },
                *uc_func_messages,
                *user_tool_messages,
            ]
            resp = await send_request(
                headers=self.headers,
                base_url=self.base_url,
                path="chat/completions",
                payload=self.adapter_class.chat_to_model(
                    {
                        **payload,
                        "messages": messages,
                    },
                    self.config,
                ),
            )
            token_usage_accumulator.update(resp.get("usage", {}))
        elif any(t["type"] == _UC_FUNCTION for t in payload.get("tools", [])):
            updated_tools = []
            uc_func_mapping: dict[str, "FunctionInfo"] = {}
            for tool in payload.get("tools", []):
                if tool["type"] == _UC_FUNCTION:
                    function_name = tool[_UC_FUNCTION]["name"]
                    function = workspace_client.functions.get(function_name)
                    param_metadata = get_func_schema(function)
                    t = {
                        "type": "function",
                        "function": param_metadata,
                    }
                    uc_func_mapping[t["function"]["name"]] = function
                    updated_tools.append(t)
                else:
                    updated_tools.append(tool)

            payload["tools"] = updated_tools

            messages = payload.pop("messages", [])
            uc_func_calls = []
            user_tool_calls = []
            resp = None
            for _ in range(20):  # loop until we get a response without tool_calls
                resp = await send_request(
                    headers=self.headers,
                    base_url=self.base_url,
                    path="chat/completions",
                    payload=self.adapter_class.chat_to_model(
                        {
                            **payload,
                            "messages": messages,
                        },
                        self.config,
                    ),
                )
                token_usage_accumulator.update(resp.get("usage", {}))
                # TODO to support n > 1.
                assistant_msg = resp["choices"][0]["message"]
                tool_calls = assistant_msg.get("tool_calls")
                if tool_calls is None:
                    if uc_func_calls:
                        original_content = resp["choices"][0]["message"]["content"]
                        resp["choices"][0]["message"]["content"] = prepend_uc_functions(
                            original_content, uc_func_calls
                        )

                    if user_tool_calls:
                        # Is this line unreachable?
                        resp["choices"][0]["message"]["tool_calls"] = user_tool_calls

                    break

                tool_messages = []
                for tool_call in tool_calls:
                    func = tool_call["function"]
                    parameters = json.loads(func["arguments"])
                    if func_info := uc_func_mapping.get(func["name"]):
                        result = execute_function(
                            ws=workspace_client,
                            warehouse_id=warehouse_id,
                            function=function,
                            parameters=parameters,
                        )
                        tool_messages.append({
                            "role": "tool",
                            "tool_call_id": tool_call["id"],
                            "content": result.to_json(),
                        })

                        uc_func_calls.append((
                            {
                                "id": tool_call["id"],
                                "name": func_info.full_name,
                                "arguments": func["arguments"],
                            },
                            {
                                "tool_call_id": tool_call["id"],
                                "content": result.to_json(),
                            },
                        ))
                    else:
                        user_tool_calls.append({
                            "id": tool_call["id"],
                            "type": "function",
                            "function": {
                                "name": func["name"],
                                "arguments": func["arguments"],
                            },
                        })

                if message_content := assistant_msg.pop("content", None):
                    messages.append({"role": "assistant", "content": message_content})
                messages += [assistant_msg, *tool_messages]

                if user_tool_calls:
                    # We can't go on without a response from the user, so we break here
                    if uc_func_calls:
                        resp["choices"][0]["message"]["content"] = join_uc_functions(uc_func_calls)

                    resp["choices"][0]["message"]["tool_calls"] = user_tool_calls
                    break
            else:
                raise AIGatewayException(
                    status_code=500,
                    detail="Max iterations reached",
                )
        else:
            # No UC functions to execute
            resp = await send_request(
                headers=self.headers,
                base_url=self.base_url,
                path="chat/completions",
                payload=self.adapter_class.chat_to_model(payload, self.config),
            )
            token_usage_accumulator.update(resp.get("usage", {}))

        # Update the token usage
        resp["usage"].update(token_usage_accumulator.dict())

        return resp

    async def _chat(self, payload: chat.RequestPayload) -> chat.ResponsePayload:
        if MLFLOW_ENABLE_UC_FUNCTIONS.get():
            warnings.warn(
                "Unity Catalog function integration via the MLflow AI Gateway is deprecated "
                "and will be removed in a future release. "
                "For an alternative, see: https://docs.databricks.com/aws/en/generative-ai/mcp/managed-mcp",
                FutureWarning,
                stacklevel=2,
            )
            resp = await self._chat_uc_function(payload)
        else:
            resp = await self._send_chat_request(payload)

        return OpenAIAdapter.model_to_chat(resp, self.config)

    async def _completions_stream(
        self, payload: completions.RequestPayload
    ) -> AsyncIterable[completions.StreamResponsePayload]:
        from fastapi.encoders import jsonable_encoder

        payload = jsonable_encoder(payload, exclude_none=True)
        self.check_for_model_field(payload)

        # Inject stream_options.include_usage=true to get usage in final chunk
        if payload.get("stream_options") is None:
            payload["stream_options"] = {"include_usage": True}
        elif "include_usage" not in payload["stream_options"]:
            payload["stream_options"]["include_usage"] = True

        stream = send_stream_request(
            headers=self.headers,
            base_url=self.base_url,
            path="completions",
            payload=OpenAIAdapter.completion_to_model(payload, self.config),
        )

        async for resp in stream_sse_data(stream):
            yield OpenAIAdapter.model_to_completions_streaming(resp, self.config)

    async def _completions(
        self, payload: completions.RequestPayload
    ) -> completions.ResponsePayload:
        from fastapi.encoders import jsonable_encoder

        payload = jsonable_encoder(payload, exclude_none=True)
        self.check_for_model_field(payload)
        resp = await send_request(
            headers=self.headers,
            base_url=self.base_url,
            path="completions",
            payload=OpenAIAdapter.completion_to_model(payload, self.config),
        )
        return OpenAIAdapter.model_to_completions(resp, self.config)

    async def _embeddings(self, payload: embeddings.RequestPayload) -> embeddings.ResponsePayload:
        from fastapi.encoders import jsonable_encoder

        payload = jsonable_encoder(payload, exclude_none=True)
        self.check_for_model_field(payload)
        resp = await send_request(
            headers=self.headers,
            base_url=self.base_url,
            path="embeddings",
            payload=OpenAIAdapter.embeddings_to_model(payload, self.config),
        )
        return OpenAIAdapter.model_to_embeddings(resp, self.config)

    def _extract_passthrough_token_usage(
        self, action: PassthroughAction, result: dict[str, Any]
    ) -> dict[str, int] | None:
        """
        Extract token usage from OpenAI passthrough response.

        Chat Completions: usage.prompt_tokens/completion_tokens, prompt_tokens_details.cached_tokens
        Responses API: usage.input_tokens/output_tokens, input_tokens_details.cached_tokens
        """
        usage = result.get("usage")
        if not usage:
            return None

        if action in (
            PassthroughAction.OPENAI_RESPONSES,
            PassthroughAction.OPENAI_RESPONSES_COMPACT,
        ):
            return self._extract_token_usage_from_dict(
                usage,
                "input_tokens",
                "output_tokens",
                "total_tokens",
                cache_read_key="input_tokens_details.cached_tokens",
            )
        else:
            return self._extract_token_usage_from_dict(
                usage,
                "prompt_tokens",
                "completion_tokens",
                "total_tokens",
                cache_read_key="prompt_tokens_details.cached_tokens",
            )

    def _extract_streaming_token_usage(self, chunk: bytes) -> dict[str, int]:
        """
        Extract token usage from OpenAI streaming chunks.

        Handles two formats:
        - Chat Completions API: data.usage with prompt_tokens/completion_tokens
        - Responses API: data.response.usage with input_tokens/output_tokens

        Returns:
            A dictionary with token usage found in this chunk.
        """
        for data in parse_sse_lines(chunk):
            # Responses API: usage nested under data.response
            resp_usage = data.get("response", {}).get("usage")
            # Chat Completions API: usage at top level
            chat_usage = data.get("usage")

            if resp_usage:
                token_usage = self._extract_token_usage_from_dict(
                    resp_usage,
                    "input_tokens",
                    "output_tokens",
                    "total_tokens",
                    cache_read_key="input_tokens_details.cached_tokens",
                )
            elif chat_usage:
                token_usage = self._extract_token_usage_from_dict(
                    chat_usage,
                    "prompt_tokens",
                    "completion_tokens",
                    "total_tokens",
                    cache_read_key="prompt_tokens_details.cached_tokens",
                )
            else:
                continue

            if token_usage:
                return token_usage
        return {}

    async def _proxy(
        self,
        path: str,
        payload: dict[str, Any],
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any] | AsyncIterable[Any]:
        gen = send_proxy_request(
            self._get_headers(None, headers), proxy_root_url(self.base_url), path, payload
        )
        meta = await gen.__anext__()
        if meta["is_streaming"]:
            return gen
        body = await gen.__anext__()
        await gen.aclose()
        return body

    async def _passthrough(
        self,
        action: PassthroughAction,
        payload: dict[str, Any],
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any] | AsyncIterable[Any]:
        payload_with_model = self.adapter_class._add_model_to_payload_if_necessary(
            payload, self.config
        )

        provider_path = self._validate_passthrough_action(action)

        request_headers = self._get_headers(payload_with_model, headers)

        supports_streaming = action != PassthroughAction.OPENAI_EMBEDDINGS

        if supports_streaming and payload_with_model.get("stream"):
            if self._enable_tracing and action == PassthroughAction.OPENAI_CHAT:
                if payload_with_model.get("stream_options") is None:
                    payload_with_model["stream_options"] = {"include_usage": True}
                elif "include_usage" not in payload_with_model["stream_options"]:
                    payload_with_model["stream_options"]["include_usage"] = True

            stream = send_stream_request(
                headers=request_headers,
                base_url=self.base_url,
                path=provider_path,
                payload=payload_with_model,
            )
            return self._stream_passthrough_with_usage(stream)
        else:
            return await send_request(
                headers=request_headers,
                base_url=self.base_url,
                path=provider_path,
                payload=payload_with_model,
            )
