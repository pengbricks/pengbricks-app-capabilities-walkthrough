import hashlib
import json
import time
from typing import Any, AsyncIterable

from mlflow.gateway.config import EndpointConfig, GeminiConfig
from mlflow.gateway.exceptions import AIGatewayException
from mlflow.gateway.providers.base import (
    BaseProvider,
    PassthroughAction,
    ProviderAdapter,
    _client_provides_auth,
    _drop_client_auth_headers,
)
from mlflow.gateway.providers.utils import (
    parse_base64_data_url,
    rename_payload_keys,
    send_proxy_request,
    send_request,
    send_stream_request,
)
from mlflow.gateway.schemas import (
    chat as chat_schema,
)
from mlflow.gateway.schemas import (
    completions as completions_schema,
)
from mlflow.gateway.schemas import (
    embeddings as embeddings_schema,
)
from mlflow.gateway.utils import handle_incomplete_chunks, strip_sse_prefix
from mlflow.types.chat import Function, ToolCall

GENERATION_CONFIG_KEY_MAPPING = {
    "stop": "stopSequences",
    "n": "candidateCount",
    "max_tokens": "maxOutputTokens",
    "top_k": "topK",
    "top_p": "topP",
    "frequency_penalty": "frequencyPenalty",
    "presence_penalty": "presencePenalty",
}

GENERATION_CONFIGS = [
    "temperature",
    "stopSequences",
    "candidateCount",
    "maxOutputTokens",
    "topK",
    "topP",
    "frequencyPenalty",
    "presencePenalty",
]


def _to_gemini_parts(content: Any) -> list[dict[str, Any]]:
    """Translate a user message's content into Gemini ``parts``.

    A string becomes a single text part (unchanged behavior). A multimodal list has each
    part translated: text -> ``{"text": ...}``, ``image_url`` base64 data URL ->
    ``{"inlineData": {"mimeType": ..., "data": ...}}``. Non-base64 image URLs fall back to
    a text note since the judge image tool only ever emits base64 data URLs. Any other part
    type is passed through unchanged rather than coerced to empty text, so a non-text part
    (e.g. ``input_audio``) isn't silently dropped.
    """
    if not isinstance(content, list):
        return [{"text": content}]

    parts: list[dict[str, Any]] = []
    for part in content:
        if part.get("type") == "text":
            parts.append({"text": part.get("text", "")})
        elif part.get("type") == "image_url":
            url = part.get("image_url", {}).get("url", "")
            if parsed := parse_base64_data_url(url):
                mime, data = parsed
                parts.append({"inlineData": {"mimeType": mime, "data": data}})
            else:
                parts.append({"text": f"[unsupported image reference: {url}]"})
        else:
            parts.append(part)
    return parts


def _tool_result_to_response(content: Any) -> dict[str, Any]:
    """Coerce OpenAI tool message content into a Gemini ``functionResponse.response``.

    OpenAI tool content is free-form and usually plain text, but Gemini requires an object,
    so a JSON object passes through and anything else is wrapped as ``{"result": ...}``.
    """
    try:
        parsed = json.loads(content)
    except (json.JSONDecodeError, TypeError):
        return {"result": content}
    return parsed if isinstance(parsed, dict) else {"result": parsed}


class GeminiAdapter(ProviderAdapter):
    @classmethod
    def _normalize_finish_reason(cls, finish_reason):
        """Normalize Gemini finish reasons to OpenAI format (lowercase)."""
        if not finish_reason:
            return finish_reason
        if finish_reason == "MAX_TOKENS":
            return "length"
        return finish_reason.lower()

    @classmethod
    def chat_to_model(cls, payload, config):
        # Documentation: https://ai.google.dev/api/generate-content
        # Example payload for the chat API.
        #
        # {
        #     "contents": [
        #         {
        #             "role": "user",
        #             "parts": [
        #                 {
        #                     "text": "System: You are an advanced AI Assistant"
        #                 }
        #             ]
        #         },
        #         {
        #             "role": "user",
        #             "parts": [
        #                 {
        #                     "text": "Please give the code for addition of two numbers"
        #                 }
        #             ]
        #         }
        #     ],
        #     "generationConfig": {
        #         "temperature": 0.1,
        #         "topP": 1,
        #         "stopSequences": ["\n"],
        #         "candidateCount": 1,
        #         "maxOutputTokens": 100,
        #         "topK": 40
        #     }
        # }

        for k1, k2 in GENERATION_CONFIG_KEY_MAPPING.items():
            if k2 in payload:
                raise AIGatewayException(
                    status_code=422, detail=f"Invalid parameter {k2}. Use {k1} instead."
                )

        if "max_completion_tokens" in payload:
            if "max_tokens" not in payload:
                payload["max_tokens"] = payload.pop("max_completion_tokens")

        payload = rename_payload_keys(payload, GENERATION_CONFIG_KEY_MAPPING)

        contents = []
        system_message = None

        call_id_to_function_name_map = {}
        call_id_to_thought_signature_map = {}

        for message in payload["messages"]:
            role = message["role"]

            if role in ("user", "assistant"):
                if role == "assistant":
                    role = "model"

                gemini_function_calls = []
                if role == "model":
                    if tool_calls := message.get("tool_calls"):
                        for tool_call in tool_calls:
                            call_id_to_function_name_map[tool_call["id"]] = tool_call["function"][
                                "name"
                            ]
                            if sig := tool_call.get("thought_signature"):
                                call_id_to_thought_signature_map[tool_call["id"]] = sig

                            fc = {
                                "id": tool_call["id"],
                                "name": tool_call["function"]["name"],
                                "args": json.loads(tool_call["function"]["arguments"]),
                            }
                            part = {"functionCall": fc}
                            if tool_call["id"] in call_id_to_thought_signature_map:
                                part["thoughtSignature"] = call_id_to_thought_signature_map[
                                    tool_call["id"]
                                ]

                            gemini_function_calls.append(part)
                if gemini_function_calls:
                    contents.append({"role": "model", "parts": gemini_function_calls})
                else:
                    # _to_gemini_parts translates multimodal list content (e.g. an image_url
                    # part) to Gemini parts; string content stays a single text part.
                    contents.append({"role": role, "parts": _to_gemini_parts(message["content"])})
            elif role == "system":
                if system_message is None:
                    system_message = {"parts": []}
                system_message["parts"].append({"text": message["content"]})
            elif role == "tool":
                call_id = message.get("tool_call_id")
                if call_id not in call_id_to_function_name_map:
                    raise AIGatewayException(
                        status_code=422,
                        detail=(
                            f"Invalid tool message: tool_call_id={call_id} does not match "
                            "any tool call in a preceding assistant message."
                        ),
                    )
                function_response = {
                    "functionResponse": {
                        "id": call_id,
                        # the function name field is required by Gemini request format
                        "name": call_id_to_function_name_map[call_id],
                        "response": _tool_result_to_response(message["content"]),
                    }
                }
                # OpenAI sends one tool message per parallel call, but Gemini requires the
                # responses to all of a model turn's calls in a single user turn.
                previous = contents[-1] if contents else None
                if (
                    previous is not None
                    and previous["role"] == "user"
                    and previous["parts"]
                    and all("functionResponse" in part for part in previous["parts"])
                ):
                    previous["parts"].append(function_response)
                else:
                    contents.append({"role": "user", "parts": [function_response]})

        gemini_payload = {"contents": contents}

        if system_message:
            gemini_payload["system_instruction"] = system_message

        if generation_config := {k: v for k, v in payload.items() if k in GENERATION_CONFIGS}:
            gemini_payload["generationConfig"] = generation_config

        # Transform response_format for Gemini structured outputs
        if response_format := payload.pop("response_format", None):
            response_format_type = response_format.get("type")
            if response_format_type == "json_schema" and "json_schema" in response_format:
                generation_config = gemini_payload.setdefault("generationConfig", {})
                generation_config["responseJsonSchema"] = response_format["json_schema"]["schema"]
                generation_config["responseMimeType"] = "application/json"
            elif response_format_type == "json_object":
                # Gemini constrains output to valid JSON when responseMimeType is set,
                # even without an explicit schema.
                generation_config = gemini_payload.setdefault("generationConfig", {})
                generation_config["responseMimeType"] = "application/json"

        # convert tool definition to Gemini format
        if tools := payload.pop("tools", None):
            function_declarations = []
            for tool in tools:
                if tool["type"] != "function":
                    raise AIGatewayException(
                        status_code=422,
                        detail=(
                            "Only function calling tool is supported, but received tool type "
                            f"{tool['type']}"
                        ),
                    )

                tool_function = tool["function"]
                function_declarations.append({
                    "name": tool_function["name"],
                    "description": tool_function["description"],
                    "parametersJsonSchema": tool_function["parameters"],
                })

            gemini_payload["tools"] = [{"functionDeclarations": function_declarations}]

            match payload.pop("tool_choice", None):
                case "none":
                    gemini_payload["toolConfig"] = {"functionCallingConfig": {"mode": "NONE"}}
                case "required":
                    gemini_payload["toolConfig"] = {"functionCallingConfig": {"mode": "ANY"}}
                case {"type": "function", "function": {"name": name}}:
                    gemini_payload["toolConfig"] = {
                        "functionCallingConfig": {"mode": "ANY", "allowedFunctionNames": [name]}
                    }

        return gemini_payload

    @classmethod
    def _convert_function_call_to_openai_choice(
        cls,
        content_parts: list[dict[str, Any]],
        finish_reason: str,
        choice_idx: int,
        stream: bool,
        tool_call_offset: int = 0,
    ):
        # convert gemini model responded "function call" struct to Openai choice / choice chunk
        # struct.
        # Gemini doc: https://ai.google.dev/api/caching#FunctionCall

        # A candidate can mix text and functionCall parts in any order, e.g. a short
        # "Let me look that up." followed by the call. Keep both.
        tool_calls = []
        text_parts = []
        for part in content_parts:
            if "text" in part:
                text_parts.append(part["text"])
            function_call = part.get("functionCall")
            if not function_call:
                continue
            func_name = function_call["name"]
            func_arguments = json.dumps(function_call["args"])
            call_id = function_call.get("id")
            # Gemini 3.x places thoughtSignature at the Part level, next to functionCall.
            # Some older responses nested it inside functionCall instead, so fall back to
            # that location too.
            thought_sig = (
                part.get("thoughtSignature")
                or part.get("thought_signature")
                or function_call.get("thoughtSignature")
                or function_call.get("thought_signature")
            )
            if call_id is None:
                # Gemini model response might not contain function call id,
                # in order to make it compatible with Openai chat protocol,
                # we need to generate a unique call id.
                call_id = (
                    "call_"
                    + hashlib.md5(
                        f"{func_name}/{func_arguments}".encode(),
                        usedforsecurity=False,
                    ).hexdigest()
                )
            if stream:
                tool_calls.append(
                    chat_schema.ToolCallDelta(
                        index=tool_call_offset + len(tool_calls),
                        id=call_id,
                        function=Function(
                            name=func_name,
                            arguments=func_arguments,
                        ),
                        type="function",
                        thought_signature=thought_sig,
                    )
                )
            else:
                tool_calls.append(
                    ToolCall(
                        id=call_id,
                        function=Function(
                            name=func_name,
                            arguments=func_arguments,
                        ),
                        type="function",
                        thought_signature=thought_sig,
                    )
                )
        content = "".join(text_parts) or None
        # Gemini reports STOP for a turn that ends in a function call.
        if tool_calls and finish_reason == "stop":
            finish_reason = "tool_calls"
        if stream:
            return chat_schema.StreamChoice(
                index=choice_idx,
                delta=chat_schema.StreamDelta(
                    role="assistant",
                    content=content,
                    tool_calls=tool_calls,
                ),
                finish_reason=finish_reason,
            )
        return chat_schema.Choice(
            index=choice_idx,
            message=chat_schema.ResponseMessage(
                role="assistant",
                content=content,
                tool_calls=tool_calls,
            ),
            finish_reason=finish_reason,
        )

    @classmethod
    def _build_chat_usage(cls, usage_metadata: dict[str, Any]) -> chat_schema.ChatUsage:
        extra = {
            key: value
            for key, value in usage_metadata.items()
            if key
            not in {
                "promptTokenCount",
                "candidatesTokenCount",
                "totalTokenCount",
                "cachedContentTokenCount",
            }
        }
        prompt_tokens_details = None
        if "cachedContentTokenCount" in usage_metadata:
            prompt_tokens_details = chat_schema.PromptTokensDetails(
                cached_tokens=usage_metadata["cachedContentTokenCount"]
            )
        return chat_schema.ChatUsage(
            **extra,
            prompt_tokens=usage_metadata.get("promptTokenCount"),
            completion_tokens=usage_metadata.get("candidatesTokenCount"),
            total_tokens=usage_metadata.get("totalTokenCount"),
            prompt_tokens_details=prompt_tokens_details,
        )

    @classmethod
    def model_to_chat(cls, resp, config):
        # Documentation: https://ai.google.dev/api/generate-content
        #
        # Example Response:
        # {
        #   "candidates": [
        #     {
        #       "content": {
        #         "parts": [
        #           {
        #             "text": "Blue is often seen as a calming and soothing color."
        #           }
        #         ]
        #       },
        #       "finishReason": "stop"
        #     }
        #   ],
        #   "usageMetadata": {
        #     "promptTokenCount": 10,
        #     "candidatesTokenCount": 10,
        #     "totalTokenCount": 20
        #   }
        # }
        choices = []
        for idx, candidate in enumerate(resp.get("candidates", [])):
            finish_reason = cls._normalize_finish_reason(candidate.get("finishReason", "stop"))

            if parts := candidate.get("content", {}).get("parts", None):
                if any(part.get("functionCall") for part in parts):
                    choices.append(
                        GeminiAdapter._convert_function_call_to_openai_choice(
                            parts, finish_reason, idx, False
                        )
                    )

                elif content := parts[0].get("text"):
                    choices.append(
                        chat_schema.Choice(
                            index=idx,
                            message=chat_schema.ResponseMessage(
                                role="assistant",
                                content=content,
                            ),
                            finish_reason=finish_reason,
                        )
                    )

        usage_metadata = resp.get("usageMetadata", {})

        return chat_schema.ResponsePayload(
            id=f"gemini-chat-{int(time.time())}",
            created=int(time.time()),
            object="chat.completion",
            model=config.model.name,
            choices=choices,
            usage=cls._build_chat_usage(usage_metadata),
        )

    @classmethod
    def model_to_chat_streaming(
        cls, resp: dict[str, Any], config, tool_call_offsets: dict[int, int] | None = None
    ) -> chat_schema.StreamResponsePayload:
        # Documentation: https://ai.google.dev/api/generate-content#method:-models.streamgeneratecontent
        #
        # Example Streaming Chunk:
        # {
        #   "candidates": [
        #     {
        #       "content": {
        #         "parts": [
        #           {
        #             "text": "Blue is often seen as a calming and soothing color."
        #           }
        #         ]
        #       },
        #       "finishReason": null
        #     }
        #   ],
        #   "id": "stream-id",
        #   "object": "chat.completion.chunk",
        #   "created": 1234567890,
        #   "model": "gemini-2.0-flash"
        # }
        choices = []
        for pos, cand in enumerate(resp.get("candidates", [])):
            # A chunk may carry only some candidates, so use the API index, not the position.
            idx = cand.get("index", pos)
            parts = cand.get("content", {}).get("parts", [])
            finish_reason = cls._normalize_finish_reason(cand.get("finishReason"))

            if parts:
                if any(part.get("functionCall") for part in parts):
                    # for gemini model streaming response,
                    # the function call message is not split into chunks
                    # it still contains the full function call arguments data.
                    choices.append(
                        GeminiAdapter._convert_function_call_to_openai_choice(
                            parts, finish_reason, idx, True, (tool_call_offsets or {}).get(idx, 0)
                        )
                    )
                    continue

            delta_text = parts[0].get("text", "") if parts else ""
            # Gemini ends a tool-call stream with a STOP chunk that carries no functionCall,
            # so the calls seen in earlier chunks decide the finish reason.
            if finish_reason == "stop" and (tool_call_offsets or {}).get(idx, 0):
                finish_reason = "tool_calls"
            choices.append(
                chat_schema.StreamChoice(
                    index=idx,
                    finish_reason=finish_reason,
                    delta=chat_schema.StreamDelta(
                        role="assistant",
                        content=delta_text,
                    ),
                )
            )
        current_time = int(time.time())

        # Extract usage from usageMetadata (available in final chunk)
        usage = None
        if usage_metadata := resp.get("usageMetadata"):
            usage = cls._build_chat_usage(usage_metadata)

        return chat_schema.StreamResponsePayload(
            id=f"gemini-chat-stream-{current_time}",
            object="chat.completion.chunk",
            created=current_time,
            model=config.model.name,
            choices=choices,
            usage=usage,
        )

    @classmethod
    def completions_to_model(cls, payload, config):
        # Documentation: https://ai.google.dev/api/generate-content
        # Example payload for the completions API.
        #
        # {
        #     "prompt": "What is the world record for flapjack consumption in a single sitting?",
        #     "temperature": 0.1,
        #     "topP": 1,
        #     "stop": ["\n"],
        #     "n": 1,
        #     "max_tokens": 100,
        #     "top_k": 40,
        # }

        chat_payload = {"messages": [{"role": "user", "content": payload.pop("prompt")}], **payload}
        if system_message := payload.pop("system_prompt", None):
            chat_payload["messages"].insert(0, {"role": "system", "content": system_message})
        return cls.chat_to_model(chat_payload, config)

    @classmethod
    def model_to_completions(cls, resp, config):
        # Documentation: https://ai.google.dev/api/generate-content
        #
        # Example Response:
        # {
        #   "candidates": [
        #     {
        #       "content": {
        #         "parts": [
        #           {
        #             "text": "Blue is often seen as a calming and soothing color."
        #           }
        #         ]
        #       },
        #       "finishReason": "stop"
        #     }
        #   ],
        #   "usageMetadata": {
        #     "promptTokenCount": 10,
        #     "candidatesTokenCount": 10,
        #     "totalTokenCount": 20
        #   }
        # }
        choices = []

        for idx, candidate in enumerate(resp.get("candidates", [])):
            text = ""
            if parts := candidate.get("content", {}).get("parts", None):
                text = parts[0].get("text", None)
            if not text:
                continue

            finish_reason = cls._normalize_finish_reason(candidate.get("finishReason", "stop"))

            choices.append(
                completions_schema.Choice(
                    index=idx,
                    text=text,
                    finish_reason=finish_reason,
                )
            )

        usage_metadata = resp.get("usageMetadata", {})

        return completions_schema.ResponsePayload(
            created=int(time.time()),
            object="text_completion",
            model=config.model.name,
            choices=choices,
            usage=completions_schema.CompletionsUsage(
                prompt_tokens=usage_metadata.get("promptTokenCount", None),
                completion_tokens=usage_metadata.get("candidatesTokenCount", None),
                total_tokens=usage_metadata.get("totalTokenCount", None),
            ),
        )

    @classmethod
    def model_to_completions_streaming(
        cls, resp: dict[str, Any], config
    ) -> completions_schema.StreamResponsePayload:
        # Documentation: https://ai.google.dev/api/generate-content#method:-models.streamgeneratecontent

        # Example SSE chunk for streaming completions:
        # {
        #   "candidates": [
        #     {
        #       "content": {
        #         "parts": [
        #           { "text": "Hello, world!" }
        #         ]
        #       },
        #       "finishReason": "stop"
        #     }
        #   ],
        #   "id": "gemini-completions-stream-1234567890",
        #   "object": "text_completion.chunk",
        #   "created": 1234567890,
        #   "model": "gemini-2.0-flash"
        # }
        choices = []
        for idx, cand in enumerate(resp.get("candidates", [])):
            parts = cand.get("content", {}).get("parts", [])
            delta_text = parts[0].get("text", "") if parts else ""
            choices.append(
                completions_schema.StreamChoice(
                    index=idx,
                    finish_reason=cls._normalize_finish_reason(cand.get("finishReason")),
                    text=delta_text,
                )
            )
        current_time = int(time.time())

        return completions_schema.StreamResponsePayload(
            id=f"gemini-completions-stream-{current_time}",
            object="text_completion.chunk",
            created=current_time,
            model=config.model.name,
            choices=choices,
        )

    @classmethod
    def embeddings_to_model(cls, payload, config):
        # Example payload for the embedding API.
        # Documentation: https://ai.google.dev/api/embeddings#v1beta.ContentEmbedding
        #
        # {
        #     "requests": [
        #         {
        #             "model": "models/text-embedding-004",
        #             "content": {
        #                 "parts": [
        #                     {
        #                         "text": "What is the meaning of life?"
        #                     }
        #                 ]
        #             }
        #         },
        #         {
        #             "model": "models/text-embedding-004",
        #             "content": {
        #                 "parts": [
        #                     {
        #                         "text": "How much wood would a woodchuck chuck?"
        #                     }
        #                 ]
        #             }
        #         },
        #         {
        #             "model": "models/text-embedding-004",
        #             "content": {
        #                 "parts": [
        #                     {
        #                         "text": "How does the brain work?"
        #                     }
        #                 ]
        #             }
        #         }
        #     ]
        # }

        texts = payload["input"]
        if isinstance(texts, str):
            texts = [texts]
        return (
            {"content": {"parts": [{"text": texts[0]}]}}
            if len(texts) == 1
            else {
                "requests": [
                    {"model": f"models/{config.model.name}", "content": {"parts": [{"text": text}]}}
                    for text in texts
                ]
            }
        )

    @classmethod
    def model_to_embeddings(cls, resp, config):
        # Documentation: https://ai.google.dev/api/embeddings#v1beta.ContentEmbedding
        #
        # Example Response:
        # {
        #   "embeddings": [
        #     {
        #       "values": [
        #         3.25,
        #         0.7685547,
        #         2.65625,
        #         ...,
        #         -0.30126953,
        #         -2.3554688,
        #         1.2597656
        #       ]
        #     }
        #   ]
        # }

        data = [
            embeddings_schema.EmbeddingObject(embedding=item.get("values", []), index=i)
            for i, item in enumerate(resp.get("embeddings") or [resp.get("embedding", {})])
        ]

        # Create and return response payload directly
        return embeddings_schema.ResponsePayload(
            data=data,
            model=config.model.name,
            usage=embeddings_schema.EmbeddingsUsage(
                prompt_tokens=None,
                total_tokens=None,
            ),
        )


class GeminiProvider(BaseProvider):
    DISPLAY_NAME = "Gemini"
    CONFIG_TYPE = GeminiConfig

    PASSTHROUGH_PROVIDER_PATHS = {
        PassthroughAction.GEMINI_GENERATE_CONTENT: "{model}:generateContent",
        PassthroughAction.GEMINI_STREAM_GENERATE_CONTENT: "{model}:streamGenerateContent?alt=sse",
    }

    def __init__(self, config: EndpointConfig, enable_tracing: bool = False) -> None:
        super().__init__(config, enable_tracing=enable_tracing)
        if config.model.config is None or not isinstance(config.model.config, GeminiConfig):
            raise TypeError(f"Unexpected config type {config.model.config}")
        self.gemini_config: GeminiConfig = config.model.config

    @property
    def headers(self):
        return {"x-goog-api-key": self.gemini_config.gemini_api_key}

    def _get_headers(
        self,
        payload: dict[str, Any] | None = None,
        headers: dict[str, str] | None = None,
    ) -> dict[str, str]:
        """
        Generate headers for Gemini API requests.

        Args:
            payload: Request payload (reserved for future conditional headers)
            headers: Optional headers from client request to propagate

        Returns:
            Merged headers with provider headers taking precedence
        """
        result_headers = self.headers.copy()

        if headers:
            client_headers = headers.copy()
            client_headers.pop("host", None)
            client_headers.pop("content-length", None)
            if _client_provides_auth(headers):
                # Preserve the client's own credentials for subscription-based tools
                # (e.g. Claude Code, Codex, Gemini CLI) instead of using the server key.
                result_headers.pop("x-goog-api-key", None)
            else:
                # Never forward client auth headers: they would be sent alongside the
                # provider credential (e.g. Vertex AI's OAuth bearer token) and shadow it.
                client_headers = _drop_client_auth_headers(client_headers)
            result_headers = client_headers | result_headers

        return result_headers

    @property
    def base_url(self):
        return "https://generativelanguage.googleapis.com/v1beta/models"

    @property
    def adapter_class(self):
        return GeminiAdapter

    def get_endpoint_url(self, route_type: str) -> str:
        model_name = self.config.model.name
        if route_type in ("llm/v1/chat", "llm/v1/completions"):
            return f"{self.base_url}/{model_name}:generateContent"
        elif route_type == "llm/v1/embeddings":
            return f"{self.base_url}/{model_name}:embedContent"
        raise ValueError(f"Invalid route type {route_type}")

    async def _request(self, path: str, payload: dict[str, Any]) -> dict[str, Any]:
        return await send_request(
            headers=self.headers,
            base_url=self.base_url,
            path=path,
            payload=payload,
        )

    async def _embeddings(
        self, payload: embeddings_schema.RequestPayload
    ) -> embeddings_schema.ResponsePayload:
        from fastapi.encoders import jsonable_encoder

        payload = jsonable_encoder(payload, exclude_none=True)
        self.check_for_model_field(payload)

        embedding_payload = self.adapter_class.embeddings_to_model(payload, self.config)
        # Documentation: https://ai.google.dev/api/embeddings

        # Use the batch endpoint if payload contains "requests"
        if "requests" in embedding_payload:
            endpoint_suffix = ":batchEmbedContents"
        else:
            endpoint_suffix = ":embedContent"

        resp = await self._request(
            f"{self.config.model.name}{endpoint_suffix}",
            embedding_payload,
        )
        return self.adapter_class.model_to_embeddings(resp, self.config)

    async def _completions(
        self, payload: completions_schema.RequestPayload
    ) -> completions_schema.ResponsePayload:
        from fastapi.encoders import jsonable_encoder

        payload = jsonable_encoder(payload, exclude_none=True)
        self.check_for_model_field(payload)

        completions_payload = self.adapter_class.completions_to_model(payload, self.config)
        # Documentation: https://ai.google.dev/api/generate-content

        resp = await self._request(
            f"{self.config.model.name}:generateContent",
            completions_payload,
        )

        return self.adapter_class.model_to_completions(resp, self.config)

    async def _completions_stream(
        self, payload: completions_schema.RequestPayload
    ) -> AsyncIterable[completions_schema.StreamResponsePayload]:
        from fastapi.encoders import jsonable_encoder

        body = jsonable_encoder(payload, exclude_none=True)
        self.check_for_model_field(body)

        model_payload = self.adapter_class.completions_to_model(body, self.config)
        path = f"{self.config.model.name}:streamGenerateContent?alt=sse"

        # Documentation: https://ai.google.dev/api/generate-content#method:-models.streamgeneratecontent
        sse = send_stream_request(
            headers=self.headers, base_url=self.base_url, path=path, payload=model_payload
        )

        async for raw in handle_incomplete_chunks(sse):
            text = raw.decode("utf-8", errors="ignore").strip()
            if not text.startswith("data:"):
                continue
            data = strip_sse_prefix(text)
            if data == "[DONE]":
                break
            resp = json.loads(data)
            yield self.adapter_class.model_to_completions_streaming(resp, self.config)

    async def _chat(self, payload: chat_schema.RequestPayload) -> chat_schema.ResponsePayload:
        from fastapi.encoders import jsonable_encoder

        payload = jsonable_encoder(payload, exclude_none=True)
        self.check_for_model_field(payload)

        chat_payload = self.adapter_class.chat_to_model(payload, self.config)
        # Documentation: https://ai.google.dev/api/generate-content

        resp = await self._request(
            f"{self.config.model.name}:generateContent",
            chat_payload,
        )

        return self.adapter_class.model_to_chat(resp, self.config)

    async def _chat_stream(
        self, payload: chat_schema.RequestPayload
    ) -> AsyncIterable[chat_schema.StreamResponsePayload]:
        from fastapi.encoders import jsonable_encoder

        body = jsonable_encoder(payload, exclude_none=True)
        self.check_for_model_field(body)

        body = self.adapter_class.chat_to_model(body, self.config)

        # Documentation: https://ai.google.dev/api/generate-content#method:-models.streamgeneratecontent
        sse = send_stream_request(
            headers=self.headers,
            base_url=self.base_url,
            path=f"{self.config.model.name}:streamGenerateContent?alt=sse",
            payload=body,
        )

        # Gemini sends each functionCall whole, but calls can arrive across chunks, so
        # number them per stream, separately for each candidate.
        tool_call_counts: dict[int, int] = {}
        async for raw in handle_incomplete_chunks(sse):
            text = raw.decode("utf-8", errors="ignore").strip()
            if not text.startswith("data:"):
                continue
            data = strip_sse_prefix(text)
            if data == "[DONE]":
                break
            resp = json.loads(data)
            yield self.adapter_class.model_to_chat_streaming(resp, self.config, tool_call_counts)
            for pos, cand in enumerate(resp.get("candidates", [])):
                idx = cand.get("index", pos)
                parts = cand.get("content", {}).get("parts", [])
                tool_call_counts[idx] = tool_call_counts.get(idx, 0) + sum(
                    1 for part in parts if part.get("functionCall")
                )

    def _extract_passthrough_token_usage(
        self, action: PassthroughAction, result: dict[str, Any]
    ) -> dict[str, int] | None:
        """
        Extract token usage from Gemini passthrough response.

        Gemini response format:
        {
            "usageMetadata": {
                "promptTokenCount": int,
                "candidatesTokenCount": int,
                "totalTokenCount": int
            }
        }
        """
        usage_metadata = result.get("usageMetadata")
        return self._extract_token_usage_from_dict(
            usage_metadata,
            "promptTokenCount",
            "candidatesTokenCount",
            "totalTokenCount",
            cache_read_key="cachedContentTokenCount",
        )

    def _extract_streaming_token_usage(self, chunk: bytes) -> dict[str, int]:
        """
        Extract token usage from Gemini streaming chunks.

        Gemini streaming format uses SSE with usageMetadata in chunks (typically final chunk):
        data: {"candidates": [...], "usageMetadata": {"promptTokenCount": X, ...}}

        Returns:
            A dictionary with token usage found in this chunk.
        """
        try:
            chunk_str = chunk.decode("utf-8").strip()
            if not chunk_str:
                return {}

            # Parse SSE format - look for data lines
            for line in chunk_str.split("\n"):
                line = line.strip()
                if not line.startswith("data:"):
                    continue

                data_str = line[5:].strip()
                if not data_str or data_str == "[DONE]":
                    continue

                data = json.loads(data_str)

                # Extract usageMetadata if present
                usage_metadata = data.get("usageMetadata")
                if token_usage := self._extract_token_usage_from_dict(
                    usage_metadata,
                    "promptTokenCount",
                    "candidatesTokenCount",
                    "totalTokenCount",
                    cache_read_key="cachedContentTokenCount",
                ):
                    return token_usage

        except (json.JSONDecodeError, UnicodeDecodeError):
            pass

        return {}

    async def _proxy(
        self,
        path: str,
        payload: dict[str, Any],
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any] | AsyncIterable[Any]:
        # base_url includes /v1beta/models; the caller's path already starts with
        # v1beta/models/..., so use the bare origin to avoid double-prefixing.
        api_origin = "https://generativelanguage.googleapis.com"
        gen = send_proxy_request(self._get_headers(None, headers), api_origin, path, payload)
        meta = await gen.__anext__()
        if meta["is_streaming"]:
            return gen
        body = await gen.__anext__()
        await gen.aclose()
        return body

    async def _passthrough(
        self,
        action: PassthroughAction,
        payload: dict[str, Any],
        headers: dict[str, str] | None = None,
    ) -> dict[str, Any] | AsyncIterable[Any]:
        provider_path = self._validate_passthrough_action(action)
        provider_path = provider_path.format(model=self.config.model.name)

        request_headers = self._get_headers(payload, headers)

        is_streaming = action == PassthroughAction.GEMINI_STREAM_GENERATE_CONTENT

        if is_streaming:
            stream = send_stream_request(
                headers=request_headers,
                base_url=self.base_url,
                path=provider_path,
                payload=payload,
            )
            return self._stream_passthrough_with_usage(stream)
        else:
            return await send_request(
                headers=request_headers,
                base_url=self.base_url,
                path=provider_path,
                payload=payload,
            )
