import re
import time
from contextlib import asynccontextmanager
from contextvars import ContextVar
from typing import Any, AsyncGenerator
from urllib.parse import urlparse, urlunparse

from mlflow.environment_variables import MLFLOW_GATEWAY_ROUTE_TIMEOUT_SECONDS
from mlflow.gateway.constants import MLFLOW_GATEWAY_AUTH_HEADER
from mlflow.utils.uri import append_to_uri_path

# data:<mime>;base64,<payload> — the only image_url form the judge image tool emits.
_DATA_URL_RE = re.compile(r"^data:(?P<mime>[^;]+);base64,(?P<data>.*)$", re.DOTALL)


def parse_base64_data_url(url: str) -> tuple[str, str] | None:
    """Parse a ``data:<mime>;base64,<payload>`` URL into ``(mime, base64_payload)``.

    Returns None for any non-base64-data-url (e.g. a remote http URL), so callers can
    decide how to handle non-base64 references.
    """
    if match := _DATA_URL_RE.match(url):
        return match.group("mime"), match.group("data")
    return None


_STRIPPED_HEADERS = frozenset({
    "accept-encoding",
    "content-encoding",
    MLFLOW_GATEWAY_AUTH_HEADER.lower(),
})

# Accumulates the total time (ms) spent waiting for provider HTTP responses in the current
# request context. Reset to 0.0 at the start of each request by the gateway timing middleware
# (add_gateway_timing_middleware in fastapi_app.py).
provider_call_duration_ms: ContextVar[float] = ContextVar("provider_call_duration_ms", default=0.0)

# Request gzip/deflate only so upstream never sends Brotli; aiohttp fails to decode
# Content-Encoding: br without the optional brotli package.
SUPPORTED_ACCEPT_ENCODING = "gzip, deflate, identity"


@asynccontextmanager
async def _aiohttp_post(
    headers: dict[str, str],
    base_url: str,
    path: str,
    payload: dict[str, Any],
    *,
    ssrf_protect: bool = True,
):
    import aiohttp
    from fastapi import HTTPException

    from mlflow.gateway.ssrf import (
        GatewaySSRFProtectionError,
        assert_public_upstream_url,
        build_ssrf_guarded_connector,
    )

    # Drop any client Accept-Encoding (any casing) so we send only one value; otherwise
    # aiohttp may send both and upstream can respond with Brotli, which is not supported.
    # Also drop Content-Encoding, which describes the body the client sent, not the JSON
    # re-serialized below (e.g. a zstd-encoded request body is decompressed before it gets
    # here). And drop X-MLflow-Authorization (MLflow's own RBAC credential on gateway routes)
    # so it is never forwarded to the upstream provider. This is the single egress choke
    # point all proxy/passthrough paths funnel through, so SSRF protection lives here too:
    # the upstream host may come from a user-supplied secret `api_base`, so the connection
    # target is checked at connect time (see mlflow.gateway.ssrf) and redirects are never
    # followed, as a redirect could otherwise steer the request to an internal address.
    request_headers = {k: v for k, v in headers.items() if k.lower() not in _STRIPPED_HEADERS}
    request_headers["Accept-Encoding"] = SUPPORTED_ACCEPT_ENCODING
    url = append_to_uri_path(base_url, path)
    connector = None
    if ssrf_protect:
        try:
            assert_public_upstream_url(url)
        except GatewaySSRFProtectionError as e:
            raise HTTPException(status_code=502, detail=str(e)) from e
        connector = build_ssrf_guarded_connector()
    try:
        # Raise the aiohttp stream read buffer to tolerate large SSE `data:` lines
        # emitted by some providers during streaming responses.
        async with aiohttp.ClientSession(
            connector=connector, headers=request_headers, read_bufsize=2**20
        ) as session:
            timeout = aiohttp.ClientTimeout(total=MLFLOW_GATEWAY_ROUTE_TIMEOUT_SECONDS.get())
            # ClientSession.__aenter__ opens no connection; the resolver runs while
            # session.post(...).__aenter__ acquires one, which this try encloses.
            try:
                async with session.post(
                    url, json=payload, timeout=timeout, allow_redirects=False
                ) as response:
                    yield response
            except GatewaySSRFProtectionError as e:
                raise HTTPException(status_code=502, detail=str(e)) from e
    finally:
        # The session owns and closes the connector on exit; this only matters when the
        # session was replaced by a test double that does not.
        if connector is not None and not connector.closed:
            await connector.close()


def _error_detail(error_body: Any) -> str:
    """Return the most specific message an upstream error body carries.

    Providers disagree on the shape: OpenAI-compatible APIs nest the message under
    ``error``, Amazon Bedrock returns a top-level ``message``, and others use neither,
    so fall back to the whole body rather than dropping it.
    """
    match error_body:
        case {"error": {"message": str(message)}} if message:
            return message
        case {"message": str(message)} if message:
            return message
    # aiohttp's json() returns None for an empty body, so report nothing and let the
    # caller fall back rather than stringifying it.
    return str(error_body) if error_body else ""


async def send_request(
    headers: dict[str, str],
    base_url: str,
    path: str,
    payload: dict[str, Any],
    *,
    ssrf_protect: bool = True,
):
    """
    Send an HTTP request to a specific URL path with given headers and payload.

    Args:
        headers: The headers to include in the request.
        base_url: The base URL where the request will be sent.
        path: The specific path of the URL to which the request will be sent.
        payload: The payload (or data) to be included in the request.
        ssrf_protect: Whether to apply the gateway's upstream SSRF protection (see
            ``mlflow.gateway.ssrf``). Pass ``False`` only for calls whose target is not
            user-controlled, such as the server calling itself.

    Returns:
        The server's response as a JSON object.

    Raises:
        HTTPException if the HTTP request fails.
    """
    import aiohttp
    from fastapi import HTTPException

    start = time.perf_counter()
    try:
        async with _aiohttp_post(
            headers, base_url, path, payload, ssrf_protect=ssrf_protect
        ) as response:
            content_type = response.headers.get("Content-Type")
            if content_type and "application/json" in content_type:
                js = await response.json()
            elif content_type and "text/plain" in content_type:
                js = {"message": await response.text()}
            else:
                raise HTTPException(
                    status_code=502,
                    detail=f"The returned data type from the route service is not supported. "
                    f"Received content type: {content_type}",
                )
            try:
                response.raise_for_status()
            except aiohttp.ClientResponseError as e:
                detail = js.get("error", {}).get("message", e.message) if "error" in js else js
                raise HTTPException(status_code=e.status, detail=detail)
    finally:
        # Record full provider HTTP time for non-streaming, even when raising.
        provider_call_duration_ms.set(
            provider_call_duration_ms.get() + (time.perf_counter() - start) * 1000
        )
    return js


async def send_stream_request(
    headers: dict[str, str], base_url: str, path: str, payload: dict[str, Any]
) -> AsyncGenerator[bytes, None]:
    """
    Send a streaming HTTP request to a specific URL path with given headers and payload.

    Args:
        headers: The headers to include in the request.
        base_url: The base URL where the request will be sent.
        path: The specific path of the URL to which the request will be sent.
        payload: The payload (or data) to be included in the request.

    Yields:
        Bytes from the server's streaming response.

    Raises:
        HTTPException if the HTTP request fails.
    """
    import aiohttp
    from fastapi import HTTPException

    async with _aiohttp_post(headers, base_url, path, payload) as response:
        try:
            response.raise_for_status()
        except aiohttp.ClientResponseError as e:
            try:
                detail = _error_detail(await response.json()) or e.message
            except Exception:
                try:
                    detail = await response.text() or e.message
                except Exception:
                    detail = e.message
            raise HTTPException(status_code=e.status, detail=detail)

        async for line in response.content:
            yield line


def proxy_root_url(base_url: str) -> str:
    """Return the root URL for raw proxy calls by stripping the last path segment.

    Provider base URLs typically include a versioned path suffix (e.g. ``/v1``).
    Raw proxy callers pass the full API path (e.g. ``v1/messages``), so appending
    that to the base URL would produce a double-versioned URL like
    ``https://api.anthropic.com/v1/v1/messages``.  Stripping the last segment
    returns the true API root (``https://api.anthropic.com``) so the caller's
    path is appended correctly.

    Examples:
        https://api.anthropic.com/v1      → https://api.anthropic.com
        https://api.openai.com/v1         → https://api.openai.com
        https://api.groq.com/openai/v1    → https://api.groq.com/openai
    """
    parsed = urlparse(base_url)
    path = parsed.path.rstrip("/")
    new_path = path.rsplit("/", 1)[0] if "/" in path.lstrip("/") else ""
    return urlunparse(parsed._replace(path=new_path))


_STREAMING_CONTENT_TYPES = frozenset({"text/event-stream", "application/x-ndjson"})


async def send_proxy_request(
    headers: dict[str, str],
    base_url: str,
    path: str,
    payload: dict[str, Any],
) -> AsyncGenerator[dict[str, Any] | bytes, None]:
    """
    Async generator for raw proxy requests that auto-detects streaming from Content-Type.

    Yields a metadata dict as the first item:
        {"content_type": str, "is_streaming": bool}

    For streaming responses (``text/event-stream``, ``application/x-ndjson``), then yields
    raw response bytes. For non-streaming responses, yields a single parsed JSON dict.

    Callers should consume all items or explicitly call ``aclose()`` to release the
    underlying HTTP connection.
    """
    import aiohttp
    from fastapi import HTTPException

    start = time.perf_counter()
    try:
        async with _aiohttp_post(headers, base_url, path, payload) as response:
            try:
                response.raise_for_status()
            except aiohttp.ClientResponseError as e:
                try:
                    detail = _error_detail(await response.json()) or e.message
                except Exception:
                    try:
                        detail = await response.text() or e.message
                    except Exception:
                        detail = e.message
                raise HTTPException(status_code=e.status, detail=detail)

            content_type = (response.headers or {}).get("Content-Type", "application/json")
            is_streaming = content_type.split(";")[0].strip() in _STREAMING_CONTENT_TYPES

            yield {"content_type": content_type, "is_streaming": is_streaming}

            if is_streaming:
                async for chunk in response.content:
                    yield chunk
            elif "application/json" in content_type:
                yield await response.json()
            elif "text/plain" in content_type:
                yield {"message": await response.text()}
            else:
                raise HTTPException(
                    status_code=502,
                    detail=f"Unsupported Content-Type from upstream proxy: {content_type}",
                )
    finally:
        provider_call_duration_ms.set(
            provider_call_duration_ms.get() + (time.perf_counter() - start) * 1000
        )


def rename_payload_keys(payload: dict[str, Any], mapping: dict[str, str]) -> dict[str, Any]:
    """Rename payload keys based on the specified mapping. If a key is not present in the
    mapping, the key and its value will remain unchanged.

    Args:
        payload: The original dictionary to transform.
        mapping: A dictionary where each key-value pair represents a mapping from the old
            key to the new key.

    Returns:
        A new dictionary containing the transformed keys.

    """
    return {mapping.get(k, k): v for k, v in payload.items()}
