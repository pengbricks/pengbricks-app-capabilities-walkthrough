# This file contains utility functions for scorer functionality.

import ast
import hashlib
import inspect
import json
import logging
import threading
from textwrap import dedent
from typing import TYPE_CHECKING, Any, Callable, Iterator, NamedTuple

from pydantic import BaseModel

from mlflow.exceptions import INVALID_PARAMETER_VALUE, MlflowException

if TYPE_CHECKING:
    from mlflow.genai.utils.type import FunctionCall

_logger = logging.getLogger(__name__)

GATEWAY_PROVIDER = "gateway"
INSTRUCTIONS_JUDGE_PYDANTIC_DATA = "instructions_judge_pydantic_data"
BUILTIN_SCORER_PYDANTIC_DATA = "builtin_scorer_pydantic_data"

# Error message used by both the Python client (Scorer._check_can_be_registered) and the
# server handler (_register_scorer) to consistently reject decorator scorer registration
# outside of Databricks environments.
DECORATOR_SCORER_REGISTRATION_NOT_SUPPORTED_ERROR = (
    "Custom scorer registration (using @scorer decorator) is disabled by default "
    "outside of Databricks tracking environments due to security concerns. "
    "Custom scorers require arbitrary code execution during deserialization.\n\n"
    "To use custom scorers:\n"
    "1. Configure MLflow to use a Databricks tracking URI, or\n"
    "2. Manage your custom scorer code in a source code repository "
    "(e.g., GitHub) and import it directly, or\n"
    "3. On a self-managed MLflow server (or local environment) that you trust to run the "
    "scorer's code, set the MLFLOW_SERVER_ENABLE_CUSTOM_SCORERS environment variable to true, or\n"
    "4. Use built-in scorers or make_judge() scorers instead."
)

THIRD_PARTY_SCORER_REGISTRATION_NOT_SUPPORTED_ON_DATABRICKS_ERROR = (
    "Third-party scorer registration (e.g., RAGAS, DeepEval, TruLens, Phoenix) is not "
    "supported when using a Databricks tracking URI. Third-party scorers are only "
    "available for registration against OSS MLflow backends.\n\n"
    "To use third-party scorers on Databricks, pass them directly to "
    "`mlflow.genai.evaluate(..., scorers=[...])` without calling `.register()`."
)

# Restricts dynamic imports during third-party scorer deserialization to this closed set
# of the modules that define the supported scorer classes, so a malicious payload can't
# turn `model_validate` into arbitrary import. Matched verbatim, never by package prefix:
# a caller who can place a file below one of these packages (for example through a
# `file://` experiment artifact root) must not be able to have the server import it as
# `mlflow.genai.scorers.<pkg>.<run_id>.artifacts.<module>`.
THIRD_PARTY_SCORER_ALLOWED_MODULES = frozenset({
    "mlflow.genai.scorers.ragas",
    "mlflow.genai.scorers.ragas.scorers",
    "mlflow.genai.scorers.ragas.scorers.agentic_metrics",
    "mlflow.genai.scorers.ragas.scorers.comparison_metrics",
    "mlflow.genai.scorers.ragas.scorers.rag_metrics",
    "mlflow.genai.scorers.deepeval",
    "mlflow.genai.scorers.deepeval.scorers",
    "mlflow.genai.scorers.deepeval.scorers.agentic_metrics",
    "mlflow.genai.scorers.deepeval.scorers.conversational_metrics",
    "mlflow.genai.scorers.deepeval.scorers.rag_metrics",
    "mlflow.genai.scorers.deepeval.scorers.safety_metrics",
    "mlflow.genai.scorers.trulens",
    "mlflow.genai.scorers.trulens.scorers.agent_trace",
    "mlflow.genai.scorers.phoenix",
})


# FunctionBodyExtractor class is forked from https://github.com/unitycatalog/unitycatalog/blob/20dd3820be332ac04deec4e063099fb863eb3392/ai/core/src/unitycatalog/ai/core/utils/callable_utils.py
class FunctionBodyExtractor(ast.NodeVisitor):
    """
    AST NodeVisitor class to extract the body of a function.
    """

    def __init__(self, func_name: str, source_code: str):
        self.func_name = func_name
        self.source_code = source_code
        self.function_body = ""
        self.indent_unit = 4
        self.found = False

    def visit_FunctionDef(self, node: ast.FunctionDef):
        if not self.found and node.name == self.func_name:
            self.found = True
            self.extract_body(node)

    def extract_body(self, node: ast.FunctionDef):
        body = node.body
        # Skip the docstring
        if (
            body
            and isinstance(body[0], ast.Expr)
            and isinstance(body[0].value, ast.Constant)
            and isinstance(body[0].value.value, str)
        ):
            body = body[1:]

        if not body:
            return

        start_lineno = body[0].lineno
        end_lineno = body[-1].end_lineno

        source_lines = self.source_code.splitlines(keepends=True)
        function_body_lines = source_lines[start_lineno - 1 : end_lineno]

        self.function_body = dedent("".join(function_body_lines)).rstrip("\n")

        if indents := [stmt.col_offset for stmt in body if stmt.col_offset is not None]:
            self.indent_unit = min(indents)


# extract_function_body function is forked from https://github.com/unitycatalog/unitycatalog/blob/20dd3820be332ac04deec4e063099fb863eb3392/ai/core/src/unitycatalog/ai/core/utils/callable_utils.py
def extract_function_body(func: Callable[..., Any]) -> tuple[str, int]:
    """
    Extracts the body of a function as a string without the signature or docstring,
    dedents the code, and returns the indentation unit used in the function (e.g., 2 or 4 spaces).
    """
    source_lines, _ = inspect.getsourcelines(func)
    dedented_source = dedent("".join(source_lines))
    func_name = func.__name__

    extractor = FunctionBodyExtractor(func_name, dedented_source)
    parsed_source = ast.parse(dedented_source)
    extractor.visit(parsed_source)

    return extractor.function_body, extractor.indent_unit


def _extract_params_from_signature(signature: str) -> str:
    if signature.startswith("("):
        try:
            func_def = ast.parse(f"def _f{signature}: pass").body[0]
        except SyntaxError:
            pass
        else:
            return ast.unparse(func_def.args)

    raise MlflowException(
        f"Invalid signature format: '{signature}'", error_code=INVALID_PARAMETER_VALUE
    )


def recreate_function(source: str, signature: str, func_name: str) -> Callable[..., Any]:
    """
    Recreate a function from its source code, signature, and name.

    Args:
        source: The function body source code.
        signature: The function signature string (e.g., "(inputs, outputs)").
        func_name: The name of the function.

    Returns:
        The recreated function.
    """
    import mlflow

    params_str = _extract_params_from_signature(signature)

    # Build the function definition with future annotations to defer type hint evaluation
    func_def = "from __future__ import annotations\n"
    func_def += f"def {func_name}({params_str}):\n"
    # Indent the source code
    indented_source = "\n".join(f"    {line}" for line in source.split("\n"))
    func_def += indented_source

    # Create a namespace with common MLflow imports that scorer functions might use
    # Include mlflow module so type hints like "mlflow.entities.Trace" can be resolved
    import_namespace = {
        "mlflow": mlflow,
    }

    # Import commonly used MLflow classes
    try:
        from mlflow.entities import (
            Assessment,
            AssessmentError,
            AssessmentSource,
            AssessmentSourceType,
            Feedback,
            Trace,
        )
        from mlflow.genai.judges import CategoricalRating

        import_namespace.update({
            "Feedback": Feedback,
            "Assessment": Assessment,
            "AssessmentSource": AssessmentSource,
            "AssessmentError": AssessmentError,
            "AssessmentSourceType": AssessmentSourceType,
            "Trace": Trace,
            "CategoricalRating": CategoricalRating,
        })
    except ImportError:
        pass  # Some imports might not be available in all contexts

    # Local namespace will capture the created function
    local_namespace = {}

    # Execute the function definition with MLflow imports available
    exec(func_def, import_namespace, local_namespace)  # noqa: S102

    # Return the recreated function
    return local_namespace[func_name]


def is_gateway_model(model: str | None) -> bool:
    if model is None:
        return False
    from mlflow.metrics.genai.model_utils import _parse_model_uri

    try:
        provider, _ = _parse_model_uri(model)
        return provider == GATEWAY_PROVIDER
    except MlflowException:
        return False


def extract_endpoint_ref(model: str) -> str:
    from mlflow.metrics.genai.model_utils import _parse_model_uri

    _, endpoint_ref = _parse_model_uri(model)
    return endpoint_ref


def build_gateway_model(endpoint_ref: str) -> str:
    return f"{GATEWAY_PROVIDER}:/{endpoint_ref}"


def extract_model_from_serialized_scorer(serialized_data: dict[str, Any]) -> str | None:
    if ij_data := serialized_data.get(INSTRUCTIONS_JUDGE_PYDANTIC_DATA):
        return ij_data.get("model")
    if bs_data := serialized_data.get(BUILTIN_SCORER_PYDANTIC_DATA):
        return bs_data.get("model")
    if mem_data := serialized_data.get("memory_augmented_judge_data"):
        base_judge = mem_data.get("base_judge", {})
        return extract_model_from_serialized_scorer(base_judge)
    if tp_data := serialized_data.get("third_party_scorer_data"):
        return tp_data.get("model")
    return None


def update_model_in_serialized_scorer(
    serialized_data: dict[str, Any], new_model: str | None
) -> dict[str, Any]:
    result = serialized_data.copy()
    if ij_data := result.get(INSTRUCTIONS_JUDGE_PYDANTIC_DATA):
        result[INSTRUCTIONS_JUDGE_PYDANTIC_DATA] = {**ij_data, "model": new_model}
    elif bs_data := result.get(BUILTIN_SCORER_PYDANTIC_DATA):
        result[BUILTIN_SCORER_PYDANTIC_DATA] = {**bs_data, "model": new_model}
    elif mem_data := result.get("memory_augmented_judge_data"):
        result["memory_augmented_judge_data"] = {
            **mem_data,
            "base_judge": update_model_in_serialized_scorer(
                mem_data.get("base_judge", {}), new_model
            ),
        }
    elif tp_data := result.get("third_party_scorer_data"):
        if tp_data.get("model") is not None:
            result["third_party_scorer_data"] = {**tp_data, "model": new_model}
    return result


def validate_scorer_name(name: str | None) -> None:
    """
    Validate the scorer name.

    Args:
        name: The scorer name to validate.

    Raises:
        MlflowException: If the name is invalid.
    """
    if name is None:
        raise MlflowException.invalid_parameter_value("Scorer name cannot be None.")
    if not isinstance(name, str):
        raise MlflowException.invalid_parameter_value(
            f"Scorer name must be a string, got {type(name).__name__}."
        )
    if not name.strip():
        raise MlflowException.invalid_parameter_value(
            "Scorer name cannot be empty or contain only whitespace."
        )


def validate_scorer_model(model: str | None) -> None:
    """
    Validate the scorer model string if present.

    Args:
        model: The model string to validate.

    Raises:
        MlflowException: If the model is invalid.
    """
    if model is None:
        return

    if not isinstance(model, str):
        raise MlflowException.invalid_parameter_value(
            f"Scorer model must be a string, got {type(model).__name__}."
        )
    if not model.strip():
        raise MlflowException.invalid_parameter_value(
            "Scorer model cannot be empty or contain only whitespace."
        )


def parse_tool_call_expectations(
    expectations: dict[str, Any] | None,
) -> list["FunctionCall"] | None:
    from mlflow.genai.utils.type import FunctionCall

    if not expectations or "expected_tool_calls" not in expectations:
        return None

    expected_tool_calls = expectations["expected_tool_calls"]
    if not expected_tool_calls:
        return None

    normalized_calls = []
    for call in expected_tool_calls:
        if isinstance(call, FunctionCall):
            normalized_calls.append(call)
        elif isinstance(call, dict):
            name = call.get("name")
            arguments = call.get("arguments")
            if arguments is not None and not isinstance(arguments, dict):
                raise MlflowException(
                    f"Invalid arguments type: {type(arguments)}. Arguments must be a dict."
                )
            normalized_calls.append(FunctionCall(name=name, arguments=arguments))
        else:
            raise MlflowException(
                f"Invalid expected tool call format: {type(call)}. "
                "Expected dict with 'name' and optional 'arguments', or FunctionCall object."
            )

    return normalized_calls


def normalize_tool_call_arguments(args: dict[str, Any] | None) -> dict[str, Any]:
    if args is None:
        return {}
    if isinstance(args, dict):
        return args
    raise MlflowException(f"Invalid arguments type: {type(args)}. Arguments must be a dict.")


def get_tool_call_signature(call: "FunctionCall", include_arguments: bool) -> str | None:
    if include_arguments:
        args = json.dumps(normalize_tool_call_arguments(call.arguments), sort_keys=True)
        return f"{call.name}({args})"
    return call.name


class _ScorerJobParamNames(NamedTuple):
    """Scorer job names grouped by how their params carry serialized scorers."""

    inline: frozenset[str]  # a single scorer under ``serialized_scorer``
    inline_list: frozenset[str]  # a list of scorers under ``serialized_scorers``
    online: frozenset[str]  # a list of online-scorer entries under ``online_scorers``


def _scorer_job_param_names() -> _ScorerJobParamNames:
    """Scorer job names grouped by how their params carry serialized scorers.

    Imported lazily from the job definitions (the single source of truth for these names) to
    avoid a circular import, so a job rename cannot silently desync this detection.
    """
    from mlflow.genai.evaluation.job import INVOKE_GENAI_EVALUATE_JOB_NAME
    from mlflow.genai.scorers.job import (
        INVOKE_SCORER_JOB_NAME,
        ONLINE_SESSION_SCORER_JOB_NAME,
        ONLINE_TRACE_SCORER_JOB_NAME,
    )

    return _ScorerJobParamNames(
        inline=frozenset({INVOKE_SCORER_JOB_NAME}),
        inline_list=frozenset({INVOKE_GENAI_EVALUATE_JOB_NAME}),
        online=frozenset({ONLINE_TRACE_SCORER_JOB_NAME, ONLINE_SESSION_SCORER_JOB_NAME}),
    )


def _obj_has_call_source(obj: Any) -> bool:
    # Recurse so a decorator sub-scorer nested in an ensemble (under
    # ``ensemble_scorer_data["scorers"]``) is detected, not only a top-level scorer.
    if isinstance(obj, dict):
        if obj.get("call_source") is not None:
            return True
        return any(_obj_has_call_source(value) for value in obj.values())
    if isinstance(obj, list):
        return any(_obj_has_call_source(item) for item in obj)
    return False


def _parse_serialized_scorer(serialized_scorer: str) -> dict[str, Any]:
    """Parse a serialized scorer, raising on malformed input rather than swallowing it."""
    try:
        return json.loads(serialized_scorer)
    except (json.JSONDecodeError, TypeError) as e:
        raise MlflowException.invalid_parameter_value(f"Malformed serialized scorer: {e}") from e


def _iter_serialized_scorers(job_name: str, params: dict[str, Any]) -> list[str]:
    names = _scorer_job_param_names()
    if job_name in names.inline:
        s = params.get("serialized_scorer")
        return [s] if isinstance(s, str) else []
    if job_name in names.inline_list:
        return [s for s in params.get("serialized_scorers") or [] if isinstance(s, str)]
    if job_name in names.online:
        return [
            sc["serialized_scorer"]
            for sc in params.get("online_scorers") or []
            if isinstance(sc, dict) and isinstance(sc.get("serialized_scorer"), str)
        ]
    return []


def params_contain_custom_scorer_code(job_name: str, params: dict[str, Any]) -> bool:
    """Return True if a job's params carry custom (@scorer decorator) scorer code.

    Custom scorers carry a non-null ``call_source`` that is executed via ``exec()``
    during deserialization. This is the server-derived signal the job framework uses to
    gate and route custom scorers. Returns False for non-custom jobs; raises on malformed
    serialized-scorer input.
    """
    return any(
        _obj_has_call_source(_parse_serialized_scorer(s))
        for s in _iter_serialized_scorers(job_name, params)
    )


def custom_scorer_execution_blocked(serialized_data: Any) -> bool:
    """Return True if this server must NOT execute the custom code in ``serialized_data``.

    Custom (@scorer) scorers embed ``call_source`` that is run via ``exec()`` when the scorer is
    deserialized, so a server blocks them unless an operator opted in with
    ``MLFLOW_SERVER_ENABLE_CUSTOM_SCORERS``. This is the single server-side check the register and
    invoke handlers share. Recurses so a custom sub-scorer nested in an ensemble is caught too.
    """
    from mlflow.environment_variables import MLFLOW_SERVER_ENABLE_CUSTOM_SCORERS

    return _obj_has_call_source(serialized_data) and not MLFLOW_SERVER_ENABLE_CUSTOM_SCORERS.get()


# Model-URI schemes resolved through the MLflow AI Gateway or a Databricks endpoint (see
# ``convert_mlflow_uri_to_litellm``). Any other scheme -- or a bare model name with no scheme --
# is a direct-provider model a remote executor cannot resolve.
_GATEWAY_BACKED_SCHEMES = frozenset({"gateway", "endpoints", "databricks"})


def _iter_scorer_models(serialized_data: dict[str, Any]) -> list[str]:
    """Model URIs referenced by a serialized scorer, including ensemble sub-scorers.

    Uses ``extract_model_from_serialized_scorer`` (which understands the known scorer types)
    rather than scanning for arbitrary ``model`` keys, and recurses into ensemble sub-scorers.
    """
    models = []
    if model := extract_model_from_serialized_scorer(serialized_data):
        models.append(model)
    ensemble = serialized_data.get("ensemble_scorer_data")
    if isinstance(ensemble, dict):
        for sub in ensemble.get("scorers") or []:
            if isinstance(sub, dict):
                models.extend(_iter_scorer_models(sub))
    return models


def scorer_params_use_direct_provider_model(job_name: str, params: dict[str, Any]) -> bool:
    """Return True if any scorer in the job references a direct-provider (non-Gateway) model.

    A remote executor can only reach models routed through the Gateway (a ``gateway:/``,
    ``endpoints:/``, or ``databricks:/`` URI). Anything else -- another scheme (e.g. ``openai:/``)
    or a bare model name with no scheme (e.g. ``gpt-oss-120b``) -- is a direct-provider model it
    cannot resolve. Scorers with no model are compatible.
    """
    from mlflow.metrics.genai.model_utils import _parse_model_uri

    for serialized in _iter_serialized_scorers(job_name, params):
        for model in _iter_scorer_models(_parse_serialized_scorer(serialized)):
            # Fail closed: a model reachable remotely must have an explicit gateway-backed scheme.
            # A missing scheme (bare name) makes _parse_model_uri raise -> treat as direct-provider.
            try:
                provider, _ = _parse_model_uri(model)
            except MlflowException:
                return True
            if provider not in _GATEWAY_BACKED_SCHEMES:
                return True
    return False


# Version fields change on every MLflow upgrade, and `timeout` is a run limit rather than scoring
# logic (a scorer registered before the field existed loads with 0 where a fresh copy has None).
_DEFINITION_DIGEST_IGNORED_KEYS = frozenset({"mlflow_version", "serialization_version", "timeout"})
# Built-in scorers store these as sets, so their dumped order depends on the string hash seed.
_DEFINITION_DIGEST_UNORDERED_KEYS = frozenset({"required_columns"})


def _normalize_definition(value: Any) -> Any:
    if isinstance(value, dict):
        return {
            key: sorted(item)
            if key in _DEFINITION_DIGEST_UNORDERED_KEYS and isinstance(item, list)
            else _normalize_definition(item)
            for key, item in value.items()
            if key not in _DEFINITION_DIGEST_IGNORED_KEYS
        }
    if isinstance(value, list):
        return [_normalize_definition(item) for item in value]
    return value


# `evaluate()` scores rows in parallel, so threads would otherwise interleave the cache restore.
_MODEL_DUMP_LOCK = threading.Lock()


def _iter_scorer_tree(scorer: Any) -> Iterator[Any]:
    yield scorer
    for sub_scorer in getattr(scorer, "_scorers", []):
        yield from _iter_scorer_tree(sub_scorer)


def _model_dump_without_caching(scorer: Any) -> dict[str, Any]:
    # `model_dump()` caches its result on the scorer and on every nested ensemble sub-scorer, and
    # `register()` reuses that cache. Restore it, so hashing doesn't freeze the definition at its
    # first digest.
    with _MODEL_DUMP_LOCK:
        scorers = [s for s in _iter_scorer_tree(scorer) if hasattr(s, "_cached_dump")]
        cached_dumps = [s._cached_dump for s in scorers]
        try:
            return scorer.model_dump()
        finally:
            for s, cached_dump in zip(scorers, cached_dumps):
                s._cached_dump = cached_dump


def get_scorer_definition_digest(scorer: Any) -> str | None:
    """
    Hash the serialized definition of a scorer, so that the same definition has the same digest
    whether or not it is registered. Returns None when the definition can't be hashed.
    """
    try:
        try:
            definition = _model_dump_without_caching(scorer)
        except Exception:
            scorer_class = type(scorer)
            if scorer_class.__module__.startswith("mlflow."):
                # Every scorer of this class would share the class source, so it isn't an identity.
                return None
            definition = {
                "name": scorer.name,
                "class_source": inspect.getsource(scorer_class),
                "fields": BaseModel.model_dump(scorer, mode="json"),
            }
        try:
            text = json.dumps(
                _normalize_definition(definition), sort_keys=True, separators=(",", ":")
            )
        except TypeError:
            return None
        return "sha256:" + hashlib.sha256(text.encode("utf-8")).hexdigest()
    except Exception:
        _logger.debug("Failed to compute the scorer definition digest", exc_info=True)
        return None
