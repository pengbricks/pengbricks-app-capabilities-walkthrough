from functools import wraps
from typing import TYPE_CHECKING, Any

from mlflow.entities.assessment import Feedback
from mlflow.exceptions import MlflowException
from mlflow.genai.judges.constants import USE_CASE_BUILTIN_JUDGE
from mlflow.genai.judges.prompts.relevance_to_query import RELEVANCE_TO_QUERY_ASSESSMENT_NAME
from mlflow.genai.judges.structured_judge import _invoke_structured_builtin_judge
from mlflow.genai.judges.utils import CategoricalRating, get_default_model, invoke_judge_model
from mlflow.utils.docstring_utils import format_docstring

if TYPE_CHECKING:
    from mlflow.genai.utils.type import FunctionCall
    from mlflow.types.chat import ChatTool

_MODEL_API_DOC = {
    "model": """Judge model to use. Must be either `"databricks"` or a form of
`<provider>:/<model-name>`, such as `"openai:/gpt-4.1-mini"`,
`"anthropic:/claude-3.5-sonnet-20240620"`. MLflow natively supports
`["openai", "anthropic", "bedrock", "mistral", "sap-ai-core"]`, and more providers are supported
through `LiteLLM <https://docs.litellm.ai/docs/providers>`_.
For ``sap-ai-core``, set ``MLFLOW_GENAI_JUDGE_BASE_URL`` to the Orchestration v2 endpoint URL.
Default model depends on the ``MLFLOW_GENAI_JUDGE_DEFAULT_MODEL`` environment
variable and the tracking URI setup:

* If ``MLFLOW_GENAI_JUDGE_DEFAULT_MODEL`` is set, that value is used.
* Databricks tracking URI: `databricks`
* Otherwise: `openai:/gpt-4.1-mini`.
""",
}


def _sanitize_feedback(feedback: Feedback) -> Feedback:
    """Sanitize the feedback object from the databricks judges.

    The judge returns a CategoricalRating class defined in the databricks-agents package.
    This function converts it to our CategoricalRating definition above.

    Args:
        feedback: The Feedback object to convert.

    Returns:
        A new Feedback object with our CategoricalRating.
    """
    feedback.value = CategoricalRating(feedback.value) if feedback.value else feedback.value
    return feedback


def requires_databricks_agents(func):
    """Decorator to check if the `databricks-agents` package is installed."""

    @wraps(func)
    def wrapper(*args, **kwargs):
        try:
            import databricks.agents.evals.judges  # noqa: F401

        except ImportError:
            raise ImportError(
                f"The `databricks-agents` package is required to use "
                f"`mlflow.genai.judges.{func.__name__}`. "
                "Please install it with `pip install databricks-agents`."
            )

        return func(*args, **kwargs)

    return wrapper


@format_docstring(_MODEL_API_DOC)
def is_context_relevant(
    *,
    request: str,
    context: Any,
    name: str | None = None,
    model: str | None = None,
    extra_headers: dict[str, str] | None = None,
) -> Feedback:
    """
    LLM judge determines whether the given context is relevant to the input request.

    Args:
        request: Input to the application to evaluate, user's question or query.
        context: Context to evaluate the relevance to the request.
            Supports any JSON-serializable object.
        name: Optional name for overriding the default name of the returned feedback.
        model: {{ model }}
        extra_headers: Optional dictionary of additional HTTP headers to include in
            requests to the judge model (e.g. ``{"AI-Resource-Group": "default"}``
            for SAP AI Core). Default: ``None``.

    Returns:
        A :py:class:`mlflow.entities.assessment.Feedback~` object with a "yes" or "no" value
        indicating whether the context is relevant to the request.

    Example:

        The following example shows how to evaluate whether a document retrieved by a
        retriever is relevant to the user's question.

        .. code-block:: python

            from mlflow.genai.judges import is_context_relevant

            feedback = is_context_relevant(
                request="What is the capital of France?",
                context="Paris is the capital of France.",
            )
            print(feedback.value)  # "yes"

            feedback = is_context_relevant(
                request="What is the capital of France?",
                context="Paris is known for its Eiffel Tower.",
            )
            print(feedback.value)  # "no"

    """
    from mlflow.genai.judges.prompts.relevance_to_query import (
        RELEVANCE_TO_QUERY_TYPESAFE_PROMPT_INSTRUCTIONS,
        get_prompt,
    )

    model = model or get_default_model()

    # NB: User-facing name for the is_context_relevant assessment. This is required
    #     since the existing databricks judge is called `relevance_to_query`
    assessment_name = name or RELEVANCE_TO_QUERY_ASSESSMENT_NAME

    if model == "databricks":
        from databricks.agents.evals.judges import relevance_to_query

        feedback = relevance_to_query(
            request=request,
            response=str(context),
            assessment_name=assessment_name,
        )
    else:
        feedback = _invoke_structured_builtin_judge(
            model,
            chat_invoker=lambda: invoke_judge_model(
                model,
                get_prompt(request, str(context)),
                assessment_name=assessment_name,
                use_case=USE_CASE_BUILTIN_JUDGE,
                extra_headers=extra_headers,
            ),
            decision_invoke_params={
                "instructions": RELEVANCE_TO_QUERY_TYPESAFE_PROMPT_INSTRUCTIONS,
                "state": {"input": request, "output": context},
                "assessment_name": assessment_name,
                "extra_headers": extra_headers,
            },
        )

    return _sanitize_feedback(feedback)


@format_docstring(_MODEL_API_DOC)
def is_context_sufficient(
    *,
    request: str,
    context: Any,
    expected_facts: list[str],
    expected_response: str | None = None,
    name: str | None = None,
    model: str | None = None,
    extra_headers: dict[str, str] | None = None,
) -> Feedback:
    """
    LLM judge determines whether the given context is sufficient to answer the input request.

    Args:
        request: Input to the application to evaluate, user's question or query.
        context: Context to evaluate the sufficiency of. Supports any JSON-serializable object.
        expected_facts: A list of expected facts that should be present in the context. Optional.
        expected_response: The expected response from the application. Optional.
        name: Optional name for overriding the default name of the returned feedback.
        model: {{ model }}
        extra_headers: Optional dictionary of additional HTTP headers to include in
            requests to the judge model (e.g. ``{"AI-Resource-Group": "default"}``
            for SAP AI Core). Default: ``None``.

    Returns:
        A :py:class:`mlflow.entities.assessment.Feedback~` object with a "yes" or "no"
        value indicating whether the context is sufficient to answer the request.

    Example:

        The following example shows how to evaluate whether the documents returned by a
        retriever gives sufficient context to answer the user's question.

        .. code-block:: python

            from mlflow.genai.judges import is_context_sufficient

            feedback = is_context_sufficient(
                request="What is the capital of France?",
                context=[
                    {"content": "Paris is the capital of France."},
                    {"content": "Paris is known for its Eiffel Tower."},
                ],
                expected_facts=["Paris is the capital of France."],
            )
            print(feedback.value)  # "yes"

            feedback = is_context_sufficient(
                request="What is the capital of France?",
                context={"content": "France is a country in Europe."},
                expected_response="Paris is the capital of France.",
            )
            print(feedback.value)  # "no"
    """
    from mlflow.genai.judges.prompts.context_sufficiency import (
        CONTEXT_SUFFICIENCY_FEEDBACK_NAME,
        CONTEXT_SUFFICIENCY_TYPESAFE_PROMPT_INSTRUCTIONS,
        get_prompt,
    )

    model = model or get_default_model()
    assessment_name = name or CONTEXT_SUFFICIENCY_FEEDBACK_NAME

    if model == "databricks":
        from databricks.agents.evals.judges import context_sufficiency

        feedback = context_sufficiency(
            request=request,
            retrieved_context=context,
            expected_facts=expected_facts,
            expected_response=expected_response,
            assessment_name=assessment_name,
        )
    else:
        feedback = _invoke_structured_builtin_judge(
            model,
            chat_invoker=lambda: invoke_judge_model(
                model,
                get_prompt(
                    request=request,
                    context=context,
                    expected_response=expected_response,
                    expected_facts=expected_facts,
                ),
                assessment_name=assessment_name,
                use_case=USE_CASE_BUILTIN_JUDGE,
                extra_headers=extra_headers,
            ),
            decision_invoke_params={
                "instructions": CONTEXT_SUFFICIENCY_TYPESAFE_PROMPT_INSTRUCTIONS,
                "state": {
                    "input": request,
                    "ground_truth": expected_response or expected_facts or "",
                    "retrieval_context": context,
                },
                "assessment_name": assessment_name,
                "extra_headers": extra_headers,
            },
        )

    return _sanitize_feedback(feedback)


@format_docstring(_MODEL_API_DOC)
def is_correct(
    *,
    request: str,
    response: str,
    expected_facts: list[str] | None = None,
    expected_response: str | None = None,
    name: str | None = None,
    model: str | None = None,
    extra_headers: dict[str, str] | None = None,
) -> Feedback:
    """
    LLM judge determines whether the expected facts are supported by the response.

    This judge evaluates if the facts specified in ``expected_facts`` or ``expected_response``
    are contained in or supported by the model's response.

    .. note::
        This judge checks if expected facts are **supported by** the response, not whether
        the response is **equivalent to** the expected output. The response may contain
        additional information beyond the expected facts and still be considered correct.

    Args:
        request: Input to the application to evaluate, user's question or query.
        response: The response from the application to evaluate.
        expected_facts: A list of expected facts that should be supported by the response.
        expected_response: The expected response containing facts that should be supported.
        name: Optional name for overriding the default name of the returned feedback.
        model: {{ model }}
        extra_headers: Optional dictionary of additional HTTP headers to include in
            requests to the judge model (e.g. ``{"AI-Resource-Group": "default"}``
            for SAP AI Core). Default: ``None``.

    Returns:
        A :py:class:`mlflow.entities.assessment.Feedback~` object with a "yes" or "no"
        value indicating whether the expected facts are supported by the response.

    Example:

        .. code-block:: python

            from mlflow.genai.judges import is_correct

            # Response supports the expected response - correct
            feedback = is_correct(
                request="What is the capital of France?",
                response="Paris is the capital of France.",
                expected_response="Paris",
            )
            print(feedback.value)  # "yes"

            # Response contradicts the expected facts - incorrect
            feedback = is_correct(
                request="What is the capital of France?",
                response="London is the capital of France.",
                expected_facts=["Paris is the capital of France"],
            )
            print(feedback.value)  # "no"
    """
    from mlflow.genai.judges.prompts.correctness import (
        CORRECTNESS_FEEDBACK_NAME,
        CORRECTNESS_TYPESAFE_PROMPT_INSTRUCTIONS,
        get_prompt,
    )

    if expected_response is not None and expected_facts is not None:
        raise MlflowException(
            "Only one of expected_response or expected_facts should be provided, not both."
        )

    model = model or get_default_model()
    assessment_name = name or CORRECTNESS_FEEDBACK_NAME

    if model == "databricks":
        from databricks.agents.evals.judges import correctness

        feedback = correctness(
            request=request,
            response=response,
            expected_facts=expected_facts,
            expected_response=expected_response,
            assessment_name=assessment_name,
        )
    else:
        feedback = _invoke_structured_builtin_judge(
            model,
            chat_invoker=lambda: invoke_judge_model(
                model,
                get_prompt(
                    request=request,
                    response=response,
                    expected_response=expected_response,
                    expected_facts=expected_facts,
                ),
                assessment_name=assessment_name,
                use_case=USE_CASE_BUILTIN_JUDGE,
                extra_headers=extra_headers,
            ),
            decision_invoke_params={
                "instructions": CORRECTNESS_TYPESAFE_PROMPT_INSTRUCTIONS,
                "state": {
                    "input": request,
                    "output": response,
                    "ground_truth": expected_response or expected_facts or "",
                },
                "assessment_name": assessment_name,
                "extra_headers": extra_headers,
            },
        )

    return _sanitize_feedback(feedback)


@format_docstring(_MODEL_API_DOC)
def is_grounded(
    *,
    request: str,
    response: str,
    context: Any,
    name: str | None = None,
    model: str | None = None,
    extra_headers: dict[str, str] | None = None,
) -> Feedback:
    """
    LLM judge determines whether the given response is grounded in the given context.

    Args:
        request: Input to the application to evaluate, user's question or query.
        response: The response from the application to evaluate.
        context: Context to evaluate the response against. Supports any JSON-serializable object.
        name: Optional name for overriding the default name of the returned feedback.
        model: {{ model }}
        extra_headers: Optional dictionary of additional HTTP headers to include in
            requests to the judge model (e.g. ``{"AI-Resource-Group": "default"}``
            for SAP AI Core). Default: ``None``.

    Returns:
        A :py:class:`mlflow.entities.assessment.Feedback~` object with a "yes" or "no"
        value indicating whether the response is grounded in the context.

    Example:

        The following example shows how to evaluate whether the response is grounded in
        the context.

        .. code-block:: python

            from mlflow.genai.judges import is_grounded

            feedback = is_grounded(
                request="What is the capital of France?",
                response="Paris",
                context=[
                    {"content": "Paris is the capital of France."},
                    {"content": "Paris is known for its Eiffel Tower."},
                ],
            )
            print(feedback.value)  # "yes"

            feedback = is_grounded(
                request="What is the capital of France?",
                response="London is the capital of France.",
                context=[
                    {"content": "Paris is the capital of France."},
                    {"content": "Paris is known for its Eiffel Tower."},
                ],
            )
            print(feedback.value)  # "no"
    """
    from mlflow.genai.judges.prompts.groundedness import (
        GROUNDEDNESS_FEEDBACK_NAME,
        GROUNDEDNESS_TYPESAFE_PROMPT_INSTRUCTIONS,
        get_prompt,
    )

    model = model or get_default_model()
    assessment_name = name or GROUNDEDNESS_FEEDBACK_NAME

    if model == "databricks":
        from databricks.agents.evals.judges import groundedness

        feedback = groundedness(
            request=request,
            response=response,
            retrieved_context=context,
            assessment_name=assessment_name,
        )
    else:
        feedback = _invoke_structured_builtin_judge(
            model,
            chat_invoker=lambda: invoke_judge_model(
                model,
                get_prompt(
                    request=request,
                    response=response,
                    context=context,
                ),
                assessment_name=assessment_name,
                use_case=USE_CASE_BUILTIN_JUDGE,
                extra_headers=extra_headers,
            ),
            decision_invoke_params={
                "instructions": GROUNDEDNESS_TYPESAFE_PROMPT_INSTRUCTIONS,
                "state": {
                    "input": request,
                    "output": response,
                    "retrieval_context": context,
                },
                "assessment_name": assessment_name,
                "extra_headers": extra_headers,
            },
        )

    return _sanitize_feedback(feedback)


@format_docstring(_MODEL_API_DOC)
def is_tool_call_efficient(
    *,
    request: str,
    tools_called: list["FunctionCall"],
    available_tools: list["ChatTool"],
    name: str | None = None,
    model: str | None = None,
    extra_headers: dict[str, str] | None = None,
) -> Feedback:
    """
    LLM judge determines whether the agent's tool usage is efficient and free of redundancy.

    This judge analyzes the agent's trajectory for redundancy,
    such as repeated tool calls with the same tool name and identical or very similar arguments.

    Args:
        request: The original user request that the agent is trying to fulfill.
        tools_called: The sequence of tools that were called by the agent.
            Each element should be a FunctionCall object.
        available_tools: The set of available tools that the agent could choose from.
            Each element should be a dictionary containing the tool name and description.
        name: Optional name for overriding the default name of the returned feedback.
        model: {{ model }}
        extra_headers: Optional dictionary of additional HTTP headers to include in
            requests to the judge model (e.g. ``{"AI-Resource-Group": "default"}``
            for SAP AI Core). Default: ``None``.

    Returns:
        A :py:class:`mlflow.entities.assessment.Feedback~` object with a "yes" or "no" value
        indicating whether the tool usage is efficient ("yes") or contains redundancy ("no").

    Example:

        The following example shows how to evaluate whether an agent's tool calls are efficient.

        .. code-block:: python

            from mlflow.genai.judges import is_tool_call_efficient
            from mlflow.genai.utils.type import FunctionCall

            # Efficient tool usage
            feedback = is_tool_call_efficient(
                request="What is the capital of France and translate it to Spanish?",
                tools_called=[
                    FunctionCall(
                        name="search",
                        arguments={"query": "capital of France"},
                        outputs="Paris",
                    ),
                    FunctionCall(
                        name="translate",
                        arguments={"text": "Paris", "target": "es"},
                        outputs="París",
                    ),
                ],
                available_tools=["search", "translate", "calculate"],
            )
            print(feedback.value)  # "yes"

            # Redundant tool usage
            feedback = is_tool_call_efficient(
                request="What is the capital of France?",
                tools_called=[
                    FunctionCall(
                        name="search",
                        arguments={"query": "capital of France"},
                        outputs="Paris",
                    ),
                    FunctionCall(
                        name="search",
                        arguments={"query": "capital of France"},
                        outputs="Paris",
                    ),  # Redundant
                ],
                available_tools=["search", "translate", "calculate"],
            )
            print(feedback.value)  # "no"

            # Tool call with exception
            feedback = is_tool_call_efficient(
                request="Get weather for an invalid city",
                tools_called=[
                    FunctionCall(
                        name="get_weather",
                        arguments={"city": "InvalidCity123"},
                        exception="ValueError: City not found",
                    ),
                ],
                available_tools=["get_weather"],
            )
            print(feedback.value)  # Judge evaluates based on exception context

    """
    from mlflow.genai.judges.prompts.tool_call_efficiency import (
        TOOL_CALL_EFFICIENCY_FEEDBACK_NAME,
        TOOL_CALL_EFFICIENCY_TYPESAFE_PROMPT_INSTRUCTIONS,
        get_prompt,
    )

    model = model or get_default_model()
    assessment_name = name or TOOL_CALL_EFFICIENCY_FEEDBACK_NAME

    feedback = _invoke_structured_builtin_judge(
        model,
        chat_invoker=lambda: invoke_judge_model(
            model,
            get_prompt(request=request, tools_called=tools_called, available_tools=available_tools),
            assessment_name=assessment_name,
            use_case=USE_CASE_BUILTIN_JUDGE,
            extra_headers=extra_headers,
        ),
        decision_invoke_params={
            "instructions": TOOL_CALL_EFFICIENCY_TYPESAFE_PROMPT_INSTRUCTIONS,
            "state": {
                "request": request,
                "available_tools": available_tools,
                "tools_called": tools_called,
            },
            "assessment_name": assessment_name,
            "extra_headers": extra_headers,
        },
    )

    return _sanitize_feedback(feedback)


@format_docstring(_MODEL_API_DOC)
def is_tool_call_correct(
    *,
    request: str,
    tools_called: list["FunctionCall"],
    available_tools: list["ChatTool"],
    expected_tool_calls: list["FunctionCall"] | None = None,
    include_arguments: bool = True,
    check_order: bool = False,
    name: str | None = None,
    model: str | None = None,
    extra_headers: dict[str, str] | None = None,
) -> Feedback:
    """
    LLM judge determines whether the agent's tool calls and their arguments are correct
    and reasonable.

    This judge analyzes whether the tools selected and the arguments provided to them
    are appropriate for fulfilling the user's request. Optionally, it can compare against
    expected tool calls for ground-truth evaluation.

    Args:
        request: The original user request that the agent is trying to fulfill.
        tools_called: The sequence of tools that were called by the agent.
            Each element should be a FunctionCall object.
        available_tools: The set of available tools that the agent could choose from.
            Each element should be a dictionary containing the tool name and description.
        expected_tool_calls: Optional list of expected tool calls for ground-truth comparison.
            If None, uses ground-truth-free evaluation.
        include_arguments: If True, compare both tool names and arguments (full expectations).
            If False, compare only tool names (partial expectations). Only used when
            expected_tool_calls is provided.
        check_order: If True, ask LLM to consider ordering of tool calls.
        name: Optional name for overriding the default name of the returned feedback.
        model: {{ model }}
        extra_headers: Optional dictionary of additional HTTP headers to include in
            requests to the judge model (e.g. ``{"AI-Resource-Group": "default"}``
            for SAP AI Core). Default: ``None``.

    Returns:
        A :py:class:`mlflow.entities.assessment.Feedback~` object with a "yes" or "no" value
        indicating whether the tool calls and arguments are correct ("yes") or incorrect ("no").

    Example:

        The following example shows how to evaluate whether an agent's tool calls are correct.

        .. code-block:: python

            from mlflow.genai.judges import is_tool_call_correct
            from mlflow.genai.utils.type import FunctionCall

            # Correct tool usage
            feedback = is_tool_call_correct(
                request="What is the weather in San Francisco?",
                tools_called=[
                    FunctionCall(
                        name="get_weather",
                        arguments={"location": "San Francisco", "unit": "celsius"},
                        outputs="15°C, partly cloudy",
                    ),
                ],
                available_tools=["get_weather", "search", "calculate"],
            )
            print(feedback.value)  # "yes"

            # Incorrect tool usage
            feedback = is_tool_call_correct(
                request="What is the weather in San Francisco?",
                tools_called=[
                    FunctionCall(
                        name="calculate",
                        arguments={"expression": "San Francisco"},
                        outputs="Error: invalid expression",
                    ),  # Wrong tool for weather query
                ],
                available_tools=["get_weather", "search", "calculate"],
            )
            print(feedback.value)  # "no"

    """
    from mlflow.genai.judges.prompts.tool_call_correctness import (
        TOOL_CALL_CORRECTNESS_FEEDBACK_NAME,
        get_prompt,
        get_typesafe_prompt_instructions,
    )

    model = model or get_default_model()
    assessment_name = name or TOOL_CALL_CORRECTNESS_FEEDBACK_NAME

    feedback = _invoke_structured_builtin_judge(
        model,
        chat_invoker=lambda: invoke_judge_model(
            model,
            get_prompt(
                request=request,
                tools_called=tools_called,
                available_tools=available_tools,
                expected_calls=expected_tool_calls,
                include_arguments=include_arguments,
                check_order=check_order,
            ),
            assessment_name=assessment_name,
            use_case=USE_CASE_BUILTIN_JUDGE,
            extra_headers=extra_headers,
        ),
        decision_invoke_params={
            "instructions": get_typesafe_prompt_instructions(
                has_expected_calls=expected_tool_calls is not None,
                include_arguments=include_arguments,
                check_order=check_order,
            ),
            "state": {
                "request": request,
                "available_tools": available_tools,
                "tools_called": tools_called,
                **(
                    {
                        "expected_calls": (
                            [
                                {"name": call.name, "arguments": call.arguments}
                                for call in expected_tool_calls
                            ]
                            if include_arguments
                            else [call.name for call in expected_tool_calls]
                        )
                    }
                    if expected_tool_calls is not None
                    else {}
                ),
            },
            "assessment_name": assessment_name,
            "extra_headers": extra_headers,
        },
    )

    return _sanitize_feedback(feedback)


@format_docstring(_MODEL_API_DOC)
def is_safe(
    *,
    content: str,
    name: str | None = None,
    model: str | None = None,
    extra_headers: dict[str, str] | None = None,
) -> Feedback:
    """
    LLM judge determines whether the given response is safe.

    Args:
        content: Text content to evaluate for safety.
        name: Optional name for overriding the default name of the returned feedback.
        model: {{ model }}
        extra_headers: Optional dictionary of additional HTTP headers to include in
            requests to the judge model (e.g. ``{"AI-Resource-Group": "default"}``
            for SAP AI Core). Default: ``None``.

    Returns:
        A :py:class:`mlflow.entities.assessment.Feedback~` object with a "yes" or "no"
        value indicating whether the response is safe.

    Example:

        .. code-block:: python

            from mlflow.genai.judges import is_safe

            feedback = is_safe(content="I am a happy person.")
            print(feedback.value)  # "yes"
    """
    from mlflow.genai.judges.prompts.safety import (
        SAFETY_ASSESSMENT_NAME,
        SAFETY_TYPESAFE_PROMPT_INSTRUCTIONS,
        get_prompt,
    )

    model = model or get_default_model()
    assessment_name = name or SAFETY_ASSESSMENT_NAME

    if model == "databricks":
        from databricks.agents.evals.judges import safety

        feedback = safety(response=content, assessment_name=assessment_name)
    else:
        feedback = _invoke_structured_builtin_judge(
            model,
            chat_invoker=lambda: invoke_judge_model(
                model,
                get_prompt(content=content),
                assessment_name=assessment_name,
                use_case=USE_CASE_BUILTIN_JUDGE,
                extra_headers=extra_headers,
            ),
            decision_invoke_params={
                "instructions": SAFETY_TYPESAFE_PROMPT_INSTRUCTIONS,
                "state": {"content": content},
                "assessment_name": assessment_name,
                "extra_headers": extra_headers,
            },
        )

    return _sanitize_feedback(feedback)


@format_docstring(_MODEL_API_DOC)
def meets_guidelines(
    *,
    guidelines: str | list[str],
    context: dict[str, Any],
    name: str | None = None,
    model: str | None = None,
    extra_headers: dict[str, str] | None = None,
) -> Feedback:
    """
    LLM judge determines whether the given response meets the given guideline(s).

    Args:
        guidelines: A single guideline or a list of guidelines.
        context: Mapping of context to be evaluated against the guidelines. For example,
            pass {"response": "<response text>"} to evaluate whether the response meets
            the given guidelines.
        name: Optional name for overriding the default name of the returned feedback.
        model: {{ model }}
        extra_headers: Optional dictionary of additional HTTP headers to include in
            requests to the judge model (e.g. ``{"AI-Resource-Group": "default"}``
            for SAP AI Core). Default: ``None``.

    Returns:
        A :py:class:`mlflow.entities.assessment.Feedback~` object with a "yes" or "no"
        value indicating whether the response meets the guideline(s).

    Example:

        The following example shows how to evaluate whether the response meets the given
        guideline(s).

        .. code-block:: python

            from mlflow.genai.judges import meets_guidelines

            feedback = meets_guidelines(
                guidelines="Be polite and respectful.",
                context={"response": "Hello, how are you?"},
            )
            print(feedback.value)  # "yes"

            feedback = meets_guidelines(
                guidelines=["Be polite and respectful.", "Must be in English."],
                context={"response": "Hola, ¿cómo estás?"},
            )
            print(feedback.value)  # "no"
    """
    from mlflow.genai.judges.prompts.guidelines import (
        GUIDELINES_FEEDBACK_NAME,
        GUIDELINES_TYPESAFE_PROMPT_INSTRUCTIONS,
        get_prompt,
    )

    model = model or get_default_model()

    if model == "databricks":
        from databricks.agents.evals.judges import guidelines as guidelines_judge

        feedback = guidelines_judge(
            guidelines=guidelines,
            context=context,
            assessment_name=name,
        )
    else:
        feedback = _invoke_structured_builtin_judge(
            model,
            chat_invoker=lambda: invoke_judge_model(
                model,
                get_prompt(guidelines, context),
                assessment_name=name or GUIDELINES_FEEDBACK_NAME,
                use_case=USE_CASE_BUILTIN_JUDGE,
                extra_headers=extra_headers,
            ),
            decision_invoke_params={
                "instructions": GUIDELINES_TYPESAFE_PROMPT_INSTRUCTIONS,
                "state": {"guidelines": guidelines, "guidelines_context": context},
                "assessment_name": name or GUIDELINES_FEEDBACK_NAME,
                "extra_headers": extra_headers,
            },
        )

    return _sanitize_feedback(feedback)
