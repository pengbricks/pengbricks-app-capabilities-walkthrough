"""Native TypeSafe System One judge invocation."""

from __future__ import annotations

import json
import math
import os
import re
from dataclasses import dataclass
from typing import Any, Literal, get_args, get_origin
from urllib.parse import urlparse

import requests

from mlflow.entities.assessment import Feedback
from mlflow.entities.assessment_source import AssessmentSource, AssessmentSourceType
from mlflow.environment_variables import MLFLOW_GATEWAY_ROUTE_TIMEOUT_SECONDS
from mlflow.exceptions import MlflowException
from mlflow.gateway.constants import (
    TYPESAFE_API_BASE_URL,
    TYPESAFE_SYSTEM_ONE_PATH,
)
from mlflow.genai.utils.gateway_utils import _resolve_gateway_uri
from mlflow.protos.databricks_pb2 import (
    BAD_REQUEST,
    INTERNAL_ERROR,
    INVALID_PARAMETER_VALUE,
    UNAUTHENTICATED,
)
from mlflow.telemetry.events import InvokeCustomJudgeModelEvent
from mlflow.telemetry.track import record_usage_event
from mlflow.tracing.constant import AssessmentMetadataKey
from mlflow.tracing.utils import TraceJSONEncoder
from mlflow.utils.credentials import get_default_host_creds
from mlflow.utils.request_utils import _get_http_response_with_retries
from mlflow.utils.rest_utils import http_request
from mlflow.utils.uri import append_to_uri_path

_RETRY_CODES = (408, 429, 500, 502, 503, 504, 529)
_GATEWAY_PROVIDER = "gateway"
_TYPESAFE_PROVIDER = "typesafe"
_SUPPORTED_PROVIDERS = frozenset({_GATEWAY_PROVIDER, _TYPESAFE_PROVIDER})
# Older gateway servers reject a non-System-One endpoint on the System One route with this
# legacy wording; current servers return _NON_TYPESAFE_GATEWAY_DETAIL. Both are accepted so a
# new client keeps detecting "not a System One endpoint" against a server that predates the
# message change. Drop the legacy string once the minimum supported server version emits only
# the new one.
_LEGACY_NON_TYPESAFE_GATEWAY_DETAIL = "Gateway endpoint does not use the TypeSafe provider."
_NON_TYPESAFE_GATEWAY_DETAIL = (
    "Gateway endpoint does not use a System One model. Use a TypeSafe or OpenRouter "
    "Jev decision model."
)
_NON_TYPESAFE_GATEWAY_DETAILS = {
    _LEGACY_NON_TYPESAFE_GATEWAY_DETAIL,
    _NON_TYPESAFE_GATEWAY_DETAIL,
}
_QUESTION_NAME = "evaluation"
_STATE_REFERENCE_PATTERN = re.compile(r"\{\{\s*([A-Za-z_][A-Za-z0-9_]*)\s*\}\}")
_TRACE_REFERENCE_PATTERN = re.compile(r"\{\{\s*trace\s*\}\}")


class _PreserveAuthorizationHeaderAuth(requests.auth.AuthBase):
    """Prevent Requests from replacing the selected Authorization header with .netrc auth."""

    def __call__(self, request: requests.PreparedRequest) -> requests.PreparedRequest:
        return request


_PRESERVE_AUTHORIZATION_HEADER_AUTH = _PreserveAuthorizationHeaderAuth()


@dataclass
class _NoulSpec:
    answer_type: Literal["noul"] = "noul"


@dataclass
class _ChoiceSpec:
    choices: dict[str, Any]
    answer_type: Literal["choice"] = "choice"


_AnswerSpec = _NoulSpec | _ChoiceSpec


def _is_typesafe_model(model_uri: str) -> bool:
    provider, separator, _ = model_uri.partition(":/")
    return bool(separator) and provider == _TYPESAFE_PROVIDER


class _GatewayEndpointNotSystemOne(Exception):
    pass


@record_usage_event(InvokeCustomJudgeModelEvent)
def _invoke_typesafe_judge(
    model_uri: str,
    *,
    instructions: str,
    state: dict[str, Any],
    feedback_value_type: Any,
    assessment_name: str,
    num_retries: int = 10,
    inference_params: dict[str, Any] | None = None,
    base_url: str | None = None,
    extra_headers: dict[str, str] | None = None,
) -> Feedback:
    """Invoke a TypeSafe model through its native System One evaluation API."""
    from mlflow.metrics.genai.model_utils import _parse_model_uri

    provider, model_name = _parse_model_uri(model_uri)
    if provider not in _SUPPORTED_PROVIDERS:
        raise MlflowException.invalid_parameter_value(
            f"Expected a typesafe:/ or gateway:/ model URI, got {model_uri!r}."
        )
    _validate_options(provider, inference_params, base_url, extra_headers)
    _validate_input(instructions, state)

    question, answer_spec = _build_question(feedback_value_type)
    question["instructions"] = _rewrite_state_references(instructions, state)
    payload = {
        "model": model_name,
        "state": _serialize_state(state),
        "questions": {_QUESTION_NAME: question},
    }

    response = (
        _send_gateway_request(payload, num_retries)
        if provider == _GATEWAY_PROVIDER
        else _send_request(payload, num_retries, base_url, extra_headers)
    )
    response_data = _parse_json_response(
        response, allow_gateway_fallback=provider == _GATEWAY_PROVIDER
    )
    value, metadata, _, _ = _parse_response(response_data, answer_spec)

    return Feedback(
        name=assessment_name,
        value=value,
        rationale=None,
        source=AssessmentSource(
            source_type=AssessmentSourceType.LLM_JUDGE,
            source_id=model_uri,
        ),
        metadata=metadata,
    )


def _validate_options(
    provider: str,
    inference_params: dict[str, Any] | None,
    base_url: str | None,
    extra_headers: dict[str, str] | None,
) -> None:
    unsupported_options = ["inference_params"] if inference_params is not None else []
    if provider == _GATEWAY_PROVIDER:
        unsupported_options.extend(
            name
            for name, value in (("base_url", base_url), ("extra_headers", extra_headers))
            if value is not None
        )
    if unsupported_options:
        raise MlflowException.invalid_parameter_value(
            "TypeSafe judge models do not support " + ", ".join(unsupported_options) + "."
        )
    if base_url is not None:
        if not base_url.strip().strip("/"):
            raise MlflowException.invalid_parameter_value("base_url must be a non-empty string.")
        try:
            parsed_base_url = urlparse(base_url)
            if parsed_base_url.scheme not in {"http", "https"} or not parsed_base_url.hostname:
                raise ValueError
            _ = parsed_base_url.port
            _ = parsed_base_url.hostname.encode("idna")
        except (UnicodeError, ValueError):
            raise MlflowException.invalid_parameter_value(
                "base_url must be an absolute HTTP or HTTPS URL with a valid host and port."
            ) from None
        if parsed_base_url.username is not None or parsed_base_url.password is not None:
            raise MlflowException.invalid_parameter_value(
                "Credentials in base_url are not supported. Pass an Authorization header in "
                "extra_headers instead."
            )


def _validate_input(instructions: str, state: dict[str, Any]) -> None:
    if not isinstance(instructions, str) or not instructions.strip():
        raise MlflowException(
            "TypeSafe evaluation instructions must be a non-empty string.",
            error_code=INVALID_PARAMETER_VALUE,
        )
    if _TRACE_REFERENCE_PATTERN.search(instructions):
        raise MlflowException(
            "TypeSafe judge models do not support trace-based tool calling. Use structured "
            "inputs, outputs, expectations, or conversation state instead.",
            error_code=INVALID_PARAMETER_VALUE,
        )
    if not isinstance(state, dict):
        raise MlflowException(
            "TypeSafe evaluation state must be a dictionary.",
            error_code=INVALID_PARAMETER_VALUE,
        )


def _send_request(
    payload: dict[str, Any],
    num_retries: int,
    base_url: str | None,
    extra_headers: dict[str, str] | None,
):
    api_key = os.environ.get("TYPESAFE_API_KEY")
    headers = dict(extra_headers or {})
    authorization_headers = [
        value for name, value in headers.items() if name.lower() == "authorization"
    ]
    if authorization_headers and any(
        not isinstance(value, str) or not value.strip() for value in authorization_headers
    ):
        raise MlflowException.invalid_parameter_value(
            "Authorization header in extra_headers must be non-empty."
        )
    if not authorization_headers and api_key:
        headers["Authorization"] = f"Bearer {api_key}"
    elif not authorization_headers:
        raise MlflowException(
            "Set TYPESAFE_API_KEY or pass an Authorization header in extra_headers to invoke "
            "a typesafe:/ judge model.",
            error_code=INVALID_PARAMETER_VALUE,
        )
    endpoint = append_to_uri_path(base_url or TYPESAFE_API_BASE_URL, TYPESAFE_SYSTEM_ONE_PATH)
    try:
        return _get_http_response_with_retries(
            method="POST",
            url=endpoint,
            headers=headers,
            auth=_PRESERVE_AUTHORIZATION_HEADER_AUTH,
            json=payload,
            max_retries=num_retries,
            backoff_factor=1,
            backoff_jitter=0.1,
            retry_codes=_RETRY_CODES,
            timeout=MLFLOW_GATEWAY_ROUTE_TIMEOUT_SECONDS.get(),
            raise_on_status=False,
            allow_redirects=False,
        )
    except requests.RequestException:
        raise MlflowException(
            "Failed to connect to the TypeSafe evaluation endpoint.",
            error_code=INTERNAL_ERROR,
        ) from None


def _send_gateway_request(payload: dict[str, Any], num_retries: int):
    gateway_uri = _resolve_gateway_uri()
    return http_request(
        host_creds=get_default_host_creds(gateway_uri),
        endpoint="/gateway/typesafe/v1/systemone",
        method="POST",
        max_retries=num_retries,
        backoff_factor=1,
        backoff_jitter=0.1,
        retry_codes=_RETRY_CODES,
        timeout=MLFLOW_GATEWAY_ROUTE_TIMEOUT_SECONDS.get(),
        raise_on_status=False,
        json=payload,
    )


def _rewrite_state_references(instructions: str, state: dict[str, Any]) -> str:
    def replace(match: re.Match) -> str:
        field = match.group(1)
        return f"state.{field}" if field in state else match.group(0)

    return _STATE_REFERENCE_PATTERN.sub(replace, instructions)


def _serialize_state(state: dict[str, Any]) -> dict[str, Any]:
    try:
        serialized = json.dumps(state, cls=TraceJSONEncoder, allow_nan=False)
        return json.loads(serialized)
    except (TypeError, ValueError):
        raise MlflowException(
            "TypeSafe evaluation state must contain JSON-serializable values without NaN or "
            "infinity.",
            error_code=INVALID_PARAMETER_VALUE,
        ) from None


def _build_question(feedback_value_type: Any) -> tuple[dict[str, Any], _AnswerSpec]:
    if feedback_value_type is bool:
        return {"type": "noul"}, _NoulSpec()

    if get_origin(feedback_value_type) is not Literal:
        raise MlflowException(
            "TypeSafe judge models support bool or finite Literal feedback value types. "
            f"Got {feedback_value_type!r}.",
            error_code=INVALID_PARAMETER_VALUE,
        )

    values = get_args(feedback_value_type)
    if not 1 <= len(values) <= 255:
        raise MlflowException(
            "TypeSafe Literal feedback value types must contain between 1 and 255 values.",
            error_code=INVALID_PARAMETER_VALUE,
        )
    for value in values:
        _validate_literal_value(value)

    choices: dict[str, Any] = {}
    criteria: dict[str, str] = {}
    for value in values:
        label = _literal_label(value)
        if not label.strip():
            raise MlflowException(
                "TypeSafe Literal feedback values must produce non-empty choice labels.",
                error_code=INVALID_PARAMETER_VALUE,
            )
        if label in choices:
            raise MlflowException(
                "TypeSafe Literal feedback values must have distinct string representations. "
                f"The label {label!r} is ambiguous.",
                error_code=INVALID_PARAMETER_VALUE,
            )
        choices[label] = value
        criteria[label] = _describe_literal(value)
    return (
        {"type": "choice", "criteria": criteria},
        _ChoiceSpec(choices=choices),
    )


def _validate_literal_value(value: Any) -> None:
    if type(value) not in (str, int, float, bool):
        raise MlflowException(
            "TypeSafe Literal feedback values must be JSON string, number, or boolean scalars.",
            error_code=INVALID_PARAMETER_VALUE,
        )
    if type(value) is float and not math.isfinite(value):
        raise MlflowException(
            "TypeSafe Literal feedback values cannot contain NaN or infinity.",
            error_code=INVALID_PARAMETER_VALUE,
        )


def _literal_label(value: Any) -> str:
    if type(value) is str:
        return value
    return json.dumps(value, ensure_ascii=False, allow_nan=False)


def _describe_literal(value: Any) -> str:
    return f"The evaluation result is {_literal_label(value)}."


def _parse_json_response(response, *, allow_gateway_fallback: bool = False) -> dict[str, Any]:
    if not 200 <= response.status_code < 300:
        if allow_gateway_fallback and response.status_code in (404, 422):
            try:
                detail = response.json().get("detail")
            except (AttributeError, ValueError):
                detail = None
            if (response.status_code == 404 and detail == "Not Found") or (
                response.status_code == 422 and detail in _NON_TYPESAFE_GATEWAY_DETAILS
            ):
                raise _GatewayEndpointNotSystemOne
        if response.status_code in (401, 403):
            error_code = UNAUTHENTICATED
        elif response.status_code < 500:
            error_code = BAD_REQUEST
        else:
            error_code = INTERNAL_ERROR
        raise MlflowException(
            f"TypeSafe evaluation failed with HTTP {response.status_code}. Check the endpoint "
            "configuration, credentials, and evaluation schema.",
            error_code=error_code,
        )
    try:
        response_data = response.json()
    except ValueError:
        raise MlflowException(
            "TypeSafe evaluation returned invalid JSON.", error_code=BAD_REQUEST
        ) from None
    if not isinstance(response_data, dict):
        raise MlflowException(
            "TypeSafe evaluation returned an invalid response.", error_code=BAD_REQUEST
        )
    return response_data


def _parse_response(
    response: dict[str, Any], answer_spec: _AnswerSpec
) -> tuple[Any, dict[str, str], int | None, int | None]:
    try:
        model = response["model"]
        answer = response["answers"][_QUESTION_NAME]
        if not isinstance(model, str) or not model or not isinstance(answer, dict):
            raise ValueError
        if answer.get("type") != answer_spec.answer_type:
            raise ValueError

        metadata = {"typesafe.model": model}
        match answer_spec:
            case _NoulSpec():
                probability = _number(answer["noul"], minimum=0, maximum=1)
                metadata["typesafe.probability"] = json.dumps(probability)
                value = probability >= 0.5
            case _ChoiceSpec(choices=choices):
                choice = answer["choice"]
                if not isinstance(choice, str) or choice not in choices:
                    raise ValueError
                probabilities = _probabilities(answer["probabilities"], set(choices))
                confidence = _number(answer["confidence"], minimum=0, maximum=1)
                metadata["typesafe.probabilities"] = json.dumps(
                    probabilities, ensure_ascii=False, sort_keys=True, allow_nan=False
                )
                metadata["typesafe.confidence"] = json.dumps(confidence)
                if "legend" in answer:
                    legend = answer["legend"]
                    if (
                        not isinstance(legend, dict)
                        or set(legend) != set(choices)
                        or any(not isinstance(key, str) for key in legend)
                        or any(not isinstance(description, str) for description in legend.values())
                    ):
                        raise ValueError
                    metadata["typesafe.legend"] = json.dumps(
                        legend, ensure_ascii=False, sort_keys=True
                    )
                value = choices[choice]

        input_tokens, output_tokens = _parse_usage(response.get("usage"), metadata)
        return value, metadata, input_tokens, output_tokens
    except (KeyError, TypeError, ValueError, AttributeError):
        raise _invalid_response(answer_spec.answer_type) from None


def _number(value: Any, minimum: float, maximum: float) -> float:
    if type(value) not in (int, float) or not minimum <= value <= maximum:
        raise ValueError
    if type(value) is float and not math.isfinite(value):
        raise ValueError
    return float(value)


def _probabilities(value: Any, expected_keys: set[str]) -> dict[str, float]:
    if not isinstance(value, dict) or set(value) != expected_keys:
        raise ValueError
    probabilities = {
        key: _number(probability, minimum=0, maximum=1) for key, probability in value.items()
    }
    if not math.isclose(sum(probabilities.values()), 1, abs_tol=1e-3):
        raise ValueError
    return probabilities


def _parse_usage(usage: Any, metadata: dict[str, str]) -> tuple[int | None, int | None]:
    if usage is None:
        return None, None
    if not isinstance(usage, dict):
        raise ValueError

    counts = []
    for field, metadata_key in (
        ("input_tokens", AssessmentMetadataKey.JUDGE_INPUT_TOKENS),
        ("output_tokens", AssessmentMetadataKey.JUDGE_OUTPUT_TOKENS),
    ):
        count = usage.get(field)
        if count is not None:
            if type(count) is not int or count < 0:
                raise ValueError
            metadata[metadata_key] = str(count)
        counts.append(count)
    return counts[0], counts[1]


def _invalid_response(answer_type: str) -> MlflowException:
    return MlflowException(
        f"TypeSafe evaluation returned an invalid {answer_type} answer.",
        error_code=BAD_REQUEST,
    )


__all__ = [
    "_GatewayEndpointNotSystemOne",
    "_invoke_typesafe_judge",
    "_is_typesafe_model",
]
