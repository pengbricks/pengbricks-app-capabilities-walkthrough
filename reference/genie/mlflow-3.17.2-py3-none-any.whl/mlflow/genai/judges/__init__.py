# Make utils available as an attribute for mocking
from mlflow.genai.judges import utils  # noqa: F401
from mlflow.genai.judges.base import AlignmentOptimizer, Judge
from mlflow.genai.judges.builtin import (
    is_context_relevant,
    is_context_sufficient,
    is_correct,
    is_grounded,
    is_safe,
    is_tool_call_correct,
    is_tool_call_efficient,
    meets_guidelines,
)
from mlflow.genai.judges.custom_prompt_judge import custom_prompt_judge
from mlflow.genai.judges.make_judge import make_judge
from mlflow.genai.judges.model_api import ModelAPI
from mlflow.genai.judges.utils import CategoricalRating

__all__ = [
    # Core Judge class
    "Judge",
    # Judge factory
    "make_judge",
    "ModelAPI",
    "AlignmentOptimizer",
    # Existing builtin judges
    "CategoricalRating",
    "is_grounded",
    "is_safe",
    "is_correct",
    "is_context_relevant",
    "is_context_sufficient",
    "is_tool_call_correct",
    "is_tool_call_efficient",
    "meets_guidelines",
    "custom_prompt_judge",
]
