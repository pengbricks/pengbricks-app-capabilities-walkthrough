from __future__ import annotations

from mlflow.exceptions import MlflowException
from mlflow.protos import databricks_pb2
from mlflow.utils.server_info import (
    SERVER_FEATURES_ENDPOINT,
    SERVER_INFO_ENDPOINT,
    SERVER_INFO_WORKSPACES_ENABLED,
    ServerInfoRequestError,
    _fetch_server_features,
    fetch_server_info,
)
from mlflow.utils.uri import is_databricks_uri
from mlflow.utils.workspace_context import get_request_workspace


class WorkspaceRestStoreMixin:
    """
    Shared workspace capability detection for REST-based stores.
    """

    _WORKSPACE_UNSUPPORTED_ERROR = (
        "Active workspace '{workspace}' cannot be used because the remote server does not "
        "support workspaces. Restart the server with --enable-workspaces or unset the active "
        "workspace."
    )
    _WORKSPACE_SUPPORT_UNDETERMINED_ERROR = (
        "MLflow could not determine whether the server supports workspaces, because "
        "the MLflow server-info and server-features endpoints were not found (HTTP 404). "
        "Verify that the configured MLflow URI points to the MLflow server, including any "
        "required path prefix."
    )
    _WORKSPACE_SUPPORT_UNDETERMINED_WITH_WORKSPACE_ERROR = (
        "Active workspace '{workspace}' cannot be used. "
        f"{_WORKSPACE_SUPPORT_UNDETERMINED_ERROR}"
        " If the configured MLflow URI is correct, ensure that the server supports "
        "workspaces and restart it with --enable-workspaces."
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._workspace_support: bool | None = None

    @property
    def supports_workspaces(self) -> bool:
        if self._workspace_support is not None:
            return self._workspace_support

        host_creds = self.get_host_creds()
        store_uri = getattr(host_creds, "host", None)
        if store_uri and is_databricks_uri(store_uri):
            self._workspace_support = False
            return False

        supported = self._probe_workspace_support()
        self._workspace_support = supported
        return supported

    def _validate_workspace_support_if_specified(self) -> None:
        """
        Raise an error if a workspace is active but the server doesn't support workspaces.
        """
        workspace = get_request_workspace()
        if workspace is None:
            return
        if not self.supports_workspaces:
            raise MlflowException(
                self._WORKSPACE_UNSUPPORTED_ERROR.format(workspace=workspace),
                error_code=databricks_pb2.FEATURE_DISABLED,
            )

    def _probe_workspace_support(self) -> bool:
        host_creds = self.get_host_creds()
        endpoint = SERVER_INFO_ENDPOINT
        try:
            response = fetch_server_info(host_creds)
        except ServerInfoRequestError as exc:  # pragma: no cover - network errors vary
            raise MlflowException(
                message=f"Failed to query {SERVER_INFO_ENDPOINT}: {exc}",
                error_code=databricks_pb2.INTERNAL_ERROR,
            ) from exc

        if response.status_code == 404:
            endpoint = SERVER_FEATURES_ENDPOINT
            try:
                response = _fetch_server_features(host_creds)
            except ServerInfoRequestError as exc:  # pragma: no cover - network errors vary
                raise MlflowException(
                    message=f"Failed to query {SERVER_FEATURES_ENDPOINT}: {exc}",
                    error_code=databricks_pb2.INTERNAL_ERROR,
                ) from exc

            if response.status_code == 404:
                workspace = get_request_workspace()
                if workspace is not None:
                    raise MlflowException(
                        message=self._WORKSPACE_SUPPORT_UNDETERMINED_WITH_WORKSPACE_ERROR.format(
                            workspace=workspace
                        ),
                        error_code=databricks_pb2.INVALID_PARAMETER_VALUE,
                    )
                raise MlflowException(
                    message=self._WORKSPACE_SUPPORT_UNDETERMINED_ERROR,
                    error_code=databricks_pb2.INVALID_PARAMETER_VALUE,
                )

        if response.status_code != 200:
            raise MlflowException(
                message=f"Failed to query {endpoint}: {response.status_code} {response.text}",
                error_code=databricks_pb2.TEMPORARILY_UNAVAILABLE,
            )

        return response.data.get(SERVER_INFO_WORKSPACES_ENABLED, False)
