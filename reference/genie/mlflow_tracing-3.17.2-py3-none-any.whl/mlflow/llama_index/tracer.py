import inspect
import json
import logging
from contextlib import contextmanager
from functools import singledispatchmethod
from typing import Any, Generator

import llama_index.core
import pydantic
from llama_index.core.base.base_retriever import BaseRetriever
from llama_index.core.base.embeddings.base import BaseEmbedding
from llama_index.core.base.llms.base import BaseLLM
from llama_index.core.base.llms.types import ChatResponse, CompletionResponse
from llama_index.core.base.response.schema import AsyncStreamingResponse, StreamingResponse
from llama_index.core.chat_engine.types import StreamingAgentChatResponse
from llama_index.core.instrumentation.event_handlers import BaseEventHandler
from llama_index.core.instrumentation.events import BaseEvent
from llama_index.core.instrumentation.events.agent import AgentToolCallEvent
from llama_index.core.instrumentation.events.embedding import EmbeddingStartEvent
from llama_index.core.instrumentation.events.exception import ExceptionEvent
from llama_index.core.instrumentation.events.llm import (
    LLMChatEndEvent,
    LLMChatStartEvent,
    LLMCompletionEndEvent,
    LLMCompletionStartEvent,
    LLMPredictStartEvent,
)
from llama_index.core.instrumentation.events.rerank import ReRankStartEvent
from llama_index.core.instrumentation.span.base import BaseSpan
from llama_index.core.instrumentation.span_handlers import BaseSpanHandler
from llama_index.core.multi_modal_llms import MultiModalLLM
from llama_index.core.schema import NodeWithScore
from llama_index.core.tools import BaseTool
from packaging.version import Version

import mlflow
from mlflow.entities import LiveSpan, SpanEvent, SpanType
from mlflow.entities.document import Document
from mlflow.entities.span_status import SpanStatusCode
from mlflow.tracing.constant import SpanAttributeKey, TokenUsageKey
from mlflow.tracing.fluent import start_span_no_context
from mlflow.tracing.provider import detach_span_from_context, set_span_in_context
from mlflow.tracing.utils import set_span_chat_tools

try:
    from llama_index.core.instrumentation.span import active_span_id
except ImportError:
    # Older LlamaIndex releases do not expose the instrumentation context variable.
    active_span_id = None

_logger = logging.getLogger(__name__)


@contextmanager
def _stream_span_context(span: LiveSpan, llama_span_id: str | None):
    mlflow_token = set_span_in_context(span)
    try:
        llama_token = (
            active_span_id.set(llama_span_id)
            if active_span_id and llama_span_id is not None
            else None
        )
        try:
            yield
        finally:
            if llama_token:
                active_span_id.reset(llama_token)
    finally:
        detach_span_from_context(mlflow_token)


def _get_llama_index_version() -> Version:
    return Version(llama_index.core.__version__)


def set_llama_index_tracer():
    """
    Set the MlflowSpanHandler and MlflowEventHandler to the global dispatcher.
    If the handlers are already set, skip setting.
    """
    from llama_index.core.instrumentation import get_dispatcher

    dsp = get_dispatcher()
    span_handler = None
    for handler in dsp.span_handlers:
        if isinstance(handler, MlflowSpanHandler):
            _logger.debug("MlflowSpanHandler is already set to the dispatcher. Skip setting.")
            span_handler = handler
            break
    else:
        span_handler = MlflowSpanHandler()
        dsp.add_span_handler(span_handler)

    for handler in dsp.event_handlers:
        if isinstance(handler, MlflowEventHandler):
            _logger.debug("MlflowEventHandler is already set to the dispatcher. Skip setting.")
            break
    else:
        dsp.add_event_handler(MlflowEventHandler(span_handler))


def remove_llama_index_tracer():
    """
    Remove the MlflowSpanHandler and MlflowEventHandler from the global dispatcher.
    """
    from llama_index.core.instrumentation import get_dispatcher

    dsp = get_dispatcher()
    dsp.span_handlers = [h for h in dsp.span_handlers if h.class_name() != "MlflowSpanHandler"]
    dsp.event_handlers = [h for h in dsp.event_handlers if h.class_name() != "MlflowEventHandler"]


class _LlamaSpan(BaseSpan, extra="allow"):
    _mlflow_span: LiveSpan = pydantic.PrivateAttr()

    def __init__(self, id_: str, parent_id: str | None, mlflow_span: LiveSpan):
        super().__init__(id_=id_, parent_id=parent_id)
        self._mlflow_span = mlflow_span


def _end_span(span: LiveSpan, status=SpanStatusCode.OK, outputs=None, token=None):
    """An utility function to end the span or trace."""
    if isinstance(outputs, (StreamingResponse, AsyncStreamingResponse, StreamingAgentChatResponse)):
        _logger.warning(
            "Trying to record streaming response to the MLflow trace. This may consume "
            "the generator and result in an empty response."
        )

    # for retriever spans, convert the outputs to Document objects
    # so they can be rendered in a more user-friendly way in the UI
    if (
        span.span_type == SpanType.RETRIEVER
        and isinstance(outputs, list)
        and all(isinstance(item, NodeWithScore) for item in outputs)
    ):
        try:
            outputs = [Document.from_llama_index_node_with_score(node) for node in outputs]
        except Exception as e:
            _logger.debug(
                f"Failed to convert NodeWithScore to Document objects: {e}", exc_info=True
            )

    if outputs is None:
        outputs = span.outputs

    try:
        span.end(status=status, outputs=outputs)
    finally:
        # We should detach span even when end_span / end_trace API call fails
        if token:
            detach_span_from_context(token)


def _is_workflow_handler(result):
    """Check if the result is a WorkflowHandler from llama-index-workflows >= 2.0."""
    try:
        from workflows.handler import WorkflowHandler

        return isinstance(result, WorkflowHandler)
    except (ImportError, ModuleNotFoundError):
        return False


def _extract_workflow_inputs(arguments: dict[str, Any]) -> dict[str, Any]:
    """Extract user-facing inputs from workflow span arguments.

    In llama-index-workflows >= 2.0 (llama-index-core >= 0.14.16), the workflow runtime
    instruments Workflow.run differently: bound_args contains internal runtime state
    (init_state, start_event, tags) instead of the original kwargs. Extract the user kwargs
    from the StartEvent object to produce clean span inputs.
    """
    start_event = arguments.get("start_event")
    if start_event is None:
        return arguments

    try:
        from llama_index.core.workflow import StartEvent

        if isinstance(start_event, StartEvent):
            return start_event.to_dict()
    except ImportError:
        pass

    return arguments


class MlflowSpanHandler(BaseSpanHandler[_LlamaSpan], extra="allow"):
    def __init__(self):
        super().__init__()
        self._span_id_to_token = {}
        self._stream_resolver = StreamResolver()
        self._pending_spans: dict[str, _LlamaSpan] = {}
        # Track workflow spans that are pending completion (WorkflowHandler returned)
        self._pending_workflow_span_ids: set[str] = set()

    @classmethod
    def class_name(cls) -> str:
        return "MlflowSpanHandler"

    def get_span_for_event(self, event: BaseEvent) -> LiveSpan:
        with self.lock:
            llama_span = self.open_spans.get(event.span_id) or self._pending_spans.get(
                event.span_id
            )
        return llama_span._mlflow_span if llama_span else None

    def new_span(
        self,
        id_: str,
        bound_args: inspect.BoundArguments,
        instance: Any | None = None,
        parent_span_id: str | None = None,
        **kwargs: Any,
    ) -> _LlamaSpan:
        with self.lock:
            parent = (
                self.open_spans.get(parent_span_id) or self._pending_spans.get(parent_span_id)
                if parent_span_id
                else None
            )

        parent_span = parent._mlflow_span if parent else mlflow.get_current_active_span()

        try:
            input_args = _extract_workflow_inputs(bound_args.arguments)
            attributes = self._get_instance_attributes(instance)
            span_type = self._get_span_type(instance) or SpanType.UNKNOWN
            span = start_span_no_context(
                name=id_.partition("-")[0],
                parent_span=parent_span,
                span_type=span_type,
                inputs=input_args,
                attributes=attributes,
            )

            token = set_span_in_context(span)
            self._span_id_to_token[span.span_id] = token

            # NB: The tool definition is passed to LLM via kwargs, but it is not set
            # to the LLM/Chat start event. Therefore, we need to handle it here.
            tools = input_args.get("kwargs", {}).get("tools")
            if tools and span_type in [SpanType.LLM, SpanType.CHAT_MODEL]:
                try:
                    set_span_chat_tools(span, tools)
                except Exception as e:
                    _logger.debug(f"Failed to set tools for {span}: {e}")

            return _LlamaSpan(id_=id_, parent_id=parent_span_id, mlflow_span=span)
        except BaseException as e:
            _logger.debug(f"Failed to create a new span: {e}", exc_info=True)

    def prepare_to_exit_span(
        self,
        id_: str,
        result: Any | None = None,
        **kwargs: Any,
    ) -> _LlamaSpan:
        try:
            with self.lock:
                llama_span = self.open_spans.get(id_)
            if not llama_span:
                return

            span = llama_span._mlflow_span
            token = self._span_id_to_token.pop(span.span_id, None)

            if _is_workflow_handler(result):
                # In llama-index-workflows >= 2.0, Workflow.run() is synchronous and returns
                # a WorkflowHandler instead of the actual result. Keep the span open so child
                # step spans can properly link to it, and close it when a StopEvent is received.
                self._pending_workflow_span_ids.add(id_)
                if token:
                    detach_span_from_context(token)
                return None  # Keep the span in open_spans
            elif self._stream_resolver.is_streaming_result(result):
                # In llama-index-core >= 0.14.17 a descendant LLM stream may be resolved
                # before this ancestor span exits. If so, its resolution was already recorded
                # and we close it here instead of pending it (which would leave it open and
                # the trace stuck in IN_PROGRESS).
                if not self._stream_resolver.resolve_pending_parent(
                    span, token=token, open_span_ids=self._open_mlflow_span_ids()
                ):
                    # If the result is a generator, we keep the span in progress for streaming
                    # and end it when the generator is exhausted.
                    is_pended = self._stream_resolver.register_stream_span(
                        span, result, llama_span_id=id_
                    )
                    if is_pended:
                        with self.lock:
                            self._pending_spans[id_] = llama_span
                        # We still need to detach the span from the context, otherwise it will
                        # be considered as "active"
                        detach_span_from_context(token)
                    else:
                        # If the span is not pended successfully, end it immediately
                        _end_span(span=span, outputs=result, token=token)
            else:
                _end_span(span=span, outputs=result, token=token)

            # If a child step returns a StopEvent, close the parent workflow span
            self._try_close_workflow_span(llama_span.parent_id, result)

            return llama_span
        except BaseException as e:
            _logger.debug(f"Failed to end a span: {e}", exc_info=True)

    def _try_close_workflow_span(self, parent_id: str | None, result: Any):
        """Close a pending workflow span when a child step returns a StopEvent."""
        if not parent_id or parent_id not in self._pending_workflow_span_ids:
            return

        try:
            from llama_index.core.workflow import StopEvent

            if not isinstance(result, StopEvent):
                return
        except ImportError:
            return

        self._pending_workflow_span_ids.discard(parent_id)
        with self.lock:
            workflow_llama_span = self.open_spans.pop(parent_id, None)
        if workflow_llama_span:
            _end_span(span=workflow_llama_span._mlflow_span, outputs=result.result)

    def resolve_pending_stream_span(self, span: LiveSpan, event: Any):
        """End the pending streaming span(s)"""
        self._stream_resolver.resolve(span, event, open_span_ids=self._open_mlflow_span_ids())
        with self.lock:
            self._pending_spans.pop(event.span_id, None)

    def _open_mlflow_span_ids(self) -> set[str]:
        """MLflow span IDs of the currently open (still executing) LlamaIndex spans."""
        with self.lock:
            return {
                llama_span._mlflow_span.span_id
                for llama_span in self.open_spans.values()
                if llama_span is not None and llama_span._mlflow_span is not None
            }

    def prepare_to_drop_span(self, id_: str, err: Exception | None, **kwargs) -> _LlamaSpan:
        """Logic for handling errors during the model execution."""
        with self.lock:
            llama_span = self.open_spans.get(id_)
        span = llama_span._mlflow_span
        token = self._span_id_to_token.pop(span.span_id, None)

        if _get_llama_index_version() >= Version("0.10.59"):
            # LlamaIndex determines if a workflow is terminated or not by propagating an special
            # exception WorkflowDone. We should treat this exception as a successful termination.
            from llama_index.core.workflow.errors import WorkflowDone

            if err and isinstance(err, WorkflowDone):
                return _end_span(span=span, status=SpanStatusCode.OK, token=token)

        span.add_event(SpanEvent.from_exception(err))
        _end_span(span=span, status="ERROR", token=token)
        return llama_span

    def _get_span_type(self, instance: Any) -> SpanType:
        """
        Map LlamaIndex instance type to MLflow span type. Some span type cannot be determined
        by instance type alone, rather need event info e.g. ChatModel, ReRanker
        """
        base_agent_types = ()
        if _get_llama_index_version() < Version("0.13.0"):
            from llama_index.core.base.agent.types import BaseAgent, BaseAgentWorker

            base_agent_types = (BaseAgent, BaseAgentWorker)
        else:
            from llama_index.core.agent.workflow import BaseWorkflowAgent

            base_agent_types = (BaseWorkflowAgent,)

        if isinstance(instance, (BaseLLM, MultiModalLLM)):
            return SpanType.LLM
        elif isinstance(instance, BaseRetriever):
            return SpanType.RETRIEVER
        elif isinstance(instance, base_agent_types):
            return SpanType.AGENT
        elif isinstance(instance, BaseEmbedding):
            return SpanType.EMBEDDING
        elif isinstance(instance, BaseTool):
            return SpanType.TOOL
        else:
            return SpanType.CHAIN

    @singledispatchmethod
    def _get_instance_attributes(self, instance: Any) -> dict[str, Any]:
        """
        Extract span attributes from LlamaIndex objects.

        NB: There are some overlap between attributes extracted from instance metadata and the
        events. For example, model name for an LLM is available in both. However, events might
        not always be triggered (e.g. 3P llm integration doesn't implement the event logic),
        so the instance metadata serves as a fallback source of information.
        """

    # TODO: Union type hint doesn't work with singledispatchmethod, so we have to define
    #  two separate methods for BaseLLM and MultiModalLLM. Once we upgrade to Python 3.10,
    #  we can use `BaseLLM | MultiModelLLM` type hint and it works with singledispatchmethod.
    @_get_instance_attributes.register
    def _(self, instance: BaseLLM):
        return self._get_llm_attributes(instance)

    @_get_instance_attributes.register
    def _(self, instance: MultiModalLLM):
        return self._get_llm_attributes(instance)

    def _get_llm_attributes(self, instance) -> dict[str, Any]:
        attr = {SpanAttributeKey.MESSAGE_FORMAT: "llamaindex"}
        if metadata := instance.metadata:
            attr["model_name"] = metadata.model_name
            attr[SpanAttributeKey.MODEL] = metadata.model_name
            if params_str := metadata.model_dump_json(exclude_unset=True):
                attr["invocation_params"] = json.loads(params_str)
        # LlamaIndex LLM class names map directly to providers
        # e.g., OpenAI, Anthropic, Gemini, Bedrock, etc.
        attr[SpanAttributeKey.MODEL_PROVIDER] = instance.__class__.__name__.lower()
        return attr

    @_get_instance_attributes.register
    def _(self, instance: BaseEmbedding):
        return {
            "model_name": instance.model_name,
            SpanAttributeKey.MODEL: instance.model_name,
            SpanAttributeKey.MODEL_PROVIDER: instance.__class__.__name__.lower(),
            "embed_batch_size": instance.embed_batch_size,
        }

    @_get_instance_attributes.register
    def _(self, instance: BaseTool):
        metadata = instance.metadata
        attributes = {"description": metadata.description}
        try:
            attributes["name"] = metadata.name
        except ValueError:
            # ToolMetadata.get_name() raises ValueError if name is None
            pass
        try:
            attributes["parameters"] = json.loads(metadata.fn_schema_str)
        except ValueError:
            # ToolMetadata.get_fn_schema_str() raises ValueError if fn_schema is None
            pass
        return attributes


class MlflowEventHandler(BaseEventHandler, extra="allow"):
    """
    Event handler processes various events that are triggered during execution.

    Events are used as supplemental source for recording additional metadata to the span,
    such as model name, parameters to the span, because they are not available in the inputs
    and outputs in SpanHandler.
    """

    _span_handler: MlflowSpanHandler

    @classmethod
    def class_name(cls) -> str:
        return "MlflowEventHandler"

    def __init__(self, _span_handler):
        super().__init__()
        self._span_handler = _span_handler

    def handle(self, event: BaseEvent) -> Any:
        try:
            if span := self._span_handler.get_span_for_event(event):
                self._handle_event(event, span)
        except Exception as e:
            _logger.debug(f"Failed to handle event: {e}", exc_info=True)

    @singledispatchmethod
    def _handle_event(self, event: BaseEvent, span: LiveSpan):
        # Pass through the events we are not interested in
        pass

    @_handle_event.register
    def _(self, event: AgentToolCallEvent, span: LiveSpan):
        span.set_attribute("name", event.tool.name)
        span.set_attribute("description", event.tool.description)
        span.set_attribute("parameters", event.tool.get_parameters_dict())

    @_handle_event.register
    def _(self, event: EmbeddingStartEvent, span: LiveSpan):
        span.set_attribute("model_dict", event.model_dict)
        self._extract_and_set_model_name(span, event.model_dict)

    @_handle_event.register
    def _(self, event: LLMPredictStartEvent, span: LiveSpan):
        """
        An event triggered when LLM's predict() is called.

        In LlamaIndex, predict() is a gateway method that dispatch the request to
        either chat() or completion() method depending on the model type, as well
        as crafting prompt from the template.
        """
        template = event.template
        template_args = {
            **template.kwargs,
            **(event.template_args or {}),
        }
        span.set_attributes({
            "prmopt_template": template.get_template(),
            "template_arguments": {var: template_args.get(var) for var in template_args},
        })

    @_handle_event.register
    def _(self, event: LLMCompletionStartEvent, span: LiveSpan):
        span.set_attribute("prompt", event.prompt)
        span.set_attribute("model_dict", event.model_dict)
        self._extract_and_set_model_name(span, event.model_dict)

    @_handle_event.register
    def _(self, event: LLMCompletionEndEvent, span: LiveSpan):
        # Defensive: response shape can vary across llama-index/openai versions
        try:
            span.set_attribute("usage", self._extract_token_usage(event.response))
            token_counts = self._parse_usage(span)
            span.set_attribute(SpanAttributeKey.CHAT_USAGE, token_counts)
        except (AttributeError, KeyError, TypeError) as e:
            _logger.debug(f"Failed to set usage attributes: {e}", exc_info=True)
        self._span_handler.resolve_pending_stream_span(span, event)

    @_handle_event.register
    def _(self, event: LLMChatStartEvent, span: LiveSpan):
        span.set_attribute(SpanAttributeKey.SPAN_TYPE, SpanType.CHAT_MODEL)
        span.set_attribute("model_dict", event.model_dict)
        self._extract_and_set_model_name(span, event.model_dict)

    @_handle_event.register
    def _(self, event: LLMChatEndEvent, span: LiveSpan):
        # Defensive: response shape can vary across llama-index/openai versions
        try:
            span.set_attribute("usage", self._extract_token_usage(event.response))
            token_counts = self._parse_usage(span)
            span.set_attribute(SpanAttributeKey.CHAT_USAGE, token_counts)
        except (AttributeError, KeyError, TypeError) as e:
            _logger.debug(f"Failed to set usage attributes: {e}", exc_info=True)
        self._span_handler.resolve_pending_stream_span(span, event)

    @_handle_event.register
    def _(self, event: ReRankStartEvent, span: LiveSpan):
        span.set_attribute(SpanAttributeKey.SPAN_TYPE, SpanType.RERANKER)
        span.set_attributes({
            "model_name": event.model_name,
            "top_n": event.top_n,
        })

    @_handle_event.register
    def _(self, event: ExceptionEvent, span: LiveSpan):
        """
        Handle an exception event for stream spans.

        For non-stream spans, exception is processed by the prepare_to_drop_span() handler of
        the span handler. However, for stream spans, the exception may raised during the
        streaming after it exit. Therefore, we need to resolve the span here.
        """
        self._span_handler.resolve_pending_stream_span(span, event)

    def _extract_and_set_model_name(self, span: LiveSpan, model_dict: dict[str, Any] | None):
        if model_dict and (model := model_dict.get("model")):
            span.set_attribute(SpanAttributeKey.MODEL, model)
            if isinstance(model, str):
                match model.split("/", 1):
                    case [provider, _]:
                        span.set_attribute(SpanAttributeKey.MODEL_PROVIDER, provider)

    def _extract_token_usage(self, response: ChatResponse | CompletionResponse) -> dict[str, int]:
        if raw := response.raw:
            # The raw response can be a Pydantic model or a dictionary
            if isinstance(raw, pydantic.BaseModel):
                raw = raw.model_dump()

            if usage := raw.get("usage"):
                return usage

        # If the usage is not found in the raw response, look for token counts
        # in additional_kwargs of the completion payload
        usage = {}
        if additional_kwargs := getattr(response, "additional_kwargs", None):
            for k in ["prompt_tokens", "completion_tokens", "total_tokens"]:
                if (v := additional_kwargs.get(k)) is not None:
                    usage[k] = v
        return usage

    def _parse_usage(self, span: LiveSpan):
        try:
            usage = span.get_attribute("usage")
            return {
                TokenUsageKey.INPUT_TOKENS: usage["prompt_tokens"],
                TokenUsageKey.OUTPUT_TOKENS: usage["completion_tokens"],
                TokenUsageKey.TOTAL_TOKENS: usage.get(
                    "total_tokens", usage["prompt_tokens"] + usage["completion_tokens"]
                ),
            }
        except Exception as e:
            _logger.debug(f"Failed to set TokenUsage to the span: {e}", exc_info=True)


_StreamEndEvent = LLMChatEndEvent | LLMCompletionEndEvent | ExceptionEvent


def _get_task_step_output_type():
    if _get_llama_index_version() < Version("0.13.0"):
        from llama_index.core.base.agent.types import TaskStepOutput

        return TaskStepOutput
    return ()


class StreamResolver:
    """
    A class is responsible for closing the pending streaming spans that are waiting
    for the stream to be exhausted. Once the associated stream is exhausted, this
    class will resolve the span, as well as recursively resolve the parent spans
    that returns the same (or derived) stream.
    """

    def __init__(self):
        self._span_id_to_span_and_gen: dict[str, tuple[LiveSpan, Generator, str | None]] = {}
        # Maps a span_id -> (status, output_text) for ancestor spans whose descendant
        # stream was resolved before the ancestor exited and registered as a pending
        # stream. In llama-index-core >= 0.14.17, the LLM stream end event can fire and
        # resolve the stream before the enclosing query-engine spans exit. Such ancestors
        # are closed immediately when they register instead of being left open forever.
        self._pending_parent_resolutions: dict[str, tuple[SpanStatusCode, str | None]] = {}

    def is_streaming_result(self, result: Any) -> bool:
        return (
            inspect.isgenerator(result)  # noqa: SIM101
            or isinstance(result, (StreamingResponse, AsyncStreamingResponse))
            or isinstance(result, StreamingAgentChatResponse)
            or (
                isinstance(result, _get_task_step_output_type())
                and self.is_streaming_result(result.output)
            )
        )

    def register_stream_span(
        self, span: LiveSpan, result: Any, llama_span_id: str | None = None
    ) -> bool:
        """
        Register the pending streaming span with the associated generator.

        Args:
            span: The span that has a streaming output.
            result: The streaming result that is being processed.
            llama_span_id: The corresponding LlamaIndex span ID, used to restore its
                context while a deferred response generator runs.

        Returns:
            True if the span is registered successfully, False otherwise.
        """
        if inspect.isgenerator(result) or inspect.isasyncgen(result):
            stream = result
        elif isinstance(result, (StreamingResponse, AsyncStreamingResponse)):
            stream = result.response_gen
        elif isinstance(result, StreamingAgentChatResponse):
            stream = result.chat_stream
        elif isinstance(result, _get_task_step_output_type()):
            stream = result.output.chat_stream
        else:
            raise ValueError(f"Unsupported streaming response type: {type(result)}")

        # Check if generator/async generator is already closed
        # Async generators use ag_frame, sync generators use gi_frame
        if inspect.isasyncgen(stream):
            # For async generators, ag_frame is None when closed
            if stream.ag_frame is None:
                return False
        elif inspect.isgenerator(stream):
            # For sync generators, use getgeneratorstate
            if inspect.getgeneratorstate(stream) == inspect.GEN_CLOSED:
                return False

        if isinstance(result, (StreamingResponse, AsyncStreamingResponse)):
            # A response synthesizer can return a generator that was created by an
            # already-pending child span. LlamaIndex resumes that generator after it
            # has reset its span context, so work performed while streaming would
            # otherwise start a new MLflow trace. Restore the innermost pending
            # span's context only while advancing the generator.
            parent_span, parent_llama_span_id = next(
                (
                    (pending_span, pending_llama_span_id)
                    for pending_span, pending_stream, pending_llama_span_id in (
                        self._span_id_to_span_and_gen.values()
                    )
                    if pending_stream is stream
                ),
                (span, llama_span_id),
            )
            stream = self._with_span_context(stream, parent_span, parent_llama_span_id)
            result.response_gen = stream
        self._span_id_to_span_and_gen[span.span_id] = (span, stream, llama_span_id)
        return True

    @staticmethod
    def _with_span_context(
        stream: Generator, span: LiveSpan, llama_span_id: str | None
    ) -> Generator:
        if inspect.isasyncgen(stream):

            async def async_generator():
                while True:
                    try:
                        with _stream_span_context(span, llama_span_id):
                            chunk = await stream.__anext__()
                    except StopAsyncIteration:
                        return
                    yield chunk

            return async_generator()

        def generator():
            while True:
                try:
                    with _stream_span_context(span, llama_span_id):
                        chunk = next(stream)
                except StopIteration:
                    return
                yield chunk

        return generator()

    def _record_pending_resolution(
        self,
        parent_id: str | None,
        resolution: tuple[SpanStatusCode, str | None],
        open_span_ids: set[str] | None,
    ) -> None:
        """
        Record a resolution for an ancestor span that has not registered as a pending
        stream yet, so it is closed immediately when it exits (see resolve_pending_parent).

        Only record when the parent genuinely still needs resolving, i.e. it is still open
        (executing) and awaiting resolution. A parent that is absent (root, parent_id is
        None) or already closed does not need resolving through this mechanism, and
        recording for it would leave a stale entry that could later close an unrelated span.
        """
        if parent_id is None:
            return
        if open_span_ids is not None and parent_id not in open_span_ids:
            return
        self._pending_parent_resolutions[parent_id] = resolution

    def resolve_pending_parent(
        self,
        span: LiveSpan,
        token: Any | None = None,
        open_span_ids: set[str] | None = None,
    ) -> bool:
        """
        Close a span whose descendant stream was already resolved out-of-order.

        In llama-index-core >= 0.14.17 the LLM stream end event can fire before the
        enclosing query-engine spans exit. When that happens, `resolve()` records the
        resolution for the not-yet-registered ancestor. This method is called when such
        an ancestor finally exits: it closes the span immediately (detaching its OTel
        token) instead of pending it, and propagates the resolution to the next ancestor
        so the whole chain is finalized as each span exits.

        Args:
            span: The span that is about to be pended as a stream.
            token: The OTel context token for the span, detached when the span is closed.
            open_span_ids: MLflow span IDs of the currently open spans, used to decide
                whether the next ancestor still needs a recorded resolution.

        Returns:
            True if a recorded resolution was found and the span was closed, False otherwise.
        """
        resolution = self._pending_parent_resolutions.pop(span.span_id, None)
        if resolution is None:
            return False

        status, output_text = resolution
        # The span was never pended, so it still holds an active OTel token. End it once
        # here (passing the token so it is detached) and do not register/pend it again.
        _end_span(span=span, status=status, outputs=output_text, token=token)

        self._record_pending_resolution(span.parent_id, resolution, open_span_ids)
        return True

    def resolve(
        self, span: LiveSpan, event: _StreamEndEvent, open_span_ids: set[str] | None = None
    ):
        """
        Finish the streaming span and recursively resolve the parent spans that
        returns the same (or derived) stream.
        """
        _, stream, _ = self._span_id_to_span_and_gen.pop(span.span_id, (None, None, None))
        if not stream:
            return

        if isinstance(event, (LLMChatEndEvent, LLMCompletionEndEvent)):
            outputs = event.response
            status = SpanStatusCode.OK
        elif isinstance(event, ExceptionEvent):
            outputs = None
            status = SpanStatusCode.ERROR
            span.add_event(SpanEvent.from_exception(event.exception))
        else:
            raise ValueError(f"Unsupported event type to resolve streaming: {type(event)}")

        _end_span(span=span, status=status, outputs=outputs)

        # Extract the complete text from the event.
        if isinstance(outputs, ChatResponse):
            output_text = outputs.message.content
        elif isinstance(outputs, CompletionResponse):
            output_text = outputs.response.text
        else:
            output_text = None

        # Recursively resolve the parent spans that are also waiting for the same token
        # stream to be exhausted.
        while span.parent_id in self._span_id_to_span_and_gen:
            if span_and_stream := self._span_id_to_span_and_gen.pop(span.parent_id, None):
                span, stream, _ = span_and_stream
                # We reuse the same output text for parent spans. This may not be 100% correct
                # as token stream can be modified by callers. However, it is technically
                # challenging to track the modified stream across multiple spans.
                _end_span(span=span, status=status, outputs=output_text)

        # In llama-index-core >= 0.14.17 the LLM stream end event can fire before the
        # enclosing query-engine spans exit and register as pending streams. Record the
        # resolution for the first ancestor that has not registered yet so it can be
        # closed immediately when it exits (see resolve_pending_parent). Without this, such
        # ancestors would stay open and the trace would be stuck in the IN_PROGRESS state.
        # On the fully-resolved path (all ancestors already closed by the loop above), the
        # loop stops at the root or a non-streaming ancestor that no longer needs resolving,
        # so _record_pending_resolution skips it.
        self._record_pending_resolution(span.parent_id, (status, output_text), open_span_ids)
